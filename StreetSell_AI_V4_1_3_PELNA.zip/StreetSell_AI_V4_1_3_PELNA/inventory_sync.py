"""Idempotent inventory reconciliation for Allegro order snapshots."""
from datetime import datetime, timezone

ACTIVE = {'READY_FOR_PROCESSING'}
# Shared Allegro: matching SKU can belong to either owner. Require an explicit offer link.
ALLOW_SKU_AUTO_LINK = False

def setup(store):
    with store.connect() as con:
        con.execute('CREATE TABLE IF NOT EXISTS inventory_archive(product_id INTEGER PRIMARY KEY, archived_at TEXT NOT NULL, reason TEXT NOT NULL)')
        con.execute('CREATE TABLE IF NOT EXISTS inventory_links(account TEXT NOT NULL, offer_id TEXT NOT NULL, product_id INTEGER NOT NULL, PRIMARY KEY(account,offer_id))')
        con.execute('''CREATE TABLE IF NOT EXISTS inventory_order_lines (
            account TEXT NOT NULL, line_id TEXT NOT NULL, offer_id TEXT NOT NULL,
            product_id INTEGER, deducted INTEGER NOT NULL DEFAULT 0,
            quantity INTEGER NOT NULL, status TEXT NOT NULL,
            PRIMARY KEY(account,line_id))''')
        con.execute('CREATE TABLE IF NOT EXISTS inventory_sync_accounts(account TEXT PRIMARY KEY, initialized_at TEXT NOT NULL)')

def archive(store, ids):
    now=datetime.now(timezone.utc).isoformat()
    with store.connect() as con:
        for pid in ids:
            if con.execute('SELECT 1 FROM products WHERE id=?',(pid,)).fetchone():
                con.execute('INSERT OR REPLACE INTO inventory_archive VALUES(?,?,?)',(pid,now,'Ręczne archiwum'))

def unarchive(store, pid):
    with store.connect() as con:con.execute('DELETE FROM inventory_archive WHERE product_id=?',(pid,))

def available(store):
    # WorkspaceApp calls load_db before ModernApp.__init__ returns.
    # Ensure schema exists before the first inventory query.
    setup(store)
    with store.connect() as con:
        return con.execute('SELECT * FROM products WHERE id NOT IN (SELECT product_id FROM inventory_archive) ORDER BY id').fetchall()

def pending(store, account):
    with store.connect() as con:
        return con.execute('''SELECT offer_id, COUNT(*) AS lines FROM inventory_order_lines
          WHERE account=? AND product_id IS NULL AND status='READY_FOR_PROCESSING'
          AND offer_id<>'' GROUP BY offer_id ORDER BY lines DESC''',(account,)).fetchall()

def link(store,account,offer_id,product_id):
    with store.connect() as con:
        if not con.execute('SELECT 1 FROM products WHERE id=?',(product_id,)).fetchone():raise ValueError('Nie ma takiego produktu.')
        con.execute('INSERT OR REPLACE INTO inventory_links VALUES(?,?,?)',(account,offer_id,product_id))
        con.execute('UPDATE inventory_order_lines SET product_id=? WHERE account=? AND offer_id=? AND product_id IS NULL',(product_id,account,offer_id))

def reconcile(store,snapshot):
    """First import is baseline, not a retroactive deduction. Never auto-restock cancellations."""
    account=snapshot.account;now=datetime.now(timezone.utc).isoformat();changed=0
    with store.connect() as con:
        first=con.execute('SELECT 1 FROM inventory_sync_accounts WHERE account=?',(account,)).fetchone() is None
        for order in snapshot.orders:
            status=order['status']
            for line in order['lines']:
                lid=line['id'];qty=int(line['quantity']);offer=line['offer_id'];external=line.get('external_id','')
                existing=con.execute('SELECT * FROM inventory_order_lines WHERE account=? AND line_id=?',(account,lid)).fetchone()
                if existing:
                    # Status updates never deduct a second time. Cancelled/returned require human stock inspection.
                    con.execute('UPDATE inventory_order_lines SET status=? WHERE account=? AND line_id=?',(status,account,lid))
                    continue
                mapped=con.execute('SELECT product_id FROM inventory_links WHERE account=? AND offer_id=?',(account,offer)).fetchone() if offer else None
                pid=mapped['product_id'] if mapped else None
                if pid is None and external and ALLOW_SKU_AUTO_LINK:
                    matches=con.execute('SELECT id FROM products WHERE sku=? AND sku<>?',(external,'')).fetchall()
                    if len(matches)==1:pid=matches[0]['id']
                if pid is not None and offer:
                    con.execute('INSERT OR IGNORE INTO inventory_links VALUES(?,?,?)',(account,offer,pid))
                con.execute('INSERT INTO inventory_order_lines VALUES(?,?,?,?,?,?,?)',
                            (account,lid,offer,pid,1 if first else 0,qty,status))
        if first:
            con.execute('INSERT INTO inventory_sync_accounts VALUES(?,?)',(account,now))
            return 0,True
        # Process newly linked lines too; only when status is confirmed and quantity available.
        rows=con.execute('''SELECT * FROM inventory_order_lines WHERE account=? AND deducted=0
          AND product_id IS NOT NULL AND status='READY_FOR_PROCESSING' ''',(account,)).fetchall()
        for row in rows:
            # Never make quantity negative: manual resolution if insufficient stock.
            result=con.execute('UPDATE products SET quantity=quantity-?,updated_at=? WHERE id=? AND quantity>=?',
                               (row['quantity'],now,row['product_id'],row['quantity']))
            if result.rowcount:
                con.execute('UPDATE inventory_order_lines SET deducted=1 WHERE account=? AND line_id=?',(account,row['line_id']))
                changed+=row['quantity']
                remaining=con.execute('SELECT quantity FROM products WHERE id=?',(row['product_id'],)).fetchone()
                if remaining and remaining['quantity']==0:
                    con.execute('INSERT OR IGNORE INTO inventory_archive VALUES(?,?,?)',(row['product_id'],now,'Sprzedane'))
    return changed,False
