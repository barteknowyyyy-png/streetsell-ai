import hashlib
import sqlite3
from datetime import datetime
from pathlib import Path

STATUSES = ('Do weryfikacji', 'Szkic', 'Zatwierdzony')
CONDITIONS = ('Nie sprawdzono', 'Nowy', 'Powystawowy', 'Używany', 'Uszkodzony')

class Store:
    def __init__(self, path):
        self.path = Path(path)

    def connect(self):
        con = sqlite3.connect(self.path, timeout=15)
        con.row_factory = sqlite3.Row
        return con

    def migrate(self):
        with self.connect() as con:
            existing = {r['name'] for r in con.execute('PRAGMA table_info(products)')}
            additions = {'condition': "TEXT DEFAULT 'Nie sprawdzono'", 'contents': "TEXT DEFAULT ''",
                         'defects': "TEXT DEFAULT ''", 'sale_price': "TEXT DEFAULT ''",
                         'updated_at': "TEXT DEFAULT ''"}
            for name, kind in additions.items():
                if name not in existing:
                    con.execute(f'ALTER TABLE products ADD COLUMN {name} {kind}')
            con.execute('CREATE TABLE IF NOT EXISTS imports (digest TEXT PRIMARY KEY, filename TEXT, imported_at TEXT)')
            con.execute("""CREATE TABLE IF NOT EXISTS product_photos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                product_id INTEGER NOT NULL REFERENCES products(id),
                relative_path TEXT NOT NULL UNIQUE,
                thumbnail_path TEXT NOT NULL,
                original_name TEXT NOT NULL,
                sha256 TEXT NOT NULL,
                position INTEGER NOT NULL,
                width INTEGER NOT NULL, height INTEGER NOT NULL,
                UNIQUE(product_id,sha256)
            )""")
            con.execute('CREATE INDEX IF NOT EXISTS photos_by_product ON product_photos(product_id,position,id)')
            photo_columns = {r['name'] for r in con.execute('PRAGMA table_info(product_photos)')}
            for name in ('source_page', 'source_image', 'original_relative_path', 'localization_language'):
                if name not in photo_columns:
                    con.execute(f"ALTER TABLE product_photos ADD COLUMN {name} TEXT NOT NULL DEFAULT ''")
        # Katalog palet i archiwizacja zbiorcza. Uruchom po migracji tabel produktow.
        import pallet_manager
        pallet_manager.setup(self)

    def products(self, query='', status='Wszystkie'):
        with self.connect() as con:
            rows = con.execute('SELECT * FROM products ORDER BY id').fetchall()
        query = query.strip().casefold()
        return [r for r in rows if (status == 'Wszystkie' or r['status'] == status) and
                (not query or query in ' '.join(str(r[k] or '') for k in
                  ('id', 'product_name', 'asin', 'ean', 'sku', 'generated_title')).casefold()
                 or query in f"SS-{r['id']:05d}".casefold())]

    def get(self, product_id):
        with self.connect() as con:
            return con.execute('SELECT * FROM products WHERE id=?', (product_id,)).fetchone()

    def save(self, product_id, values, approved=False):
        values = dict(values)
        title = values.get('generated_title', '').strip()
        description = values.get('generated_description', '').strip()
        try:
            quantity = int(str(values['quantity']))
        except (ValueError, KeyError):
            raise ValueError('Ilość musi być liczbą całkowitą.')
        if quantity < 0:
            raise ValueError('Ilość nie może być ujemna.')
        price = values.get('sale_price', '').strip().replace(',', '.')
        if price:
            from decimal import Decimal, InvalidOperation
            try:
                amount = Decimal(price)
                if not amount.is_finite() or amount < 0 or amount.as_tuple().exponent < -2:
                    raise InvalidOperation
            except InvalidOperation:
                raise ValueError('Podaj cenę w złotych, np. 129,99 (maksymalnie 2 miejsca po przecinku).')
        if 'asin' in values:
            import re
            asin = str(values['asin'] or '').strip().upper()
            if asin and not re.fullmatch(r'[A-Z0-9]{10}', asin):
                raise ValueError('ASIN powinien mieć dokładnie 10 liter lub cyfr, np. B0GVT2SXDY. Możesz też zostawić go pustego.')
            values['asin'] = asin
        if 'product_link' in values:
            link = str(values['product_link'] or '').strip()
            if link:
                from public_web import https_url
                link = https_url(link)
            values['product_link'] = link
        if approved:
            if not title or not description:
                raise ValueError('Przed zatwierdzeniem uzupełnij tytuł i opis.')
            if values.get('condition') == 'Nie sprawdzono':
                raise ValueError('Przed zatwierdzeniem sprawdź i wybierz stan produktu.')
        values.update(quantity=quantity, sale_price=price, generated_title=title,
                      generated_description=description,
                      status='Zatwierdzony' if approved else 'Szkic',
                      updated_at=datetime.now().isoformat(timespec='seconds'))
        allowed = {'quantity', 'sale_price', 'condition', 'contents', 'defects',
                   'generated_title', 'generated_description', 'research_notes', 'status', 'updated_at', 'asin', 'product_link'}
        if set(values) - allowed:
            raise ValueError('Nieobsługiwane pole produktu.')
        with self.connect() as con:
            con.execute('UPDATE products SET ' + ', '.join(f'{k}=?' for k in values) + ' WHERE id=?',
                        (*values.values(), product_id))

    def invalidate_approval(self, product_id):
        with self.connect() as con:
            con.execute("UPDATE products SET status='Do weryfikacji' WHERE id=?", (product_id,))

    def backup(self, destination):
        if Path(destination).resolve() == self.path.resolve():
            raise ValueError('Wybierz inny plik niż aktywna baza.')
        with self.connect() as source, sqlite3.connect(destination) as target:
            source.backup(target)

    @staticmethod
    def digest(path):
        return hashlib.sha256(Path(path).read_bytes()).hexdigest()
