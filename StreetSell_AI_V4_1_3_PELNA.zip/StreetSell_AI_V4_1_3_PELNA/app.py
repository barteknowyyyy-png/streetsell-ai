"""StreetSell AI V4 Windows entrypoint with a single-instance/update lock."""
from pathlib import Path
import os


def main():
    with open(Path(__file__).with_name('streetsell_v4.lock'),'a+b') as lock:
        if os.name=='nt':
            import msvcrt
            lock.seek(0);lock.write(b'0');lock.flush();lock.seek(0)
            try:msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
            except OSError:
                import tkinter as tk
                from tkinter import messagebox
                root=tk.Tk();root.withdraw();messagebox.showerror('StreetSell AI V4','Aplikacja lub aktualizator jest już uruchomiony.');root.destroy();return
        from cloud_ui import run
        run()

if __name__=='__main__':main()
