@echo off
cd /d "%~dp0"
py -3 --version >nul 2>&1
if errorlevel 1 (
 echo Zainstaluj Python 3.10 lub nowszy z python.org.
 pause
 exit /b 1
)
if not exist .venv\Scripts\python.exe py -3 -m venv .venv
if errorlevel 1 goto :error
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto :error
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0create_shortcut.ps1"
if errorlevel 1 (
 echo Nie udalo sie utworzyc skrotu. Aplikacje mozesz uruchomic przez run.bat.
) else (
 echo Instalacja zakonczona. Uruchom ikone StreetSell AI na pulpicie.
)
pause
exit /b 0
:error
echo Instalacja nie powiodla sie. Sprawdz komunikat powyzej.
pause
exit /b 1
