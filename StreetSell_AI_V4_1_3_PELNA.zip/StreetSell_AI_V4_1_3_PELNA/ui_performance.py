"""Bounded UI work: batch wheel events into one update per display frame."""
import math
import tkinter as tk

TABLE_ROWS=8

class WheelBatch:
    def __init__(self,scheduler,interval=16,max_steps=24):
        self.scheduler=scheduler;self.interval=interval;self.max_steps=max_steps
        self.pending=None;self.amounts={};self.closed=False

    def add(self,target,steps):
        if self.closed or not steps:return
        self.amounts[target]=max(-self.max_steps,min(self.max_steps,self.amounts.get(target,0)+steps))
        if self.pending is None:self.pending=self.scheduler.after(self.interval,self.flush)

    def flush(self):
        self.pending=None
        for target,amount in tuple(self.amounts.items()):
            steps=math.trunc(amount)
            if abs(amount-steps)>0.0001:self.amounts[target]=amount-steps
            else:self.amounts.pop(target,None)
            if steps:
                try:target.yview_scroll(steps,'units')
                except (tk.TclError,RuntimeError):self.amounts.pop(target,None)
        # Fractions wait for the next event; never spin timers while idle.

    def clear(self):
        if self.pending is not None:
            try:self.scheduler.after_cancel(self.pending)
            except tk.TclError:pass
        self.pending=None;self.amounts.clear()

    def close(self):self.clear();self.closed=True


def visible_rows(count):return max(3,min(TABLE_ROWS,count))


def can_scroll(widget,steps):
    first,last=widget.yview()
    return first>0.0001 if steps<0 else last<0.9999
