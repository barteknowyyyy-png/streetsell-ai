"""Dzisiejsza sprzedaż Allegro: tylko odczyt, dzień w Europe/Warsaw, PLN."""
import hashlib,json,re
from dataclasses import dataclass
from datetime import datetime,time,timedelta,timezone
from decimal import Decimal,InvalidOperation
from urllib.parse import urlencode
from zoneinfo import ZoneInfo
from allegro_api import AllegroClient,AllegroError,ApiError

WARSAW=ZoneInfo('Europe/Warsaw')
CURRENCIES=('PLN','EUR','CZK','HUF')
ZERO=Decimal('0.00')

def money(value):
    try:
        result=Decimal(str(value).strip().replace(',','.'))
        if not result.is_finite() or result<0 or result>Decimal('999999999.99') or result.as_tuple().exponent < -2:raise InvalidOperation
        return result.quantize(Decimal('.01'))
    except (InvalidOperation,ValueError,TypeError):raise ValueError('Podaj kwotę w złotych z maksymalnie 2 miejscami po przecinku.') from None

def pln(value):return f'{value:,.2f}'.replace(',',' ').replace('.',',')+' zł'

def amount(value,currency='PLN'):
    return pln(value) if currency=='PLN' else pln(value).removesuffix(' zł')+' '+currency

def today_bounds(now=None):
    now=now or datetime.now(timezone.utc)
    if now.tzinfo is None:raise ValueError('Data musi zawierać strefę czasową.')
    day=now.astimezone(WARSAW).date()
    start=datetime.combine(day,time.min,WARSAW).astimezone(timezone.utc)
    end=datetime.combine(day+timedelta(days=1),time.min,WARSAW).astimezone(timezone.utc)
    return day.isoformat(),start,end

@dataclass
class DailySnapshot:
    day:str
    account:str
    login:str
    units:int
    orders:int
    value:Decimal
    cod:Decimal
    fetched_at:str
    lines:list
    currency:str="PLN"
    by_currency:dict|None=None


def aggregate(orders,day,start,end,account,login,now):
    seen=set();buckets={};all_order_ids=set();all_units=0
    ordered=sorted(orders,key=lambda o:str(o.get('updatedAt') or ''),reverse=True)
    for order in ordered:
        eligible=order.get('status')=='READY_FOR_PROCESSING' and (order.get('fulfillment') or {}).get('status') not in ('CANCELLED','RETURNED')
        is_cod=(order.get('payment') or {}).get('type')=='CASH_ON_DELIVERY'
        for item in order.get('lineItems') or []:
            identity=item.get('id')
            if not isinstance(identity,str) or not identity:raise AllegroError('Allegro zwróciło pozycję bez identyfikatora. Statystyki nie zostały obliczone.')
            if identity in seen:continue
            seen.add(identity)
            if not eligible:continue
            try:
                bought=datetime.fromisoformat(str(item['boughtAt']).replace('Z','+00:00'))
                if bought.tzinfo is None:raise ValueError()
                if not start<=bought<end:continue
                price=item['price'];currency=price['currency']
                if not isinstance(currency,str) or not re.fullmatch('[A-Z]{3}',currency):raise ValueError()
                qty=item['quantity']
                if type(qty) is not int or qty<1:raise ValueError()
                total=money(price['amount'])*qty
            except (KeyError,ValueError,TypeError):raise AllegroError('Niepełne dane pozycji zamówienia. Statystyki nie zostały obliczone.') from None
            bucket=buckets.setdefault(currency,dict(units=0,orders=set(),value=ZERO,cod=ZERO,lines=[]))
            bucket['units']+=qty;bucket['value']+=total;bucket['orders'].add(str(order.get('id') or ''))
            all_units+=qty;all_order_ids.add(str(order.get('id') or ''))
            if is_cod:bucket['cod']+=total
            bucket['lines'].append(dict(line_id=identity,name=str((item.get('offer') or {}).get('name') or 'Produkt'),quantity=qty,total=str(total),cod=is_cod,currency=currency))
    stamp=now.astimezone(WARSAW).isoformat(timespec='seconds')
    groups={c:DailySnapshot(day,account,login,b['units'],len(b['orders']),b['value'],b['cod'],stamp,b['lines'],c) for c,b in buckets.items()}
    pl=groups.get('PLN')
    return DailySnapshot(day,account,login,all_units,len(all_order_ids),pl.value if pl else ZERO,
        pl.cod if pl else ZERO,stamp,[line for b in buckets.values() for line in b['lines']], 'PLN',groups)

def currency_snapshot(snapshot,currency):
    if snapshot.by_currency is None:
        if snapshot.currency==currency:return snapshot
    elif currency in snapshot.by_currency:return snapshot.by_currency[currency]
    return DailySnapshot(snapshot.day,snapshot.account,snapshot.login,0,0,ZERO,ZERO,snapshot.fetched_at,[],currency)

class DailySalesService:
    def __init__(self,client_factory=AllegroClient):self.factory=client_factory
    def fetch(self,now=None):
        now=now or datetime.now(timezone.utc);day,start,end=today_bounds(now)
        client=self.factory('production')
        profile=client.profile() # odnawia token istniejącym mechanizmem
        config=client._config();token=(client.state().get('tokens') or {}).get('access_token')
        if not token:raise AllegroError('Połącz konto Allegro, aby pobrać statystyki.')
        all_orders=[];offset=0
        while True:
            params={'lineItems.boughtAt.gte':start.isoformat().replace('+00:00','Z'),
                    'lineItems.boughtAt.lte':(end-timedelta(microseconds=1)).isoformat().replace('+00:00','Z'),
                    'limit':20,'offset':offset}
            try:
                payload=client.transport.request(client.api_url+'/order/checkout-forms?'+urlencode(params),'GET',client._headers(config,token))
            except ApiError as exc:
                if exc.status==403:raise AllegroError('Brak uprawnienia odczytu zamówień. W Allegro włącz allegro:api:orders:read, a następnie w Integracja Allegro kliknij Połącz konto ponownie.') from None
                raise
            forms=payload.get('checkoutForms')
            if not isinstance(forms,list) or any(not isinstance(o,dict) for o in forms):raise AllegroError('Nieprawidłowy format listy zamówień Allegro.')
            all_orders.extend(forms);offset+=len(forms)
            total=payload.get('totalCount')
            if not forms or (isinstance(total,int) and offset>=total) or len(forms)<20:break
            if offset>=2000:raise AllegroError('Dzienna lista przekroczyła limit 2000 zamówień. Nie pokazano niepełnych statystyk.')
        return aggregate(all_orders,day,start,end,profile['id'],profile['login'],now)

class DailyCosts:
    """Koszty osobno dla konta, dnia i waluty; dotychczasowe PLN zachowane."""
    def __init__(self,store):
        self.store=store
        with store.connect() as con:
            con.execute("CREATE TABLE IF NOT EXISTS daily_costs (account TEXT NOT NULL,day TEXT NOT NULL,goods TEXT NOT NULL,fees TEXT NOT NULL,other TEXT NOT NULL,basis TEXT NOT NULL DEFAULT '',PRIMARY KEY(account,day))")
            columns={row['name'] for row in con.execute('PRAGMA table_info(daily_costs)')}
            if 'basis' not in columns:con.execute("ALTER TABLE daily_costs ADD COLUMN basis TEXT NOT NULL DEFAULT ''")
            con.execute("CREATE TABLE IF NOT EXISTS daily_currency_costs (account TEXT NOT NULL,day TEXT NOT NULL,currency TEXT NOT NULL,goods TEXT NOT NULL,fees TEXT NOT NULL,other TEXT NOT NULL,basis TEXT NOT NULL DEFAULT '',PRIMARY KEY(account,day,currency))")
    def _row(self,account,day,currency):
        with self.store.connect() as con:
            if currency=='PLN':return con.execute('SELECT goods,fees,other,basis FROM daily_costs WHERE account=? AND day=?',(account,day)).fetchone()
            return con.execute('SELECT goods,fees,other,basis FROM daily_currency_costs WHERE account=? AND day=? AND currency=?',(account,day,currency)).fetchone()
    def get(self,account,day,currency='PLN'):
        row=self._row(account,day,currency)
        return tuple(money(row[k]) for k in ('goods','fees','other')) if row else None
    @staticmethod
    def signature(snapshot):
        lines=sorted((str(line.get('line_id') or ''),int(line['quantity']),str(line['total'])) for line in snapshot.lines)
        raw=[snapshot.day,snapshot.units,str(snapshot.value),lines]
        if snapshot.currency!='PLN':raw.append(snapshot.currency)
        return hashlib.sha256(json.dumps(raw,ensure_ascii=True).encode()).hexdigest()
    def save(self,account,day,goods,fees,other,snapshot=None,currency=None):
        currency=currency or (snapshot.currency if snapshot else 'PLN')
        if not re.fullmatch('[A-Z]{3}',currency):raise ValueError('Nieprawidłowy kod waluty.')
        values=tuple(money(v) for v in (goods,fees,other));basis=self.signature(snapshot) if snapshot else ''
        with self.store.connect() as con:
            if currency=='PLN':con.execute('INSERT OR REPLACE INTO daily_costs(account,day,goods,fees,other,basis) VALUES(?,?,?,?,?,?)',(account,day,*(str(v) for v in values),basis))
            else:con.execute('INSERT OR REPLACE INTO daily_currency_costs VALUES(?,?,?,?,?,?,?)',(account,day,currency,*(str(v) for v in values),basis))
        return values
    def profit(self,snapshot):
        snapshot=currency_snapshot(snapshot,snapshot.currency)
        row=self._row(snapshot.account,snapshot.day,snapshot.currency)
        if row is None or row['basis']!=self.signature(snapshot):return None
        return snapshot.value-sum((money(row[k]) for k in ('goods','fees','other')),ZERO)
