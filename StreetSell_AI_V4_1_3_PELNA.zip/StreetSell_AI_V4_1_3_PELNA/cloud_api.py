"""Supabase REST transport. No passwords or access tokens are written to SQLite."""
import json
import ssl
import time
import urllib.error
import urllib.request
from pathlib import Path

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs):return None

class CloudError(ValueError):
    pass

class Supabase:
    def __init__(self, config, transport=None, vault=None):
        self.url=config['url'].rstrip('/').removesuffix('/rest/v1')
        self.key=config['publishable_key'].strip()
        from urllib.parse import urlsplit
        u=urlsplit(self.url)
        if u.scheme!='https' or not u.hostname or u.username or u.password or u.path or u.query or u.fragment:
            raise CloudError('Podaj adres HTTPS projektu Supabase, bez /rest/v1/.')
        if not self.key or self.key.startswith('sb_secret_'):
            raise CloudError('Użyj klucza publishable/anon, nigdy service_role lub secret.')
        if self.key.count('.')==2:
            import base64
            try:
                claims=json.loads(base64.urlsafe_b64decode(self.key.split('.')[1]+'=='))
                if claims.get('role')=='service_role':raise CloudError('Klucz service_role nie może być używany w aplikacji.')
            except (ValueError, UnicodeError):
                raise CloudError('Nieprawidłowy klucz anon.') from None
        self.transport=transport
        self.vault=vault
        self.session={}
        self.remembered=False
        import hashlib
        self.service='StreetSellAI.Supabase.'+hashlib.sha256(self.url.encode()).hexdigest()[:20]

    def _vault(self):
        if self.vault is not None:return self.vault
        from owner_session import windows_vault
        return windows_vault()

    def request(self, path, data=None, authenticated=True, method=None):
        if authenticated:self.refresh_if_needed()
        headers={'apikey':self.key,'Content-Type':'application/json'}
        if authenticated:headers['Authorization']='Bearer '+self.session['access_token']
        if self.transport:return self.transport(path,data,headers,method)
        try:
            import certifi
            context=ssl.create_default_context(cafile=certifi.where())
        except ImportError:context=ssl.create_default_context()
        req=urllib.request.Request(self.url+path,data=None if data is None else json.dumps(data).encode(),headers=headers,method=method or ('POST' if data is not None else 'GET'))
        try:
            opener=urllib.request.build_opener(urllib.request.HTTPSHandler(context=context),NoRedirect())
            with opener.open(req,timeout=25) as r:
                body=r.read();return json.loads(body) if body else None
        except urllib.error.HTTPError as exc:
            # Never display a response that may contain tokens, passwords or row data.
            if exc.code in (401,403):msg='Brak dostępu. Sprawdź klucz projektu, konto, sesję i polityki RLS.'
            elif exc.code in (400,404):msg='Niezgodna konfiguracja Supabase. Sprawdź migrację V4 i dane logowania.'
            elif exc.code==429:msg='Limit prób. Odczekaj chwilę i spróbuj ponownie.'
            else:msg='Błąd serwera Supabase.'
            raise CloudError(f'{msg} (HTTP {exc.code})') from None
        except (urllib.error.URLError,TimeoutError,OSError,json.JSONDecodeError):
            raise CloudError('Brak połączenia z Supabase. Dane lokalne pozostały zapisane.') from None

    def accept(self, data):
        if not isinstance(data,dict) or not data.get('access_token') or not data.get('refresh_token') or not data.get('user',{}).get('id'):
            raise CloudError('Nieprawidłowa odpowiedź logowania.')
        self.session=dict(data);self.session['expires_at']=time.time()+int(data.get('expires_in',3600))
        if self.remembered:self._vault().set_password(self.service,'refresh',data['refresh_token'])

    @property
    def user_id(self):return self.session.get('user',{}).get('id')

    def login(self,email,password,remember=False):
        self.forget()
        self.session={}
        data=self.request('/auth/v1/token?grant_type=password',{'email':email.strip(),'password':password},False)
        self.accept(data)
        if remember:
            try:self._vault().set_password(self.service,'refresh',self.session['refresh_token']);self.remembered=True
            except Exception:
                self.session={};raise CloudError('Nie udało się zapisać sesji w magazynie Windows. Zaloguj się bez opcji zapamiętywania.') from None
        return self.session['user'].get('email',email)

    def resume(self):
        try:token=self._vault().get_password(self.service,'refresh')
        except Exception:return None
        if not token:return None
        self.remembered=True
        try:
            self.accept(self.request('/auth/v1/token?grant_type=refresh_token',{'refresh_token':token},False))
            return self.session['user'].get('email','Supabase')
        except Exception:
            self.remembered=False;self.session={};return None

    def refresh_if_needed(self):
        if not self.session:raise CloudError('Zaloguj się ponownie do Supabase.')
        if self.session['expires_at']<time.time()+60:
            self.accept(self.request('/auth/v1/token?grant_type=refresh_token',{'refresh_token':self.session['refresh_token']},False))

    def forget(self):
        self.remembered=False
        try:
            vault=self._vault()
            if vault.get_password(self.service,'refresh'):vault.delete_password(self.service,'refresh')
        except Exception as exc:
            # A failed vault deletion must not be presented as a successful logout.
            raise CloudError('Nie udało się usunąć zapisanej sesji z magazynu Windows.') from exc

    def logout(self):
        self.forget()
        try:
            if self.session:self.request('/auth/v1/logout',{},True)
        finally:self.session={}

    def list_rows(self,kind):
        rows=[];offset=0
        while True:
            page=self.request('/rest/v1/rpc/ss_v4_pull',{'p_kind':kind,'p_offset':offset})
            if not isinstance(page,list):raise CloudError('Nieprawidłowa odpowiedź synchronizacji.')
            rows.extend(page)
            if len(page)<200:return rows
            offset+=len(page)

    def push(self,kind,uid,revision,data):
        result=self.request('/rest/v1/rpc/ss_v4_push',{'p_kind':kind,'p_id':uid,'p_expected':revision,'p_data':data})
        if not isinstance(result,dict) or 'ok' not in result:raise CloudError('Nieprawidłowy protokół V4.')
        return result


def load_config(path):
    try:return json.loads(Path(path).read_text(encoding='utf-8'))
    except (OSError,ValueError):return {'url':'','publishable_key':''}
