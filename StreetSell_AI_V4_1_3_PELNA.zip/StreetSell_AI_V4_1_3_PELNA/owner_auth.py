"""Local owner gate. Protects app access, does not encrypt the product database."""
import hashlib,json,os,secrets,tempfile,time
from pathlib import Path

class AuthError(ValueError):pass

def digest(value,salt):
    return hashlib.scrypt(value.encode('utf-8'),salt=bytes.fromhex(salt),n=32768,r=8,p=1,maxmem=64*1024*1024,dklen=32).hex()

def credential(value):
    salt=secrets.token_hex(16)
    return {'salt':salt,'hash':digest(value,salt)}

def valid(value,record):
    return secrets.compare_digest(digest(value,record['salt']),record['hash'])

class OwnerAuth:
    def __init__(self,path):self.path=Path(path)
    def exists(self):return self.path.exists()
    def read(self):
        try:
            data=json.loads(self.path.read_text(encoding='utf-8'))
            if data['version']!=1 or not data['login'] or any(len(data[k]['salt'])!=32 or len(data[k]['hash'])!=64 for k in ('password','recovery')):raise ValueError()
            return data
        except (OSError,ValueError,KeyError,TypeError):raise AuthError('Nie można odczytać konta właściciela. Przywróć owner_auth.json z własnej kopii zapasowej.') from None
    def write(self,data):
        self.path.parent.mkdir(parents=True,exist_ok=True)
        with tempfile.NamedTemporaryFile(mode='w',encoding='utf-8',dir=self.path.parent,delete=False) as f:
            stage=Path(f.name);json.dump(data,f);f.flush();os.fsync(f.fileno())
        try:
            stage.chmod(0o600);stage.replace(self.path)
        finally:stage.unlink(missing_ok=True)
    def check_password(self,password):
        if not 10<=len(password)<=256:raise AuthError('Hasło musi mieć od 10 do 256 znaków.')
    def create(self,login,password):
        if self.exists():raise AuthError('Konto właściciela już istnieje.')
        login=login.strip()
        if not 3<=len(login)<=80:raise AuthError('Login musi mieć od 3 do 80 znaków.')
        self.check_password(password);code=secrets.token_urlsafe(24)
        self.write(dict(version=1,login=login,password=credential(password),recovery=credential(code),failures=0,locked_until=0))
        return code
    def verify(self,login,value,recovery=False,new_password=None):
        data=self.read();now=time.time()
        if data.get('locked_until',0)>now:raise AuthError('Za dużo prób. Spróbuj ponownie za minutę.')
        if not isinstance(value,str) or len(value)>256:raise AuthError('Nieprawidłowe dane logowania.')
        correct=valid(value,data['recovery' if recovery else 'password'])
        if login.strip()!=data['login'] or not correct:
            data['failures']=data.get('failures',0)+1
            if data['failures']>=5:data['locked_until']=now+60;data['failures']=0
            self.write(data);raise AuthError('Nieprawidłowy login lub '+('kod odzyskiwania.' if recovery else 'hasło.'))
        if recovery:
            self.check_password(new_password or '');code=secrets.token_urlsafe(24)
            data['password']=credential(new_password);data['recovery']=credential(code);data.pop('session',None)
        data['failures']=0;data['locked_until']=0;self.write(data)
        return code if recovery else data['login']
