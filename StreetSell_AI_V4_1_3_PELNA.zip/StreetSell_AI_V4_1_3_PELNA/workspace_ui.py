"""StreetSell AI V3.1.0 — panel produktów i edytor ofert."""
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from tkinter import font as tkfont
import core
from storage import STATUSES, CONDITIONS
from photos import Gallery, PhotoError
from PIL import Image, ImageOps, ImageTk
from collections import OrderedDict
from datetime import datetime

BG = '#0d0f14'
SIDEBAR = '#101218'
PANEL = '#171a22'
FIELD = '#20242e'
BORDER = '#292e3a'
TEXT = '#f5f6fa'
MUTED = '#969eaf'
RED = '#f04455'
FONT = 'Segoe UI'

class App(core.App):
    def __init__(self):
        self.photo_importing = False
        self.backup_running = False
        self.thumbnail_cache = OrderedDict()
        self.visible_thumbnails = {}
        super().__init__()
        self.title('StreetSell AI • V3.1.0')
        screen_w, screen_h = self.winfo_screenwidth(), self.winfo_screenheight()
        self.minsize(1080, 650)
        self.geometry(f'{min(1500, screen_w - 40)}x{min(920, screen_h - 55)}')
        self.after_idle(self.initial_layout)

    def integration_info(self):
        from allegro_ui import AllegroDialog
        existing = getattr(self, 'allegro_dialog', None)
        if existing is not None and existing.winfo_exists():
            existing.lift()
            return
        self.allegro_dialog = AllegroDialog(self)

    def close(self):
        editor = getattr(self, 'photo_editor', None)
        if editor is not None and editor.winfo_exists():
            editor.close()
            if editor.winfo_exists():
                return
        internet = getattr(self, 'internet_dialog', None)
        if internet is not None and internet.winfo_exists():
            internet.close()
            if internet.winfo_exists():
                return
        if self.backup_running:
            messagebox.showinfo('Kopia danych', 'Poczekaj na zakończenie tworzenia kopii danych.')
            return
        if self.photo_importing:
            messagebox.showinfo('Trwa import zdjęć', 'Poczekaj na zakończenie importu albo anuluj go w zakładce Zdjęcia.')
            return
        dialog = getattr(self, 'allegro_dialog', None)
        if dialog is not None and dialog.winfo_exists():
            dialog.close()
            if dialog.winfo_exists():
                return
        super().close()

    def destroy(self):
        # Usuń oczekujące odświeżenia podglądów przed zamknięciem interpretera Tk.
        for token in self.tk.call('after', 'info'):
            try:
                script = self.tk.call('after', 'info', token)[0]
                if script in (self._tclCommands or []):
                    self.after_cancel(token)
            except tk.TclError:
                pass
        super().destroy()

    def initial_layout(self):
        self.show_inventory()

    def label(self, parent, text='', size=10, color=TEXT, bold=False, **kw):
        return tk.Label(parent, text=text, bg=parent.cget('bg'), fg=color,
                        font=(FONT, size, 'bold' if bold else 'normal'), **kw)

    def panel(self, parent, **kw):
        return tk.Frame(parent, bg=PANEL, highlightbackground=BORDER, highlightthickness=1, **kw)

    def _build_ui(self):
        self.configure(bg=BG)
        self.gallery = Gallery(self.store)
        self.current_section = 'Magazyn'
        self.current_view = 'inventory'
        self.inventory_heading = 'Magazyn produktów'
        self.setup_style()
        shell = tk.Frame(self, bg=BG)
        shell.pack(fill='both', expand=True)
        side = tk.Frame(shell, bg=SIDEBAR, width=212)
        side.pack(side='left', fill='y');side.pack_propagate(False)
        tk.Frame(shell,bg=BORDER,width=1).pack(side='left',fill='y')
        brand=tk.Frame(side,bg=SIDEBAR);brand.pack(fill='x',padx=22,pady=(28,30))
        self.label(brand,'STREET',size=20,bold=True).pack(anchor='w')
        logo=tk.Frame(brand,bg=SIDEBAR);logo.pack(fill='x')
        self.label(logo,'SELL',size=20,color=RED,bold=True).pack(side='left')
        self.label(logo,' / AI',size=11,color=MUTED).pack(side='left',padx=8)
        self.label(brand,'TWOJE CENTRUM SPRZEDAŻY',size=7,color=MUTED).pack(anchor='w',pady=(9,0))
        self.label(side,'PRZESTRZEŃ ROBOCZA',size=8,color=MUTED,bold=True).pack(anchor='w',padx=22,pady=(0,12))
        self.nav_buttons={}
        for title,mark,command in [('Magazyn','01',self.back_to_inventory),('Karta produktu','02',self.open_product)]:
            btn=tk.Button(side,text=f'{mark}    {title}',anchor='w',bg=SIDEBAR,fg=MUTED,
                activebackground=FIELD,activeforeground=TEXT,font=(FONT,11,'bold'),
                relief='flat',bd=0,padx=16,pady=15,highlightthickness=0,cursor='hand2',command=command)
            btn.pack(fill='x',padx=12,pady=3);self.nav_buttons[title]=btn
        tk.Frame(side,bg=BORDER,height=1).pack(fill='x',padx=22,pady=24)
        self.label(side,'NARZĘDZIA',size=8,color=MUTED,bold=True).pack(anchor='w',padx=22,pady=(0,10))
        for title,command in [('Import palety',self.import_file),('Eksport produktów',self.export_csv),
                              ('Kopia danych',self.backup_db),('Klucz OpenAI',self.configure_key),
                              ('Integracja Allegro',self.integration_info)]:
            tk.Button(side,text=title,command=command,anchor='w',bg=SIDEBAR,fg=MUTED,
                activebackground=FIELD,activeforeground=TEXT,relief='flat',bd=0,
                font=(FONT,10),padx=16,pady=10,highlightthickness=0,cursor='hand2').pack(fill='x',padx=12)
        foot=tk.Frame(side,bg=SIDEBAR);foot.pack(side='bottom',fill='x',padx=22,pady=22)
        self.label(foot,'STREETSELL AI  /  3.1.0',size=8,bold=True).pack(anchor='w')
        self.label(foot,'Oferty pod Twoją kontrolą',size=8,color=MUTED).pack(anchor='w',pady=(6,0))
        body=tk.Frame(shell,bg=BG);body.pack(side='left',fill='both',expand=True,padx=24,pady=20)
        self.top=tk.Frame(body,bg=BG);self.top.pack(fill='x',pady=(0,20))
        headings=tk.Frame(self.top,bg=BG);headings.pack(side='left',fill='x',expand=True)
        self.breadcrumb=self.label(headings,'PRZESTRZEŃ ROBOCZA  /  MAGAZYN',size=8,color=MUTED,bold=True)
        self.breadcrumb.pack(anchor='w',pady=(0,7))
        self.page_title=self.label(headings,'Magazyn produktów',size=25,bold=True);self.page_title.pack(anchor='w')
        self.subtitle=self.label(headings,'Wszystkie produkty. Jedno miejsce do zarządzania.',size=10,color=MUTED)
        self.subtitle.pack(anchor='w',pady=(5,0))
        self.import_top=ttk.Button(self.top,text='+  Importuj paletę',style='Accent.TButton',command=self.import_file)
        self.import_top.pack(side='right')
        self.back_top=ttk.Button(self.top,text='‹  Wróć do magazynu',command=self.back_to_inventory)
        status=tk.Frame(body,bg=BG);status.pack(side='bottom',fill='x',pady=(12,0))
        self.statusbar=self.label(status,'Gotowy. Otwórz produkt dwuklikiem lub przyciskiem „Otwórz kartę”.',size=9,color=MUTED,anchor='w')
        self.statusbar.pack(fill='x')
        self.statusbar.bind('<Configure>',lambda e:self.statusbar.config(wraplength=max(250,e.width-10)))
        self.workspace=tk.Frame(body,bg=BG);self.workspace.pack(fill='both',expand=True)
        self.inventory_page=tk.Frame(self.workspace,bg=BG)
        self.product_page=self.panel(self.workspace)
        cards=tk.Frame(self.inventory_page,bg=BG);cards.pack(fill='x',pady=(0,18))
        self.stat_labels={}
        for i,(key,title,caption) in enumerate([('products','PRODUKTY','pozycje w magazynie'),
                ('quantity','STAN MAGAZYNOWY','sztuki łącznie'),('approved','ZATWIERDZONE','gotowe po Twojej weryfikacji')]):
            cards.columnconfigure(i,weight=1)
            card=self.panel(cards);card.grid(row=0,column=i,sticky='nsew',padx=(0 if i==0 else 12,0))
            inner=tk.Frame(card,bg=PANEL);inner.pack(fill='x',padx=18,pady=13)
            self.label(inner,title,size=8,color=MUTED,bold=True).pack(anchor='w')
            line=tk.Frame(inner,bg=PANEL);line.pack(fill='x',pady=(7,0))
            value=self.label(line,'—',size=25,color=RED if key=='approved' else TEXT,bold=True)
            value.pack(side='left');self.stat_labels[key]=value
            self.label(line,caption,size=8,color=MUTED).pack(side='left',padx=12,pady=(9,0))
        table=self.panel(self.inventory_page);table.pack(fill='both',expand=True)
        self.build_list(table)
        self.build_editor(self.product_page)
        self.inventory_page.pack(fill='both',expand=True)
        self.style_navigation('Magazyn')
        self.bind('<Control-s>',lambda e:self.save_draft() if self.current_view=='product' else None)
        self.bind('<Alt-Left>',lambda e:self.back_to_inventory())
        for sequence in ('<MouseWheel>','<Button-4>','<Button-5>'):
            self.bind_all(sequence,self.scroll_under_pointer,add='+')

    def setup_style(self):
        global FONT
        available={name.casefold():name for name in tkfont.families(self)}
        FONT=next((available[name.casefold()] for name in ('Segoe UI','DejaVu Sans','Nimbus Sans','Nimbus Sans L','Helvetica','Arial') if name.casefold() in available),'Arial')
        for name in ('TkDefaultFont','TkTextFont','TkMenuFont'):
            tkfont.nametofont(name).configure(family=FONT,size=10)
        style = ttk.Style(self)
        style.theme_use('clam')
        style.configure('.', background=PANEL, foreground=TEXT, font=(FONT, 10))
        style.configure('TFrame', background=PANEL)
        style.configure('TLabel', background=PANEL, foreground=TEXT)
        style.configure('TButton', background=FIELD, foreground=TEXT, borderwidth=0,
                        padding=(15, 11), font=(FONT, 10))
        style.map('TButton', background=[('active', '#313644'), ('disabled', '#262833')],
                  foreground=[('disabled', '#747986')])
        style.configure('Accent.TButton', background=RED, font=(FONT, 10, 'bold'))
        style.map('Accent.TButton', background=[('active', '#f95467'), ('disabled', '#642631')])
        style.configure('TEntry', fieldbackground=FIELD, foreground=TEXT, bordercolor=BORDER,
                        insertcolor=TEXT,padding=8,lightcolor=BORDER,darkcolor=BORDER)
        style.configure('TCombobox', fieldbackground=FIELD, background=FIELD, foreground=TEXT,
                        arrowcolor=MUTED,bordercolor=BORDER,padding=6,lightcolor=BORDER,darkcolor=BORDER)
        style.map('TCombobox', fieldbackground=[('readonly', FIELD)], foreground=[('readonly', TEXT)],
                  selectbackground=[('readonly', FIELD)], selectforeground=[('readonly', TEXT)])
        style.configure('Treeview', background=PANEL, fieldbackground=PANEL, foreground=TEXT,
                        rowheight=68,borderwidth=0,lightcolor=BORDER,darkcolor=BORDER,bordercolor=BORDER, font=(FONT, 10))
        style.configure('Treeview.Heading', background=FIELD, foreground=MUTED, relief='flat',
                        padding=(8, 11), font=(FONT, 9))
        style.map('Treeview', background=[('selected', '#552331')], foreground=[('selected', '#ffffff')])
        style.configure('TNotebook',background=PANEL,borderwidth=0,lightcolor=PANEL,darkcolor=PANEL,bordercolor=PANEL)
        style.configure('TNotebook.Tab',lightcolor=BORDER,darkcolor=BORDER,bordercolor=BORDER, background=PANEL, foreground=MUTED, padding=(20, 13),font=(FONT,10,'bold'))
        style.map('TNotebook.Tab', background=[('selected', FIELD),('active','#292d37')], foreground=[('selected', RED)],expand=[('selected',[0,0,0,0])])
        style.configure('TCheckbutton',background=PANEL,foreground=TEXT,padding=7)
        style.map('TCheckbutton',background=[('active',FIELD)],foreground=[('disabled',MUTED)])
        style.configure('Vertical.TScrollbar', background=FIELD, troughcolor=PANEL, borderwidth=0, arrowsize=10)
        style.configure('Horizontal.TScrollbar', background=FIELD, troughcolor=PANEL, borderwidth=0, arrowsize=10)

    def build_list(self, parent):
        header = tk.Frame(parent, bg=PANEL)
        header.pack(fill='x', padx=15, pady=(16, 12))
        self.label(header, 'Lista produktów', size=13, bold=True).pack(side='left')
        ttk.Button(header,text='Otwórz kartę  →',style='Accent.TButton',command=self.open_product).pack(side='right',padx=(12,0))
        self.list_count = self.label(header, '', size=9, color=MUTED)
        self.list_count.pack(side='right')
        search_frame = tk.Frame(parent, bg=PANEL)
        search_frame.pack(fill='x', padx=15)
        self.search_var = tk.StringVar()
        entry = ttk.Entry(search_frame, textvariable=self.search_var)
        entry.pack(side='left', fill='x', expand=True)
        entry.bind('<Return>', lambda e: self.refresh())
        ttk.Button(search_frame, text='Szukaj', command=self.refresh).pack(side='right', padx=(8,0))
        self.label(parent, 'Nazwa, numer SS, ASIN, EAN lub SKU', size=8, color=MUTED).pack(anchor='w', padx=16, pady=(5, 10))
        filters=search_frame
        self.filter_var = tk.StringVar(value='Wszystkie')
        combo = ttk.Combobox(filters, textvariable=self.filter_var, values=('Wszystkie', *STATUSES), state='readonly', width=17)
        combo.pack(side='left',padx=(10,0))
        combo.bind('<<ComboboxSelected>>', lambda e: self.filter_changed())
        ttk.Button(filters,text='Wyczyść',command=self.reset_filters).pack(side='right',padx=(8,0))
        container = tk.Frame(parent, bg=PANEL)
        container.pack(fill='both', expand=True)
        cols = ('number', 'name', 'asin', 'ean', 'qty', 'condition', 'status', 'ai_status')
        self.tree = ttk.Treeview(container, columns=cols, show='tree headings', selectmode='browse',
                                 displaycolumns=('number','name','qty','condition','status','ai_status'))
        self.tree.heading('#0', text='Zdjęcie')
        self.tree.column('#0', width=80, minwidth=80, stretch=False)
        specs = [('Numer', 88), ('Produkt', 320), ('ASIN', 110), ('EAN', 125), ('Szt.', 44),
                 ('Stan', 110), ('Status', 110), ('Analiza AI', 145)]
        for col, (title, width) in zip(cols, specs):
            self.tree.heading(col, text=title)
            self.tree.column(col, width=width, minwidth=40, stretch=col == 'name', anchor='w')
        self.tree.grid(row=0, column=0, sticky='nsew')
        sy = ttk.Scrollbar(container, orient='vertical', command=self.tree.yview)
        sy.grid(row=0, column=1, sticky='ns')
        sx = ttk.Scrollbar(container, orient='horizontal', command=self.tree.xview)
        sx.grid(row=1, column=0, sticky='ew')
        self.tree.configure(yscrollcommand=sy.set, xscrollcommand=sx.set)
        container.columnconfigure(0, weight=1)
        container.rowconfigure(0, weight=1)
        self.tree.bind('<<TreeviewSelect>>', self.on_select)
        self.tree.bind('<Double-Button-1>',self.open_product_event)
        self.tree.bind('<Return>',lambda e:self.open_product())
        self.tree.tag_configure('even', background='#1b1e27')
        self.tree.tag_configure('odd', background=PANEL)
        self.summary = self.label(parent, '', size=9, color=MUTED, anchor='w')
        self.summary.pack(fill='x', padx=15, pady=10)
        self.summary.bind('<Configure>', lambda e: self.summary.config(wraplength=max(200, e.width)))
        self.empty_list = self.label(container, 'Brak produktów dla wybranych filtrów.\nZmień wyszukiwanie lub zaimportuj paletę.',
                                     size=10, color=MUTED, justify='center')

    def build_editor(self, parent):
        self.editor_parent=parent
        self.editor_content=tk.Frame(parent,bg=PANEL)
        frame=self.editor_content
        header=tk.Frame(frame,bg=PANEL);header.pack(fill='x',padx=24,pady=(20,8))
        self.label(header,'KARTA PRODUKTU',size=8,color=RED,bold=True).pack(side='left')
        self.save_label=self.label(header,'',size=9,color=MUTED);self.save_label.pack(side='right')
        self.product_label=self.label(frame,'Wybierz produkt z magazynu',size=17,bold=True,anchor='w',justify='left')
        self.product_label.pack(fill='x',padx=24,pady=(0,5))
        self.product_label.bind('<Configure>',lambda e:self.product_label.config(wraplength=max(250,e.width-4)))
        self.identifiers=self.label(frame,'',size=9,color=MUTED,anchor='w')
        self.identifiers.pack(fill='x',padx=24,pady=(0,16))
        controls=tk.Frame(frame,bg=PANEL);controls.pack(side='bottom',fill='x',padx=24,pady=16)
        ttk.Button(controls,text='Zatwierdź ofertę',style='Accent.TButton',command=self.approve).pack(side='right')
        ttk.Button(controls,text='Zapisz szkic',command=self.save_draft).pack(side='right',padx=10)
        content=tk.Frame(frame,bg=PANEL);content.pack(fill='both',expand=True,padx=24)
        overview_shell=tk.Frame(content,bg=PANEL,width=260);overview_shell.pack(side='right',fill='y',padx=(20,0));overview_shell.pack_propagate(False)
        self.overview_shell=overview_shell
        overview=self.scroll_panel(overview_shell)
        self.label(overview,'PODGLĄD PRODUKTU',size=8,color=MUTED,bold=True).pack(anchor='w',pady=(5,12))
        self.overview_canvas=tk.Canvas(overview,bg=BG,height=190,width=240,highlightthickness=0)
        self.overview_canvas.pack(fill='x')
        self.overview_canvas.bind('<Configure>',self.draw_overview)
        self.overview_source=None;self.overview_image=None
        ttk.Button(overview,text='Zarządzaj zdjęciami  →',command=self.goto_photos).pack(fill='x',pady=(10,18))
        self.label(overview,'CENA SPRZEDAŻY',size=8,color=MUTED,bold=True).pack(anchor='w')
        self.overview_price=self.label(overview,'—',size=26,bold=True);self.overview_price.pack(anchor='w',pady=(5,12))
        self.overview_meta=self.label(overview,'',size=10,color=MUTED,justify='left',anchor='w',wraplength=250)
        self.overview_meta.pack(fill='x',pady=(0,16))
        self.analyze_button=ttk.Button(controls,text='Analizuj produkt AI',style='Accent.TButton',command=self.analyze_selected)
        self.analyze_button.pack(side='left')
        self.label(overview,'Sprawdź wynik analizy przed zatwierdzeniem oferty.',size=9,color=MUTED,justify='left',wraplength=245).pack(anchor='w',pady=(10,0))
        tabs=ttk.Notebook(content);self.editor_tabs=tabs
        tabs.pack(side='left',fill='both',expand=True)
        tabs.bind('<<NotebookTabChanged>>',self.card_tab_changed)
        offer=self.scroll_tab(tabs,'Opis oferty')
        details=self.scroll_tab(tabs,'Dane produktu')
        sources=self.scroll_tab(tabs,'Źródła AI')
        photos=self.scroll_tab(tabs,'Zdjęcia')
        from photo_ui import GalleryPane
        self.photo_pane = GalleryPane(photos, self)
        self.photo_pane.pack(fill='both', expand=True)
        title_head = ttk.Frame(offer)
        title_head.pack(fill='x')
        ttk.Label(title_head, text='Tytuł oferty').pack(side='left')
        self.title_count = ttk.Label(title_head, text='0 znaków', foreground=MUTED)
        self.title_count.pack(side='right')
        self.title_box = self.textbox(offer, 2, expand=False)
        self.title_box.bind('<KeyRelease>', lambda e: self.update_title_count(), add='+')
        desc_head = ttk.Frame(offer, padding=(0, 12, 0, 0))
        desc_head.pack(fill='x')
        ttk.Label(desc_head, text='Opis produktu').pack(side='left')
        self.description_box = self.textbox(offer, 5)
        copy = ttk.Frame(offer, padding=(0, 8, 0, 0))
        copy.pack(fill='x')
        ttk.Button(copy, text='Kopiuj tytuł', command=lambda: self.copy_text(self.title_box)).pack(side='left')
        ttk.Button(copy, text='Kopiuj opis', command=lambda: self.copy_text(self.description_box)).pack(side='right')

        fields = ttk.Frame(details)
        fields.pack(fill='x')
        fields.columnconfigure(0, weight=2)
        fields.columnconfigure(1, weight=1)
        fields.columnconfigure(2, weight=1)
        self.vars = {}
        for i, (name, label, width) in enumerate([('condition', 'Stan produktu', 16), ('quantity', 'Sztuki', 5), ('sale_price', 'Cena (zł)', 9)]):
            ttk.Label(fields, text=label).grid(row=0, column=i, sticky='w', padx=(0, 6), pady=(0, 6))
            var = tk.StringVar()
            self.vars[name] = var
            widget = (ttk.Combobox(fields, textvariable=var, values=CONDITIONS, state='readonly', width=width)
                      if name == 'condition' else ttk.Entry(fields, textvariable=var, width=width))
            widget.grid(row=1, column=i, sticky='ew', padx=(0, 6))
            var.trace_add('write', self.mark_dirty)
            var.trace_add('write', lambda *_: self.update_overview_values())
        ttk.Label(details, text='Zawartość zestawu', padding=(0, 13, 0, 0)).pack(anchor='w')
        self.contents_box = self.textbox(details, 3)
        ttk.Label(details, text='Braki i wady', padding=(0, 10, 0, 0)).pack(anchor='w')
        self.defects_box = self.textbox(details, 3)
        ttk.Label(details, text='Uwzględnij te ustalenia również w opisie oferty.',
                  foreground=MUTED, wraplength=330, padding=(0, 8, 0, 0)).pack(anchor='w')
        for name, label in [('asin', 'ASIN produktu (10 liter lub cyfr)'), ('product_link', 'Link do produktu (HTTPS)')]:
            ttk.Label(sources, text=label).pack(anchor='w', pady=(5,4))
            var = tk.StringVar()
            self.vars[name] = var
            ttk.Entry(sources, textvariable=var).pack(fill='x', pady=(0,8))
            var.trace_add('write', self.mark_dirty)
        ttk.Label(sources, text='Dopasowanie produktu i źródła', padding=(0, 0, 0, 6)).pack(anchor='w')
        self.notes_box = self.textbox(sources, 8)
        ttk.Label(sources, text='Sprawdź dokładny model i wariant. EAN z palety pozostaje bez zmian.',
                  foreground=MUTED, wraplength=330, padding=(0, 10, 0, 0)).pack(anchor='w')
        self.empty_editor = tk.Frame(parent, bg=PANEL)
        badge = tk.Canvas(self.empty_editor, width=70, height=70, bg=PANEL, highlightthickness=0)
        badge.pack(pady=(100, 18))
        badge.create_rectangle(15, 20, 55, 53, outline=RED, width=2)
        badge.create_line(15, 20, 35, 10, 55, 20, fill=RED, width=2)
        badge.create_line(35, 10, 35, 44, fill=RED, width=2)
        self.label(self.empty_editor, 'Wybierz produkt', size=18, bold=True).pack()
        self.label(self.empty_editor, 'Otwórz produkt z osobnej sekcji Magazyn.\nTutaj przygotujesz jego dane, ofertę i zdjęcia.',
                   size=10, color=MUTED, justify='center').pack(pady=12)
        self.set_editor_visible(False)

    def scroll_panel(self,parent):
        canvas=tk.Canvas(parent,bg=PANEL,highlightthickness=0,width=240,height=150)
        scroll=ttk.Scrollbar(parent,orient='vertical',command=canvas.yview)
        scroll.pack(side='right',fill='y');canvas.pack(side='left',fill='both',expand=True)
        canvas.configure(yscrollcommand=scroll.set)
        inner=tk.Frame(canvas,bg=PANEL)
        window=canvas.create_window((0,0),window=inner,anchor='nw')
        def resize(_event=None):
            canvas.itemconfigure(window,width=max(1,canvas.winfo_width()))
            canvas.configure(scrollregion=canvas.bbox('all'))
        inner.bind('<Configure>',resize);canvas.bind('<Configure>',resize)
        inner._scroll_target=canvas;canvas._scroll_target=canvas
        return inner

    def scroll_under_pointer(self,event):
        widget=event.widget
        if widget.winfo_class() in ('Text','Treeview','Listbox','TCombobox'):return
        while widget is not None:
            target=getattr(widget,'_scroll_target',None)
            if target is not None:
                delta=-1 if getattr(event,'num',None)==4 else 1 if getattr(event,'num',None)==5 else (-1 if event.delta>0 else 1)
                target.yview_scroll(delta*3,'units');return 'break'
            widget=getattr(widget,'master',None)

    def scroll_tab(self, notebook, title):
        shell = ttk.Frame(notebook)
        notebook.add(shell, text=title)
        canvas = tk.Canvas(shell, bg=PANEL, highlightthickness=0, width=200, height=180)
        scroll = ttk.Scrollbar(shell, orient='vertical', command=canvas.yview)
        scroll.pack(side='right', fill='y')
        canvas.pack(side='left', fill='both', expand=True)
        canvas.configure(yscrollcommand=scroll.set)
        inner = ttk.Frame(canvas, padding=(0, 10, 4, 6))
        window = canvas.create_window((0, 0), window=inner, anchor='nw')
        def resize(_event=None):
            canvas.itemconfigure(window, width=max(1, canvas.winfo_width()),
                                 height=max(inner.winfo_reqheight(), canvas.winfo_height()))
            canvas.configure(scrollregion=canvas.bbox('all'))
        inner.bind('<Configure>', resize)
        canvas.bind('<Configure>', resize)
        inner._scroll_target=canvas;canvas._scroll_target=canvas
        return inner

    def set_editor_visible(self, visible):
        if visible:
            self.empty_editor.pack_forget()
            self.editor_content.pack(fill='both', expand=True)
        else:
            self.editor_content.pack_forget()
            self.empty_editor.pack(fill='both', expand=True)

    def textbox(self, parent, height, expand=True):
        holder = tk.Frame(parent, bg=FIELD, highlightbackground=BORDER, highlightthickness=1)
        holder.pack(fill='both' if expand else 'x', expand=expand, pady=(5, 0))
        box = tk.Text(holder, height=height, width=12, bg=FIELD, fg=TEXT, insertbackground=TEXT,
                      selectbackground='#652735', relief='flat', wrap='word', padx=11, pady=9,
                      font=(FONT, 10), undo=True, borderwidth=0)
        scrollbar = ttk.Scrollbar(holder, orient='vertical', command=box.yview)
        scrollbar.pack(side='right', fill='y')
        box.pack(side='left', fill='both', expand=True)
        box.configure(yscrollcommand=scrollbar.set)
        box.bind('<<Modified>>', self.text_modified)
        return box

    def style_navigation(self,title):
        for name,button in self.nav_buttons.items():
            active=name==title
            button.configure(bg='#351e29' if active else SIDEBAR,fg=TEXT if active else MUTED)
        self.current_section=title

    def show_inventory(self):
        self.product_page.pack_forget()
        self.inventory_page.pack(fill='both',expand=True)
        self.current_view='inventory';self.style_navigation('Magazyn')
        self.page_title.configure(text='Magazyn produktów')
        self.breadcrumb.configure(text='PRZESTRZEŃ ROBOCZA  /  MAGAZYN')
        self.subtitle.configure(text='Wybierz produkt i otwórz jego kartę, aby przygotować ofertę.')
        self.back_top.pack_forget();self.import_top.pack(side='right')

    def back_to_inventory(self):
        if self.current_view=='product' and not self.confirm_pending():return False
        self.show_inventory()
        self.tree.focus_set()
        return True

    def open_product_event(self,event):
        if self.tree.identify_region(event.x,event.y) not in ('tree','cell'):return
        self.open_product()

    def open_product(self):
        if self.current_view=='product':return True
        selected=self.tree.selection()
        if selected and int(selected[0])!=self.selected_id:self.on_select()
        if self.selected_id is None:
            messagebox.showinfo('Wybierz produkt','Zaznacz produkt w magazynie, a następnie kliknij „Otwórz kartę”.')
            return False
        self.show_product()
        self.inventory_page.pack_forget();self.product_page.pack(fill='both',expand=True)
        self.current_view='product';self.style_navigation('Karta produktu')
        self.page_title.configure(text='Karta produktu')
        self.breadcrumb.configure(text=f'MAGAZYN  /  SS-{self.selected_id:05d}')
        self.subtitle.configure(text='Dane, oferta i zdjęcia wybranego produktu.')
        self.import_top.pack_forget();self.back_top.pack(side='right')
        return True

    def navigate(self,title,status):
        if not self.confirm_pending():return
        self.filter_var.set(status);self.search_var.set('')
        self.selected_id=None;self.clear_detail();self.load_db();self.show_inventory()

    def filter_changed(self):
        if not self.confirm_pending():
            self.filter_var.set(getattr(self,'applied_filter','Wszystkie'));return
        self.applied_filter=self.filter_var.get();self.refresh()

    def reset_filters(self):self.navigate('Magazyn','Wszystkie')

    def card_tab_changed(self,_event=None):
        if self.editor_tabs.index('current')==3:
            self.overview_shell.pack_forget()
        elif not self.overview_shell.winfo_manager():
            self.overview_shell.pack(side='right',fill='y',padx=(20,0),before=self.editor_tabs)

    def goto_photos(self):self.editor_tabs.select(3)

    def update_overview_values(self):
        if not hasattr(self,'overview_price'):return
        price=self.vars.get('sale_price')
        value=price.get().strip() if price else ''
        self.overview_price.configure(text=(value+' zł') if value else '—')
        qty=self.vars.get('quantity');condition=self.vars.get('condition')
        self.overview_meta.configure(text=f"Stan: {condition.get() if condition and condition.get() else '—'}\nIlość: {qty.get() if qty and qty.get() else '—'} szt.")

    def load_overview(self):
        if self.overview_source is not None:self.overview_source.close()
        self.overview_source=None
        rows=self.gallery.photos(self.selected_id) if self.selected_id else []
        if rows:
            try:self.overview_source=self.gallery.preview(rows[0])
            except (PhotoError,OSError):pass
        self.draw_overview();self.update_overview_values()

    def draw_overview(self,_event=None):
        if not hasattr(self,'overview_canvas'):return
        canvas=self.overview_canvas;canvas.delete('all')
        if self.overview_source is None:
            self.overview_image=None
            canvas.create_text(max(1,canvas.winfo_width())/2,95,text='Brak zdjęcia głównego',fill=MUTED,font=(FONT,10))
        else:
            im=ImageOps.contain(self.overview_source,(max(1,canvas.winfo_width()-18),172),Image.Resampling.LANCZOS)
            self.overview_image=ImageTk.PhotoImage(im,master=self)
            canvas.create_image(canvas.winfo_width()/2,95,image=self.overview_image)

    def load_db(self):
        super().load_db()
        self.applied_filter = self.filter_var.get()
        rows = self.store.products()
        self.stat_labels['products'].config(text=str(len(rows)))
        self.stat_labels['quantity'].config(text=str(sum(r['quantity'] or 0 for r in rows)))
        self.stat_labels['approved'].config(text=str(sum(r['status'] == 'Zatwierdzony' for r in rows)))
        ids = self.tree.get_children()
        main_photos = self.gallery.main_photos()
        self.visible_thumbnails = {}
        for i, iid in enumerate(ids):
            self.tree.item(iid, tags=('even' if i % 2 == 0 else 'odd',))
            photo = main_photos.get(int(iid))
            if photo:
                try:
                    key = photo['relative_path']
                    image = self.thumbnail_cache.get(key)
                    if image is None:
                        original = self.gallery.thumbnail(photo)
                        original.thumbnail((48, 48), Image.Resampling.LANCZOS)
                        image = ImageTk.PhotoImage(original, master=self)
                        self.thumbnail_cache[key] = image
                        if len(self.thumbnail_cache) > 256:
                            self.thumbnail_cache.popitem(last=False)
                    self.visible_thumbnails[iid] = image
                    self.tree.item(iid, image=image)
                except (PhotoError, OSError, ValueError):
                    pass
        self.list_count.config(text=f'{len(ids)} pozycji')
        self.empty_list.place_forget()
        if not ids:
            self.empty_list.place(relx=.5, rely=.45, anchor='center')

    def show_product(self):
        super().show_product()
        row = self.store.get(self.selected_id)
        if row:
            self.identifiers.config(text=f"ASIN: {row['asin'] or '—'}   •   EAN: {row['ean'] or '—'}")
            self.product_label.config(text=f"SS-{row['id']:05d}  |  {(row['product_name'] or '')[:100]}")
            self.update_title_count()
            self.set_editor_visible(True)
            self.photo_pane.set_product(self.selected_id)
            self.load_overview()

    def save_draft(self, approved=False):
        saved = super().save_draft(approved)
        if saved:
            row = self.store.get(self.selected_id)
            self.identifiers.config(text=f"ASIN: {row['asin'] or '—'}   •   EAN: {row['ean'] or '—'}")
            self.update_overview_values()
        return saved

    def clear_detail(self):
        super().clear_detail()
        self.identifiers.config(text='')
        self.update_title_count()
        self.set_editor_visible(False)
        self.photo_pane.set_product(None)
        self.load_overview()

    def photos_changed(self, product_id):
        self.load_db()
        if self.selected_id == product_id:
            self.photo_pane.reload()
            self.load_overview()
            if not self.dirty:
                row = self.store.get(product_id)
                self.save_label.config(text=row['status'])

    def backup_db(self):
        if self.backup_running:
            messagebox.showinfo('Kopia danych', 'Tworzenie kopii już trwa.')
            return
        if self.photo_importing:
            messagebox.showinfo('Trwa import', 'Poczekaj na zakończenie importu zdjęć przed wykonaniem kopii.')
            return
        if not self.confirm_pending():
            return
        path = filedialog.asksaveasfilename(title='Pełna kopia bazy i zdjęć',
            initialfile=f'streetsell_kopia_{datetime.now():%Y%m%d_%H%M%S}.zip',
            defaultextension='.zip', filetypes=[('Kopia danych i zdjęć ZIP', '*.zip')])
        if path:
            import threading
            self.backup_running = True
            self.statusbar.config(text='Tworzę kopię ZIP bazy i zdjęć…')
            def worker():
                try:
                    self.gallery.backup_zip(path)
                    self.events.put((self.backup_done, (None,)))
                except Exception as exc:
                    self.events.put((self.backup_done, (str(exc),)))
            threading.Thread(target=worker, daemon=True).start()

    def backup_done(self, error):
        self.backup_running = False
        if error:
            self.statusbar.config(text='Nie udało się zapisać kopii danych.')
            messagebox.showerror('Błąd kopii', error)
        else:
            self.statusbar.config(text='Zapisano pełną kopię bazy i zdjęć.')
            messagebox.showinfo('Kopia gotowa', 'Zapisano bazę produktów i przypisane zdjęcia. Poświadczenia kont pozostają w magazynie Windows.')

    def update_title_count(self):
        self.title_count.config(text=f"{len(self.title_box.get('1.0', 'end-1c'))} znaków")

if __name__ == '__main__':
    App().mainloop()
