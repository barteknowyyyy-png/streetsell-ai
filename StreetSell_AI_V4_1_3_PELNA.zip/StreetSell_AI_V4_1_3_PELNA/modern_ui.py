"""Docelowy interfejs StreetSell: zaokrąglone panele, galeria i pasek dnia."""
import tkinter as tk
from tkinter import ttk,messagebox,simpledialog,font as tkfont
from pathlib import Path
import re,threading
from datetime import datetime,timezone
import customtkinter as ctk
from PIL import Image,ImageDraw,ImageTk
import workspace_ui as previous
from workspace_ui import App as WorkspaceApp
from photos import Gallery,PhotoError
from photo_ui import GalleryPane
from storage import STATUSES,CONDITIONS
from exchange_rates import ExchangeRates,RateError,CombinedCosts,combined_snapshot,combined_profit
from orders import OrdersService,PERIODS,daily_from_orders,today_overview,matches
from orders_ui import OrdersPanel
import inventory_sync
import pallet_manager
from page_scroll import WholePage,GrowText,PAGE_SIZE
from ui_performance import visible_rows
from fixed_workspace import FixedPage
from daily_sales import DailyCosts,today_bounds,pln,money,amount

BG='#0b0e13';SIDE='#0e1117';PANEL='#141820';FIELD='#1b202a';BORDER='#272e3a';TEXT='#f4f6fa';MUTED='#96a0b1';RED='#f3344e'

class Label(ctk.CTkLabel):
    def config(self,**kw):
        if 'fg' in kw:kw['text_color']=kw.pop('fg')
        return self.configure(**kw)

class Button(ctk.CTkButton):
    def __init__(self,parent,text,command=None,primary=False,**kw):
        super().__init__(parent,text=text,command=command,height=44,corner_radius=14,
            fg_color=RED if primary else FIELD,hover_color='#d9233d' if primary else '#272e3b',
            text_color=TEXT,border_width=0 if primary else 1,border_color=BORDER,**kw)
    def state(self,states=None):
        if states is not None:
            self.configure(state='disabled' if 'disabled' in states else 'normal')
        return ('disabled',) if self.cget('state')=='disabled' else ()
    def config(self,**kw):return self.configure(**kw)

class Tabs(ctk.CTkTabview):
    def __init__(self,parent,**kw):
        super().__init__(parent,fg_color=PANEL,corner_radius=10,
            segmented_button_fg_color=PANEL,segmented_button_unselected_color=PANEL,
            segmented_button_unselected_hover_color=FIELD,segmented_button_selected_color='#41202b',
            segmented_button_selected_hover_color='#512333',text_color=TEXT,anchor='nw',**kw)
        self.names=[]
    def add(self,name):self.names.append(name);return super().add(name)
    def select(self,index=None):
        if index is None:return self.get()
        self.set(self.names[index] if isinstance(index,int) else index)
    def index(self,name):return self.names.index(self.get() if name=='current' else name)


def icon(name,color=TEXT,size=20):
    im=Image.new('RGBA',(64,64));d=ImageDraw.Draw(im);w=4
    def line(points):d.line(points,fill=color,width=w,joint='curve')
    def rect(box):d.rounded_rectangle(box,radius=4,outline=color,width=w)
    if name=='box':
        line([(10,22),(32,10),(54,22),(54,47),(32,59),(10,47),(10,22),(32,34),(54,22)])
        line([(32,34),(32,59),(32,34),(10,22)]);line([(22,16),(44,28)])
    elif name=='doc':
        line([(15,7),(39,7),(51,20),(51,57),(15,57),(15,7)]);line([(38,7),(38,22),(51,22)])
        for y in (32,41,49):line([(24,y),(43,y)])
    elif name=='cart':line([(6,12),(15,12),(22,42),(50,42),(57,22),(18,22)]);d.ellipse((23,49,29,55),fill=color);d.ellipse((44,49,50,55),fill=color)
    elif name=='truck':rect((5,19,37,45));line([(37,27),(48,27),(58,37),(58,46),(37,46)]);d.ellipse((14,41,26,53),fill=PANEL,outline=color,width=w);d.ellipse((43,41,55,53),fill=PANEL,outline=color,width=w)
    elif name=='search':d.ellipse((10,8,43,41),outline=color,width=w);line([(40,39),(57,56)])
    elif name=='photo':rect((7,12,57,53));d.ellipse((39,20,46,27),fill=color);line([(9,45),(24,28),(36,40),(44,32),(56,47)])
    elif name=='gear':
        d.ellipse((15,15,49,49),outline=color,width=w);d.ellipse((26,26,38,38),outline=color,width=w)
        for x,y,xx,yy in ((32,6,32,17),(32,47,32,58),(6,32,17,32),(47,32,58,32),(13,13,20,20),(44,44,51,51),(13,51,20,44),(44,20,51,13)):line([(x,y),(xx,yy)])
    elif name=='money':rect((7,16,57,49));d.ellipse((25,23,39,41),outline=color,width=w);line([(13,25),(18,25)]);line([(46,40),(51,40)])
    elif name=='trend':line([(8,48),(25,31),(36,39),(56,14),(40,14)]);line([(56,14),(56,30)])
    elif name=='refresh':d.arc((10,10,54,54),30,310,fill=color,width=w);line([(53,16),(54,32),(41,29)])
    return ctk.CTkImage(im,im,size=(size,size))

class ModernGallery(GalleryPane):
    def __init__(self,parent,app):
        ttk.Frame.__init__(self,parent)
        self.app=app;self.gallery=app.gallery;self.product_id=None;self.selected_photo=None
        self.rows=[];self.images=[];self.preview_source=None;self.preview_image=None;self.resize_job=None;self.cancel=threading.Event()
        self.header=Label(self,text='Galeria produktu',font=ctk.CTkFont(size=14,weight='bold'),text_color=TEXT,height=20)
        self.header.pack(anchor='w',pady=(0,8))
        media=ctk.CTkFrame(self,fg_color='transparent');media.pack(fill='x')
        rail=ctk.CTkFrame(media,fg_color='transparent',width=96);rail.pack(side='left',fill='y',padx=(0,10))
        self.strip=tk.Canvas(rail,bg=PANEL,highlightthickness=0,height=280,width=86)
        self.strip._wheel_target=self.strip
        self.strip.pack(side='left',fill='y')
        scroll=ctk.CTkScrollbar(rail,orientation='vertical',width=10,command=self.strip.yview,fg_color=PANEL,button_color=BORDER)
        scroll.pack(side='right',fill='y');self.strip.configure(yscrollcommand=scroll.set)
        cover=ctk.CTkFrame(media,fg_color='#ffffff',corner_radius=12)
        cover.pack(side='left',fill='both',expand=True)
        self.preview_canvas=tk.Canvas(cover,bg='white',height=480,width=360,highlightthickness=0)
        self.preview_canvas.pack(fill='x',padx=9,pady=9)
        self.preview_canvas.bind('<Configure>',self.resize_large_preview);self.preview_canvas.bind('<Double-Button-1>',self.full_preview)
        self.zoom_button=Button(self,'Powiększ zdjęcie',self.full_preview,width=140,font=ctk.CTkFont(size=14))
        self.zoom_button.pack(anchor='e',pady=(5,0))
        self.caption=Label(self,text='Dodaj zdjęcia produktu',text_color=MUTED,wraplength=320,font=ctk.CTkFont(size=14),height=16)
        self.caption.pack(anchor='w',pady=(3,2))
        actions=ctk.CTkFrame(self,fg_color='transparent');actions.pack(fill='x',pady=(5,6))
        self.buttons={}
        for i,(title,action) in enumerate((('Główne','main'),('<','left'),('>','right'),('Usuń','remove'))):
            actions.columnconfigure(i,weight=1)
            b=Button(actions,title,lambda a=action:self.mutate(a),width=50,font=ctk.CTkFont(size=14))
            b.configure(height=28);b.grid(row=0,column=i,sticky='ew',padx=2);self.buttons[action]=b
        row=ctk.CTkFrame(self,fg_color='transparent');row.pack(fill='x',pady=3)
        row.columnconfigure((0,1),weight=1)
        self.add_button=Button(row,'Dodaj zdjęcia',self.add,image=icon('photo',size=16),width=110,font=ctk.CTkFont(size=14))
        self.add_button.grid(row=0,column=0,sticky='ew',padx=(0,3))
        self.online_button=Button(row,'Pobierz z internetu',self.open_internet,width=120,font=ctk.CTkFont(size=14))
        self.online_button.grid(row=0,column=1,sticky='ew',padx=(3,0))
        self.prepare_button=Button(self,'Białe tło i margines',self.open_editor,primary=True,font=ctk.CTkFont(size=14))
        self.prepare_button.pack(fill='x',pady=5)
        row=ctk.CTkFrame(self,fg_color='transparent');row.pack(fill='x',pady=3)
        row.columnconfigure((0,1),weight=1)
        self.export_button=Button(row,'Eksportuj zdjęcia',self.export,width=105,font=ctk.CTkFont(size=14))
        self.export_button.configure(height=28)
        self.export_button.grid(row=0,column=0,sticky='ew',padx=(0,3))
        self.source_button=Button(row,'Źródło zdjęcia',self.open_source,width=105,font=ctk.CTkFont(size=14),state='disabled')
        self.source_button.configure(height=28)
        self.source_button.grid(row=0,column=1,sticky='ew',padx=(3,0))
        row=ctk.CTkFrame(self,fg_color='transparent');row.pack(fill='x',pady=3)
        row.columnconfigure((0,1),weight=1)
        self.translate_button=Button(row,'Napisy → polski',self.open_localize,width=105,font=ctk.CTkFont(size=14))
        self.translate_button.configure(height=28);self.translate_button.grid(row=0,column=0,sticky='ew',padx=(0,3))
        self.original_button=Button(row,'Oryginał przed PL',self.open_original,width=105,font=ctk.CTkFont(size=14),state='disabled')
        self.original_button.configure(height=28);self.original_button.grid(row=0,column=1,sticky='ew',padx=(3,0))
        self.info=Label(self,text='Kopie PL: oryginały dostępne do porównania.',text_color=MUTED,font=ctk.CTkFont(size=14));self.info.pack(anchor='w',pady=3)
        self.import_cancel=Button(self,'Anuluj import',self.cancel.set)

    def draw_strip(self):
        self.strip.delete('all');self.images=[]
        for index,row in enumerate(self.rows):
            y=index*88;tag=f"photo-{row['id']}"
            self.strip.create_rectangle(2,y+2,82,y+83,fill=FIELD,outline=RED if row['id']==self.selected_photo else BORDER,width=2,tags=(tag,))
            try:
                im=self.gallery.thumbnail(row);im.thumbnail((70,55),Image.Resampling.LANCZOS)
                picture=ImageTk.PhotoImage(im,master=self);im.close();self.images.append(picture)
                self.strip.create_image(42,y+32,image=picture,tags=(tag,))
            except (PhotoError,OSError,ValueError):self.strip.create_text(42,y+32,text='Brak pliku',fill=MUTED,tags=(tag,))
            self.strip.create_text(42,y+70,text='GŁÓWNE' if index==0 else str(index+1),fill=RED if index==0 else MUTED,font=(previous.FONT,8),tags=(tag,))
            self.strip.tag_bind(tag,'<Button-1>',lambda e,pid=row['id']:self.select_photo(pid))
            self.strip.tag_bind(tag,'<Double-Button-1>',lambda e,pid=row['id']:self.open_photo(pid))
        self.strip.configure(scrollregion=(0,0,86,max(1,len(self.rows)*88)))

    def set_product(self,product_id):
        if product_id!=self.product_id:self.strip.yview_moveto(0)
        super().set_product(product_id)

    def resize_large_preview(self,event):
        geometry=(event.width,event.height)
        if geometry==getattr(self,'_large_preview_geometry',None):return
        self._large_preview_geometry=geometry
        height=max(360,min(560,event.width))
        if self.preview_canvas.winfo_reqheight()!=height:self.preview_canvas.configure(height=height)
        self.schedule_preview(event)

    def button_states(self):
        super().button_states()
        self.zoom_button.state(['!disabled' if self.selected_photo is not None else 'disabled'])

    def reload(self):
        super().reload()
        self.header.configure(text=f'Galeria produktu ({len(self.rows)})')

    def load_preview(self):
        super().load_preview()
        row=next((r for r in self.rows if r['id']==self.selected_photo),None)
        if row:
            index=next(i for i,r in enumerate(self.rows) if r['id']==row['id'])
            self.caption.configure(text=f"{index+1}/{len(self.rows)} | {row['width']} x {row['height']} px"+(' | Główne' if index==0 else ''))

class App(WorkspaceApp):
    def __init__(self):
        self.orders_running=False;self.sync_generation=0;self.daily_overview=None;self.stats_expanded_on_product=False;self.rate_book=None;self.rate_error="";self.rates_running=False
        self.snapshot=None;self.sales_running=False;self.sales_error='Połącz konto, aby pobrać dane'
        super().__init__()
        self.title('StreetSell AI • V3.8.0')
        inventory_sync.setup(self.store)
        self.minsize(1080,700)
        try:self.state('zoomed')
        except tk.TclError:pass
        self.bind('<F11>',lambda e:self.attributes('-fullscreen',not self.attributes('-fullscreen')))
        self.bind('<Escape>',lambda e:self.attributes('-fullscreen',False))
        self.costs=DailyCosts(self.store);self.total_costs=CombinedCosts(self.store);self.fx_service=ExchangeRates(self.store);self.orders_service=OrdersService(self.store)
        self._offer_prices_running=False
        self.after(15000,self.auto_offer_prices)
        self.after(1200,self.sync_sales)
        self.after(300000,self.auto_sync)
        self.after(60000,self.auto_rates)
        self.day_key=today_bounds()[0];self.after(30000,self.day_watch)

    def _build_ui(self):
        ctk.set_appearance_mode('dark');ctk.set_default_color_theme('dark-blue');ctk.set_widget_scaling(1)
        self.configure(bg=BG);self.gallery=Gallery(self.store)
        self.current_view='inventory';self.current_section='Magazyn';self.setup_style()
        # Renderowanie wektorowe nie zależy od instalacji czcionki kształtów.
        ctk.DrawEngine.preferred_drawing_method='polygon_shapes'
        ctk.ThemeManager.theme['CTkFont']['family']=previous.FONT
        self.option_add('*Font',(previous.FONT,12))
        ctk.ThemeManager.theme['CTkFont']['size']=16
        style=ttk.Style(self)
        style.configure('.',font=(previous.FONT,12))
        style.configure('TButton',font=(previous.FONT,12))
        style.configure('TLabel',font=(previous.FONT,12))
        style.configure('Treeview',font=(previous.FONT,13),rowheight=48)
        style.configure('Treeview.Heading',font=(previous.FONT,12,'bold'),padding=(8,10))
        shell=ctk.CTkFrame(self,fg_color=BG,corner_radius=0);shell.pack(fill='both',expand=True)
        side=ctk.CTkFrame(shell,fg_color=SIDE,width=205,corner_radius=0);side.pack(side='left',fill='y');side.pack_propagate(False)
        brand=ctk.CTkFrame(side,fg_color='transparent');brand.pack(fill='x',padx=20,pady=(26,24))
        try:
            with Image.open(Path(__file__).with_name('brand_ss.png')) as source:self.brand_source=source.convert('RGB')
            self.brand_mark=ctk.CTkImage(self.brand_source,self.brand_source,size=(48,48))
            Label(brand,text='',image=self.brand_mark,width=48,height=48).pack(side='left',padx=(0,10))
            self.window_icon=ImageTk.PhotoImage(self.brand_source.resize((64,64),Image.Resampling.LANCZOS),master=self)
            self.iconphoto(True,self.window_icon)
            from branding import apply_icon
            apply_icon(self)
        except OSError:
            Label(brand,text='SS',text_color=RED,font=ctk.CTkFont(size=30,weight='bold')).pack(side='left',padx=(0,10))
        words=ctk.CTkFrame(brand,fg_color='transparent');words.pack(side='left')
        Label(words,text='STREETSELL AI',font=ctk.CTkFont(size=15,weight='bold'),text_color=TEXT).pack(anchor='w')
        Label(words,text='PANEL SPRZEDAŻY',font=ctk.CTkFont(size=14),text_color=MUTED).pack(anchor='w')
        self.nav_buttons={}
        for title,kind,command in [('Magazyn','box',self.back_to_inventory),('Karta produktu','doc',self.open_product),('Zamówienia','cart',self.open_orders),('Allegro','doc',self.integration_info)]:
            b=Button(side,title,command,image=icon(kind),anchor='w',font=ctk.CTkFont(size=14),width=175)
            b.pack(fill='x',padx=13,pady=5);self.nav_buttons[title]=b
        foot=ctk.CTkFrame(side,fg_color='transparent');foot.pack(side='bottom',fill='x',padx=13,pady=20)
        Button(foot,'Wyloguj',self.logout,anchor='w').pack(fill='x',pady=(0,8))
        Button(foot,'Ustawienia',self.settings,image=icon('gear'),anchor='w').pack(fill='x',pady=(0,12))
        self.owner_label=Label(foot,text='Właściciel',font=ctk.CTkFont(size=13,weight='bold'),text_color=TEXT);self.owner_label.pack(anchor='w',padx=10)
        Label(foot,text='V4.1.3  ·  Twoja przestrzeń',font=ctk.CTkFont(size=14),text_color=MUTED).pack(anchor='w',padx=10)
        self.page_scroll=FixedPage(shell,self);self.page_scroll.pack(side='left',fill='both',expand=True,padx=10,pady=6)
        body=self.page_scroll.content
        self.stats_host=ctk.CTkFrame(body,fg_color='transparent');self.stats_host.pack(fill='x')
        self.build_daily_strip(self.stats_host)
        self.compact_stats=ctk.CTkFrame(body,fg_color=PANEL,corner_radius=16)
        self.compact_values={}
        for key in ('units','value','shipping'):
            label=Label(self.compact_stats,text='--',text_color=RED if key=='shipping' else TEXT,font=ctk.CTkFont(size=14,weight='bold'),anchor='w')
            label.pack(side='left',fill='x',expand=True,padx=12,pady=6);self.compact_values[key]=label
        stats_button=Button(self.compact_stats,'Statystyki',self.toggle_product_stats,width=115,font=ctk.CTkFont(size=14))
        stats_button.configure(height=30);stats_button.pack(side='right',padx=8,pady=3)
        self.top=ctk.CTkFrame(body,fg_color='transparent');self.top.pack(fill='x',pady=(4,4))
        headings=ctk.CTkFrame(self.top,fg_color='transparent');headings.pack(side='left',fill='x',expand=True)
        self.title_wrap_width=0
        headings.bind('<Configure>',self.fit_page_title)
        self.breadcrumb=Label(headings,text='Przestrzeń robocza / Magazyn',text_color=MUTED,font=ctk.CTkFont(size=14));self.breadcrumb.pack(anchor='w')
        self.page_title=Label(headings,text='Magazyn produktów',text_color=TEXT,font=ctk.CTkFont(size=26,weight='bold'));self.page_title.pack(anchor='w',pady=(3,0))
        self.subtitle=Label(headings,text='Zarządzaj towarem i przygotuj produkty do sprzedaży.',text_color=MUTED,font=ctk.CTkFont(size=14));self.subtitle.pack(anchor='w')
        self.breadcrumb.pack_forget();self.subtitle.pack_forget()
        self.import_top=Button(self.top,'Importuj paletę',self.import_file,width=130)
        self.import_top.pack(side='right',padx=5)
        self.add_product_top=Button(self.top,'+ Dodaj produkt',self.add_product,primary=True,width=140)
        self.add_product_top.pack(side='right',padx=5)
        self.back_top=Button(self.top,'< Wróć do magazynu',self.back_to_inventory,width=160)
        footer=ctk.CTkFrame(body,fg_color='transparent');footer.pack(side='bottom',fill='x',pady=(8,0))
        self.statusbar=Label(footer,text='Gotowy. Otwórz produkt dwuklikiem.',text_color=MUTED,font=ctk.CTkFont(size=14),anchor='w');self.statusbar.pack(fill='x')
        self.status_wrap_width=0
        footer.bind('<Configure>',self.fit_status)
        self.workspace=ctk.CTkFrame(body,fg_color='transparent');self.workspace.pack(fill='both',expand=True)
        self.inventory_page=ctk.CTkFrame(self.workspace,fg_color='transparent')
        self.product_page=ctk.CTkFrame(self.workspace,fg_color='transparent')
        self.orders_page=OrdersPanel(self.workspace,self)
        self.build_inventory(self.inventory_page);self.build_product(self.product_page)
        self.inventory_page.pack(fill='both',expand=True);self.style_navigation('Magazyn')
        self.bind('<Control-s>',lambda e:self.save_draft() if self.current_view=='product' else None)
        self.bind('<Alt-Left>',lambda e:self.back_to_inventory())

    def fit_page_title(self,event):
        width=max(240,event.width-12)
        if width!=self.title_wrap_width:
            self.title_wrap_width=width;self.page_title.configure(wraplength=width,justify='left',anchor='w')

    def fit_status(self,event):
        width=max(200,event.width-10)
        if width!=self.status_wrap_width:
            self.status_wrap_width=width;self.statusbar.configure(wraplength=width)

    def build_daily_strip(self,parent):
        head=ctk.CTkFrame(parent,fg_color='transparent');head.pack(fill='x',pady=(0,7))
        self.day_label=Label(head,text='DZISIAJ  ·  '+today_bounds()[0]+'  ·  ALLEGRO',text_color=MUTED,font=ctk.CTkFont(size=14,weight='bold'));self.day_label.pack(side='left')
        self.cost_button=Button(head,'Statystyki i koszty',self.show_sales_details,width=140,font=ctk.CTkFont(size=14));self.cost_button.pack(side='right',padx=(8,0))
        self.sync_button=Button(head,'Odśwież',self.sync_sales,width=92,image=icon('refresh',size=14),font=ctk.CTkFont(size=14));self.sync_button.pack(side='right')
        self.sync_hint=Label(head,text='Dane sprzedaży nie zostały jeszcze pobrane',text_color=MUTED,font=ctk.CTkFont(size=14));self.sync_hint.pack(side='right',padx=12)
        cards=ctk.CTkFrame(parent,fg_color='transparent');cards.pack(fill='x');cards.columnconfigure((0,1,2),weight=1)
        self.daily_values={};self.daily_notes={}
        for col,(key,title,kind,note) in enumerate((('units','Sprzedane dziś','cart','potwierdzone sztuki'),('value','Wartość sprzedaży dziś','money','produkty, bez dostawy'),('shipping','Do wysłania','truck','w wybranym okresie zamówień'))):
            card=ctk.CTkFrame(cards,fg_color=PANEL,corner_radius=20,border_width=1,border_color=BORDER)
            card.grid(row=0,column=col,sticky='nsew',padx=(0 if col==0 else 12,0))
            Label(card,text='  '+title,image=icon(kind,MUTED,18),compound='left',anchor='w',text_color=MUTED,font=ctk.CTkFont(size=14)).pack(fill='x',padx=16,pady=(12,0))
            self.daily_values[key]=Label(card,text='--',text_color=RED if key=='shipping' else TEXT,font=ctk.CTkFont(size=26,weight='bold'),anchor='w')
            self.daily_values[key].pack(fill='x',padx=16,pady=(2,0))
            self.daily_notes[key]=Label(card,text=note,text_color=MUTED,font=ctk.CTkFont(size=14),anchor='w')
            self.daily_notes[key].pack(fill='x',padx=16,pady=(0,11))
            if key=='shipping':
                for widget in (card,*card.winfo_children()):widget.bind('<Button-1>',lambda e:self.open_pending_orders())
        self.metrics_frame=cards
        self.daily_feedback=Label(parent,text='Oczekuję na synchronizację dzisiejszych zamówień.',text_color=MUTED,font=ctk.CTkFont(size=14),anchor='w',justify='left',wraplength=780)
        self.daily_feedback.pack(fill='x',pady=(6,0))

    def build_inventory(self,parent):
        tools=ctk.CTkFrame(parent,fg_color='transparent');tools.pack(fill='x',pady=(0,5))
        self.search_var=tk.StringVar();self.filter_var=tk.StringVar(value='Wszystkie')
        self.search_entry=ctk.CTkEntry(tools,textvariable=self.search_var,placeholder_text='Szukaj produktu, ASIN lub numeru SS…',height=40,corner_radius=10,fg_color=FIELD,border_color=BORDER)
        self.search_entry.pack(side='left',fill='x',expand=True);self.search_entry.bind('<Return>',lambda e:self.refresh())
        Button(tools,'Szukaj',self.refresh,width=76,image=icon('search',size=15)).pack(side='left',padx=8)
        self.filter_menu=ctk.CTkOptionMenu(tools,values=['Wszystkie',*STATUSES],variable=self.filter_var,command=lambda _:self.filter_changed(),width=160,height=38,fg_color=FIELD,button_color=BORDER,button_hover_color='#39404e')
        self.filter_menu.pack(side='left')
        Button(tools,'Wyczyść',self.reset_filters,width=80).pack(side='left',padx=(8,0))
        Button(tools,'Analiza grupowa ▾',self.toggle_bulk_tools,width=155).pack(side='left',padx=(6,0))
        for control in tools.winfo_children():
            if isinstance(control,Button):control.configure(height=32)
        bulk=ctk.CTkFrame(parent,fg_color='transparent');self.bulk_tools=bulk
        Button(bulk,'Zaznacz wszystkie produkty',self.select_all_products,width=225).pack(side='left',padx=(0,8))
        Button(bulk,'Analizuj zaznaczone AI',self.start_bulk_analysis,width=195,primary=True).pack(side='left',padx=(0,8))
        Button(bulk,'Przerwij analizę',self.stop_bulk_analysis,width=145).pack(side='left',padx=(0,8))
        Button(bulk,'Odznacz wszystkie',self.clear_bulk_selection,width=175).pack(side='left')
        self.bulk_count=Label(bulk,text='Zaznaczono: 0',text_color=MUTED,font=ctk.CTkFont(size=14))
        self.bulk_count.pack(side='left',padx=12)
        table=ctk.CTkFrame(parent,fg_color=PANEL,corner_radius=20,border_width=1,border_color=BORDER);self.inventory_table=table;table.pack(fill='both',expand=True)
        heading=ctk.CTkFrame(table,fg_color='transparent');heading.pack(fill='x',padx=12,pady=(5,4))
        self.list_count=Label(heading,text='',text_color=MUTED,font=ctk.CTkFont(size=14));self.list_count.pack(side='left')
        Button(heading,'Otwórz kartę >',self.open_product,primary=True,width=140).pack(side='right')
        Button(heading,'Palety / faktury',self.manage_pallets,width=155).pack(side='right',padx=6)
        Button(heading,'Archiwizuj zaznaczone',self.archive_selected,width=190).pack(side='right',padx=6)
        Button(heading,'Przypisz Allegro',self.assign_pending,width=155).pack(side='right',padx=6)
        Button(heading,'Przywróć',self.restore_product,width=100).pack(side='right',padx=6)
        for control in heading.winfo_children():
            if isinstance(control,Button):control.configure(height=32)
        area=tk.Frame(table,bg=PANEL);area.pack(fill='both',expand=True,padx=8)
        cols=('number','name','asin','ean','qty','condition','status','ai_status','price')
        self.tree=ttk.Treeview(area,columns=cols,show='tree headings',selectmode='extended',displaycolumns=('name','qty','price','status'))
        self.tree.heading('#0',text='✓');self.tree.column('#0',width=54,minwidth=54,stretch=False,anchor='center')
        for key,title,width in [('number','Numer',96),('name','Produkt / numer / stan',340),('asin','ASIN',110),('ean','EAN',110),('qty','Szt.',60),('condition','Stan',125),('status','Status',155),('ai_status','Analiza',120),('price','Cena',140)]:
            self.tree.heading(key,text=title);self.tree.column(key,width=width,minwidth=40,stretch=key=='name')
        self.tree.grid(row=0,column=0,sticky='nsew');area.columnconfigure(0,weight=1);area.rowconfigure(0,weight=1)
        sy=ctk.CTkScrollbar(area,command=self.tree.yview,fg_color=PANEL,button_color=BORDER);sy.grid(row=0,column=1,sticky='ns',padx=(3,0));sy._wheel_target=self.tree
        sx=ctk.CTkScrollbar(area,orientation='horizontal',command=self.tree.xview,fg_color=PANEL,button_color=BORDER,height=10);sx.grid_remove()
        self.tree.configure(yscrollcommand=sy.set,xscrollcommand=sx.set)
        self.tree.tag_configure('even',background=PANEL);self.tree.tag_configure('odd',background='#171c25')
        self.tree.bind('<Button-1>',self.toggle_product_checkbox,add='+');self.tree.bind('<<TreeviewSelect>>',self.on_select);self.tree.bind('<<TreeviewSelect>>',self.track_multi_selection,add='+');self.tree.bind('<Double-Button-1>',self.open_product_event);self.tree.bind('<Return>',lambda e:self.open_product())
        self.empty_list=Label(area,text='Brak produktów. Zmień filtr lub dodaj produkt.',text_color=MUTED,font=ctk.CTkFont(size=14))
        paging=ctk.CTkFrame(table,fg_color='transparent');paging.pack(fill='x',padx=12,pady=6)
        self.inventory_page_number=0;self.inventory_records=[];self.bulk_selected_ids=set();self._bulk_updating=False
        Button(paging,'< Poprzednie',lambda:self.inventory_change_page(-1),width=140).pack(side='left')
        self.inventory_page_label=Label(paging,text='');self.inventory_page_label.pack(side='left',padx=12)
        Button(paging,'Następne >',lambda:self.inventory_change_page(1),width=140).pack(side='right')
        self.summary=Label(table,text='',text_color=MUTED,font=ctk.CTkFont(size=14),anchor='w');self.summary.pack(side='bottom',fill='x',padx=16,pady=5,before=area)
        paging.pack_configure(side='bottom',before=area)
        self.stat_labels={key:Label(parent,text='') for key in ('products','quantity','approved')}

    def toggle_bulk_tools(self):
        if self.bulk_tools.winfo_manager():
            self.bulk_tools.pack_forget()
        else:
            self.bulk_tools.pack(fill='x',pady=(0,5),before=self.inventory_table)

    def textfield(self,parent,height=120):
        holder=ctk.CTkFrame(parent,fg_color=FIELD,corner_radius=10,border_width=1,border_color=BORDER,height=height+20)
        holder.pack(fill='both',expand=height>100,pady=(5,12))
        box=tk.Text(holder,bg=FIELD,fg=TEXT,insertbackground=TEXT,relief='flat',borderwidth=0,font=(previous.FONT,13),wrap='word',undo=True,height=max(2,height//20),width=12,selectbackground='#522432')
        box.pack(side='left',fill='both',expand=True,padx=(10,0),pady=10)
        scroll=ctk.CTkScrollbar(holder,command=box.yview,fg_color=FIELD,button_color=BORDER,height=height);scroll.pack(side='right',fill='y',padx=(0,3),pady=8)
        box.bind('<<Modified>>',self.text_modified)
        box.configure(yscrollcommand=scroll.set);scroll._wheel_target=box
        GrowText(box,minimum=max(3,height//24),maximum=max(6,min(16,height//20)),on_resize=self.grow_product_tabs)
        return box

    def grow_product_tabs(self):
        # Fixed workspace: descriptions scroll internally; never grow the whole page.
        pass

    def build_product(self,parent):
        from fixed_workspace import build_product
        build_product(self,parent)

    def update_price_display(self):
        text=self.vars['sale_price'].get().strip()
        try:price=pln(money(text)) if text else 'Ustal cenę'
        except ValueError:price='Sprawdź cenę'
        self.price_display.configure(text=price)

    def scroll_to_description(self):
        self.editor_tabs.select(0)
        self.description_box.focus_set()

    def pricing_fields(self,parent):
        fields=ctk.CTkFrame(parent,fg_color='transparent');fields.pack(fill='x');fields.columnconfigure((0,1),weight=1)
        for key,title,row,col,span in (('sale_price','Cena (zł)',0,0,1),('quantity','Ilość',0,1,1),('condition','Stan produktu',2,0,2)):
            Label(fields,text=title,text_color=MUTED,anchor='w',font=ctk.CTkFont(size=15)).grid(row=row,column=col,columnspan=span,sticky='ew',padx=4)
            if key not in self.vars:
                self.vars[key]=tk.StringVar();self.vars[key].trace_add('write',self.mark_dirty)
            var=self.vars[key]
            widget=ctk.CTkOptionMenu(fields,variable=var,values=list(CONDITIONS),width=150,height=42,fg_color=FIELD,button_color=BORDER,font=ctk.CTkFont(size=16)) if key=='condition' else ctk.CTkEntry(fields,textvariable=var,width=90,height=42,fg_color=FIELD,border_color=BORDER,font=ctk.CTkFont(size=17))
            widget.grid(row=row+1,column=col,columnspan=span,sticky='ew',padx=4,pady=(4,12))

    def show_inventory(self):
        self.page_scroll.top()
        self.set_product_focus(False)
        self.orders_page.pack_forget()
        self.product_page.pack_forget();self.inventory_page.pack(fill='both',expand=True)
        self.current_view='inventory';self.style_navigation('Magazyn')
        self.page_title.configure(text='Magazyn produktów');self.breadcrumb.configure(text='Przestrzeń robocza / Magazyn')
        self.subtitle.configure(text='Zarządzaj towarem i przygotuj produkty do sprzedaży.')
        self.back_top.pack_forget();self.import_top.pack(side='right',padx=5);self.add_product_top.pack(side='right',padx=5)
    def open_product(self):
        result=super().open_product()
        if result:
            self.set_product_focus(True)
            self.page_scroll.top()
            self.orders_page.pack_forget()
            self.add_product_top.pack_forget();self.page_title.configure(text=str(self.store.get(self.selected_id)['product_name'])[:160])
        return result
    def show_product(self):
        super().show_product()
        if self.current_view=='product' and self.selected_id:self.page_title.configure(text=str(self.store.get(self.selected_id)['product_name'])[:160])
    def style_navigation(self,title):
        for name,button in self.nav_buttons.items():button.configure(fg_color='#3b1b27' if name==title else SIDE,border_width=0)
        self.current_section=title
    def load_overview(self):pass
    def update_overview_values(self):pass
    def card_tab_changed(self,_event=None):
        if self.editor_tabs.index('current')==3:self.photo_pane.ensure_loaded()
    def goto_photos(self):self.editor_tabs.select(3)
    def load_db(self):
        # Build Python records first. Only visible rows and thumbnails reach Tk.
        all_rows=inventory_sync.available(self.store);query=self.search_var.get().strip().casefold();status=self.filter_var.get()
        rows=[r for r in all_rows if (status=='Wszystkie' or r['status']==status) and (not query or query in ' '.join(str(r[k] or '') for k in ('id','product_name','asin','ean','sku','generated_title')).casefold() or query in f"SS-{r['id']:05d}".casefold())]
        if self.selected_id and not any(r['id']==self.selected_id for r in rows):
            selected=next((r for r in all_rows if r['id']==self.selected_id),None)
            if selected is not None:rows.append(selected)
        self.bulk_selected_ids.intersection_update({int(r['id']) for r in all_rows})
        self.update_bulk_count()
        self.inventory_records=[];self.applied_filter=status
        for i,r in enumerate(rows):
            values=(f"SS-{r['id']:05d}",str(r['product_name'])+'\n'+f"SS-{r['id']:05d} · {r['condition'] or 'Nie sprawdzono'}",r['asin'],r['ean'],r['quantity'],r['condition'],r['status'],'Analizuję…' if r['id']==self.busy_id else r['ai_status'],str(r['sale_price'])+' zł' if r['sale_price'] else '--')
            self.inventory_records.append((str(r['id']),{'values':values,'image':'','tags':('even' if i%2==0 else 'odd',)}))
        qty=sum(r['quantity'] or 0 for r in all_rows);approved=sum(r['status']=='Zatwierdzony' for r in all_rows)
        for key,value in (('products',len(all_rows)),('quantity',qty),('approved',approved)):self.stat_labels[key].config(text=str(value))
        self.summary.config(text=f'Produkty: {len(all_rows)}  •  Sztuki: {qty}  •  Zatwierdzone: {approved}')
        self.list_count.config(text=f'{len(rows)} pozycji');self.empty_list.place_forget()
        if not rows:self.empty_list.place(relx=.5,rely=.45,anchor='center')
        self.main_photo_rows=self.gallery.main_photos()
        if self.selected_id:
            selected=next((i for i,(ident,_) in enumerate(self.inventory_records) if ident==str(self.selected_id)),None)
            if selected is not None:self.inventory_page_number=selected//PAGE_SIZE
        self.render_inventory_page()

    def inventory_change_page(self,step):
        pages=max(1,(len(self.inventory_records)+PAGE_SIZE-1)//PAGE_SIZE)
        self.inventory_page_number=max(0,min(pages-1,self.inventory_page_number+step))
        self.selected_id=None;self.render_inventory_page();self.page_scroll.top()

    def render_inventory_page(self):
        records=self.inventory_records;pages=max(1,(len(records)+PAGE_SIZE-1)//PAGE_SIZE)
        self.inventory_page_number=min(self.inventory_page_number,pages-1)
        selected=str(self.selected_id) if self.selected_id else ''
        self.loading=True;self._bulk_updating=True;self.tree.delete(*self.tree.get_children())
        visible=records[self.inventory_page_number*PAGE_SIZE:(self.inventory_page_number+1)*PAGE_SIZE]
        for ident,item in visible:self.tree.insert('','end',iid=ident,text='☑' if int(ident) in self.bulk_selected_ids else '☐',values=item['values'],image=item['image'],tags=item['tags'])
        self.tree.configure(height=visible_rows(len(visible)));self.tree.yview_moveto(0)
        self.inventory_page_label.configure(text=f'Strona {self.inventory_page_number+1} / {pages} · do {PAGE_SIZE} produktów')
        chosen=[ident for ident,_ in visible if int(ident) in self.bulk_selected_ids]
        if chosen:self.tree.selection_set(chosen)
        elif selected and self.tree.exists(selected) and not self.bulk_selected_ids:self.tree.selection_set(selected)
        self.loading=False;self._bulk_updating=False
        self.thumbnail_generation=getattr(self,'thumbnail_generation',0)+1
        self.visible_thumbnails={}
        self.after(1,lambda generation=self.thumbnail_generation,ids=[ident for ident,_ in visible]:self.load_visible_thumbnails(generation,ids))
        self.page_scroll.schedule()

    def load_visible_thumbnails(self,generation,ids):
        if generation!=self.thumbnail_generation or self.closing:return
        for ident in ids[:4]:
            photo=self.main_photo_rows.get(int(ident))
            if photo and self.tree.exists(ident):
                try:
                    key=photo['relative_path'];image=self.thumbnail_cache.get(key)
                    if image is None:
                        original=self.gallery.thumbnail(photo)
                        try:
                            original.thumbnail((48,48),Image.Resampling.LANCZOS)
                            image=ImageTk.PhotoImage(original,master=self)
                        finally:original.close()
                        self.thumbnail_cache[key]=image
                        if len(self.thumbnail_cache)>256:self.thumbnail_cache.popitem(last=False)
                    self.visible_thumbnails[ident]=image;self.tree.item(ident,image=image)
                except (PhotoError,OSError,ValueError):pass
        if len(ids)>4:self.after(8,lambda:self.load_visible_thumbnails(generation,ids[4:]))

    def open_pending_orders(self):
        if self.open_orders():
            self.orders_page.status.set('Do realizacji');self.orders_page.query.set('');self.orders_page.page_number=0;self.orders_page.render()

    def render_shipping(self):
        snapshot=self.orders_page.snapshot
        count=sum(matches(o,status='Do realizacji') for o in snapshot.orders) if snapshot else None
        self.daily_values['shipping'].configure(text=str(count) if count is not None else '--')
        self.compact_values['shipping'].configure(text='Do wysłania: '+(str(count) if count is not None else '--'))
        self.daily_notes['shipping'].configure(text=f'ostatnie {snapshot.days} dni · kliknij, aby otworzyć' if snapshot else 'odśwież zamówienia')

    def auto_offer_prices(self):
        self.after(180000,self.auto_offer_prices)
        if self._offer_prices_running or self.dirty or self.busy_id is not None or self.current_view!='inventory' or self.grab_current() is not None:return
        with self.store.connect() as con:
            if not con.execute("SELECT 1 FROM sqlite_master WHERE name='ss_allegro_listings'").fetchone():return
            if not con.execute("SELECT 1 FROM ss_allegro_listings WHERE env='production' AND offer_id<>'' LIMIT 1").fetchone():return
        self._offer_prices_running=True
        def completed(changed):
            self._offer_prices_running=False
            if changed and not self.dirty:self.load_db()
        def fetch():
            changed=0
            try:
                from allegro_listing_api import OfferAPI
                from allegro_listing import refresh_linked_prices
                changed=refresh_linked_prices(self.store,OfferAPI())
            except Exception:pass
            if not self.closing:self.after(0,completed,changed)
        threading.Thread(target=fetch,daemon=True).start()

    def open_allegro_offer(self):
        if self.busy_id is not None or getattr(self,'_bulk_ai_running',False) or getattr(self,'cloud_running',False) or getattr(self,'photo_importing',False) or getattr(self,'_offer_prices_running',False):
            messagebox.showinfo('Allegro','Poczekaj na zakończenie analizy, importu lub synchronizacji.',parent=self);return
        if not self.confirm_pending():return
        pid=self.selected_id
        if not pid:
            selection=self.tree.selection()
            pid=int(selection[0]) if selection else None
        if not pid:
            messagebox.showinfo('Allegro','Najpierw wybierz produkt w magazynie.',parent=self);return
        from allegro_listing_ui import OfferEditor
        current=getattr(self,'listing_dialog',None)
        if current is not None and current.winfo_exists():current.lift();return
        self.listing_dialog=OfferEditor(self,pid)

    def settings(self):
        win=ctk.CTkToplevel(self);win.title('Ustawienia');win.geometry('380x440');win.transient(self);win.grab_set()
        Label(win,text='Ustawienia i narzędzia',font=ctk.CTkFont(size=22,weight='bold')).pack(pady=22)
        for title,callback in [('Integracja Allegro',self.integration_info),('Klucz OpenAI',self.configure_key),('Import palety',self.import_file),('Eksport produktów',self.export_csv),('Kopia danych',self.backup_db)]:
            def action(fn=callback):win.destroy();fn()
            Button(win,title,action,width=300).pack(pady=6)
        Button(win,'Zamknij',win.destroy,width=300).pack(pady=16)

    def add_product(self):
        if not self.confirm_pending():return
        win=ctk.CTkToplevel(self);win.title('Dodaj produkt');win.geometry('440x440');win.transient(self);win.grab_set()
        Label(win,text='Nowy produkt',font=ctk.CTkFont(size=22,weight='bold')).pack(pady=20)
        vars={}
        for key,title,default in (('name','Nazwa produktu',''),('asin','ASIN (opcjonalnie)',''),('qty','Ilość','1'),('price','Cena sprzedaży (zł, opcjonalnie)','')):
            Label(win,text=title,anchor='w',text_color=MUTED).pack(fill='x',padx=25)
            vars[key]=tk.StringVar(value=default);ctk.CTkEntry(win,textvariable=vars[key],height=35).pack(fill='x',padx=25,pady=(3,10))
        def save():
            try:
                name=vars['name'].get().strip();asin=vars['asin'].get().strip().upper();qty=int(vars['qty'].get())
                if not name or len(name)>500:raise ValueError('Podaj nazwę produktu (do 500 znaków).')
                if asin and not re.fullmatch('[A-Z0-9]{10}',asin):raise ValueError('ASIN musi mieć 10 liter lub cyfr.')
                if not 0<=qty<=9999999:raise ValueError('Podaj poprawną nieujemną ilość.')
                price=str(money(vars['price'].get())) if vars['price'].get().strip() else ''
                with self.store.connect() as con:
                    cur=con.execute("INSERT INTO products(product_name,asin,quantity,sale_price,status) VALUES(?,?,?,?,?)",(name,asin,qty,price,'Szkic'));pid=cur.lastrowid
            except (ValueError,OverflowError) as exc:messagebox.showwarning('Sprawdź dane',str(exc),parent=win);return
            win.destroy();self.selected_id=pid;self.search_var.set('');self.filter_var.set('Wszystkie');self.load_db();self.tree.selection_set(str(pid));self.on_select();self.open_product()
        Button(win,'Dodaj produkt',save,primary=True).pack(pady=8)

    def open_orders(self):
        if self.current_view=='product' and not self.confirm_pending():return False
        self.page_scroll.top()
        self.set_product_focus(False)
        self.inventory_page.pack_forget();self.product_page.pack_forget();self.orders_page.pack(fill='both',expand=True)
        self.current_view='orders';self.style_navigation('Zamówienia')
        self.page_title.configure(text='Twoje zamówienia Allegro');self.breadcrumb.configure(text='Przestrzeń robocza / Zamówienia')
        self.subtitle.configure(text='Rzeczywiste zakupy, płatności i dostawy z połączonego konta.')
        self.add_product_top.pack_forget();self.import_top.pack_forget();self.back_top.pack(side='right')
        if self.orders_page.snapshot is None and not self.sales_running and not self.orders_running:self.sync_orders()
        return True

    def clear_allegro_data(self):
        self.sync_generation+=1;self.sales_running=False;self.orders_running=False;self.sync_controls()
        self.snapshot=None;self.daily_overview=None;self.sales_error='Konto Allegro odłączone. Połącz konto ponownie.'
        self.orders_page.received(None,self.sales_error);self.render_daily()

    def allegro_connected(self):
        self.clear_allegro_data();self.sync_sales()

    def sync_result(self,generation,callback,snapshot,error):
        if generation==self.sync_generation:callback(snapshot,error)

    def sync_controls(self):
        busy=self.sales_running or self.orders_running
        self.sync_button.state(['disabled' if busy else '!disabled'])
        self.orders_page.refresh.configure(state='disabled' if busy else 'normal')
        self.orders_page.period_menu.configure(state='disabled' if busy else 'normal')

    def sync_sales(self):
        if self.sales_running or self.orders_running:return
        self.sales_running=True;self.orders_running=True;self.sync_controls()
        days=PERIODS[self.orders_page.period.get()];generation=self.sync_generation
        def post(callback,snapshot,error):
            self.events.put((self.sync_result,(generation,callback,snapshot,error)))
        self.sync_hint.configure(text='Pobieram sprzedaż z Allegro…')
        self.orders_page.hint.configure(text='Pobieram listę zamówień…',text_color=MUTED)
        def worker():
            from allegro_api import AllegroError
            try:
                result=self.orders_service.fetch(days)
                daily=daily_from_orders(result)
                try:post(self.rates_done,self.fx_service.fetch((daily.by_currency or {}).keys()),None)
                except RateError as exc:post(self.rates_done,None,str(exc))
                post(self.orders_done,result,None)
            except Exception as exc:
                text=str(exc) if isinstance(exc,AllegroError) else 'Nie udało się pobrać zamówień. Sprawdź połączenie i spróbuj ponownie.'
                post(self.orders_done,None,text)
        threading.Thread(target=worker,daemon=True).start()
    def manage_pallets(self):
        """Katalog palet z archiwizacją i przywracaniem całych grup."""
        pallet_manager.setup(self.store)
        win=ctk.CTkToplevel(self)
        win.title('StreetSell AI — Palety i faktury')
        win.geometry('850x630')
        win.minsize(720,520)
        win.transient(self)
        win.grab_set()

        Label(win,text='Zarządzanie paletami',text_color=TEXT,
              font=ctk.CTkFont(size=23,weight='bold')).pack(anchor='w',padx=20,pady=(18,5))
        Label(win,text='Wybierz paletę, przypisz produkty po numerach SS i zarządzaj archiwum.',
              text_color=MUTED).pack(anchor='w',padx=20,pady=(0,12))
        toolbar=ctk.CTkFrame(win,fg_color='transparent')
        toolbar.pack(fill='x',padx=18,pady=5)
        table_holder=ctk.CTkFrame(win,fg_color=PANEL)
        table_holder.pack(fill='both',expand=True,padx=18,pady=8)
        cols=('number','invoice','count','state')
        table=ttk.Treeview(table_holder,columns=cols,show='headings',selectmode='browse',height=10)
        for key,title,width in [('number','Numer palety',145),('invoice','Numer faktury',250),
                                ('count','Produkty',90),('state','Status',140)]:
            table.heading(key,text=title)
            table.column(key,width=width,stretch=key=='invoice')
        scrollbar=ttk.Scrollbar(table_holder,orient='vertical',command=table.yview)
        table.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side='right',fill='y',padx=(0,6),pady=8)
        table.pack(side='left',fill='both',expand=True,padx=(8,0),pady=8)
        actions=ctk.CTkFrame(win,fg_color='transparent')
        actions.pack(fill='x',padx=18,pady=(6,8))
        note=Label(win,text='Produkty archiwalne pozostają w bazie, wraz ze zdjęciami.',
                   text_color=MUTED,wraplength=770)
        note.pack(anchor='w',padx=20,pady=(0,14))

        def refresh_table(select=None):
            table.delete(*table.get_children())
            for archived in (False,True):
                for pallet in pallet_manager.list_pallets(self.store,archived=archived):
                    number=pallet['number']
                    table.insert('','end',iid=number,values=(number,pallet['invoice'] or '—',
                        pallet['product_count'],'Archiwalna' if archived else 'Aktywna'))
            if select and table.exists(select):
                table.selection_set(select)
                table.see(select)

        def selected():
            chosen=table.selection()
            if not chosen:
                messagebox.showinfo('Palety','Najpierw wybierz paletę z listy.',parent=win)
                return None
            return chosen[0]

        def is_archived(number):
            return table.set(number,'state')=='Archiwalna'

        def create():
            invoice=simpledialog.askstring('Nowa paleta','Numer faktury (można zostawić pusty):',
                                           parent=win)
            if invoice is None:return
            try:
                number=pallet_manager.create_pallet(self.store,invoice)
                refresh_table(number)
                messagebox.showinfo('Nowa paleta',f'Utworzono paletę {number}.',parent=win)
            except Exception as exc:
                messagebox.showerror('Błąd',str(exc),parent=win)

        def assign():
            number=selected()
            if not number:return
            if is_archived(number):
                messagebox.showwarning('Paleta','Najpierw przywróć paletę z archiwum.',parent=win)
                return
            initial=str(self.selected_id) if self.selected_id else ''
            value=simpledialog.askstring('Przypisz produkty',
                'Podaj numery produktów SS oddzielone przecinkami, np. 12, 13, 14.\n'
                'Produkt może należeć tylko do jednej palety.',
                initialvalue=initial,parent=win)
            if value is None:return
            try:
                parts=[part.strip().upper().removeprefix('SS-') for part in value.split(',')]
                if not parts or len(parts)>1000 or any(not x.isdigit() for x in parts):
                    raise ValueError('Wpisz numery produktów oddzielone przecinkami.')
                ids=list(dict.fromkeys(int(x) for x in parts))
                with self.store.connect() as con:
                    missing=[pid for pid in ids if not con.execute(
                        'SELECT 1 FROM products WHERE id=?',(pid,)).fetchone()]
                if missing:
                    raise ValueError('Nie znaleziono produktów: '+', '.join(map(str,missing[:15])))
                if not messagebox.askyesno('Przypisanie',
                    f'Przypisać {len(ids)} produktów do {number}?\n'
                    'Produkty wcześniej przypisane do innej aktywnej palety zostaną przeniesione.',
                    parent=win):return
                for pid in ids:pallet_manager.assign_product(self.store,number,pid)
                refresh_table(number)
                messagebox.showinfo('Gotowe',f'Przypisano {len(ids)} produktów.',parent=win)
            except (ValueError,TypeError) as exc:
                messagebox.showwarning('Sprawdź numery',str(exc),parent=win)
            except Exception as exc:
                messagebox.showerror('Błąd',str(exc),parent=win)

        def show_products():
            number=selected()
            if not number:return
            try:
                products=pallet_manager.pallet_products(self.store,number)
                sample='\n'.join(f"SS-{r['id']:05d} — {str(r['product_name'])[:65]}" for r in products[:30])
                suffix=f'\n... i {len(products)-30} kolejnych' if len(products)>30 else ''
                messagebox.showinfo(number,f'Produktów: {len(products)}\n\n'+
                    (sample+suffix if products else 'Paleta jest pusta.'),parent=win)
            except Exception as exc:messagebox.showerror('Błąd',str(exc),parent=win)

        def change_invoice():
            number=selected()
            if not number:return
            value=simpledialog.askstring('Numer faktury',f'Faktura dla {number}:',
                initialvalue=table.set(number,'invoice').replace('—',''),parent=win)
            if value is None:return
            try:pallet_manager.update_invoice(self.store,number,value);refresh_table(number)
            except Exception as exc:messagebox.showerror('Błąd',str(exc),parent=win)

        def archive_or_restore():
            number=selected()
            if not number:return
            archived=is_archived(number)
            count=len(pallet_manager.pallet_products(self.store,number))
            action='Przywrócić' if archived else 'Archiwizować'
            if not messagebox.askyesno(action+' paletę',
                f'{action} paletę {number} i jej {count} produktów?\n\n'
                'Produkty i zdjęcia nie zostaną usunięte.\n'
                'Produkty wcześniej zarchiwizowane jako sprzedane pozostaną w archiwum.',
                parent=win):return
            try:
                changed=(pallet_manager.restore_pallet(self.store,number) if archived
                         else pallet_manager.archive_pallet(self.store,number))
                self.selected_id=None
                self.load_db()
                refresh_table(number)
                messagebox.showinfo('Gotowe',f'Paleta {number}: operacja zakończona.\n'
                    f'Przetworzono {changed} produktów.',parent=win)
            except Exception as exc:messagebox.showerror('Błąd',str(exc),parent=win)

        Button(toolbar,'+ Nowa paleta',create,primary=True,width=145).pack(side='left',padx=3)
        Button(toolbar,'Przypisz produkty SS',assign,width=175).pack(side='left',padx=3)
        Button(toolbar,'Zmień fakturę',change_invoice,width=135).pack(side='left',padx=3)
        Button(actions,'Pokaż produkty',show_products,width=145).pack(side='left',padx=3)
        Button(actions,'Archiwizuj / przywróć paletę',archive_or_restore,
               primary=True,width=245).pack(side='left',padx=3)
        Button(actions,'Zamknij',win.destroy,width=110).pack(side='right',padx=3)
        refresh_table()

    def update_bulk_count(self):
        if hasattr(self,'bulk_count'):
            self.bulk_count.configure(text=f'Zaznaczono: {len(self.bulk_selected_ids)}')

    def track_multi_selection(self,_event=None):
        if getattr(self,'_bulk_updating',False) or getattr(self,'loading',False):return
        # Aktualizujemy tylko produkty z aktualnej strony, zachowując wybór z innych stron.
        visible={int(x) for x in self.tree.get_children()}
        selected={int(x) for x in self.tree.selection()}
        self.bulk_selected_ids.difference_update(visible-selected)
        self.bulk_selected_ids.update(selected)
        self.refresh_checkbox_marks()
        self.update_bulk_count()

    def refresh_checkbox_marks(self):
        if not hasattr(self,'tree'):return
        for ident in self.tree.get_children():
            self.tree.item(ident,text='☑' if int(ident) in self.bulk_selected_ids else '☐')

    def toggle_product_checkbox(self,event):
        # Kliknięcie kwadratu przełącza wyłącznie ten produkt.
        if self.tree.identify_region(event.x,event.y) != 'tree':return
        ident=self.tree.identify_row(event.y)
        if not ident:return
        pid=int(ident)
        if pid in self.bulk_selected_ids:self.bulk_selected_ids.remove(pid)
        else:self.bulk_selected_ids.add(pid)
        self._bulk_updating=True
        try:
            if pid in self.bulk_selected_ids:self.tree.selection_add(ident)
            else:self.tree.selection_remove(ident)
        finally:self._bulk_updating=False
        self.refresh_checkbox_marks()
        self.update_bulk_count()
        return 'break'

    def select_all_products(self):
        # Wybiera wszystkie wyniki bieżącego wyszukiwania, także z kolejnych stron.
        self.bulk_selected_ids.update(int(ident) for ident,_ in self.inventory_records)
        self._bulk_updating=True
        try:self.tree.selection_set(self.tree.get_children())
        finally:self._bulk_updating=False
        self.refresh_checkbox_marks()
        self.update_bulk_count()

    def clear_bulk_selection(self):
        self.bulk_selected_ids.clear()
        self._bulk_updating=True
        try:self.tree.selection_remove(self.tree.selection())
        finally:self._bulk_updating=False
        self.refresh_checkbox_marks()
        self.update_bulk_count()

    def start_bulk_analysis(self):
        """Analiza wybranych produktów po kolei, z zachowaniem istniejących szkiców."""
        import legacy
        if getattr(self, '_bulk_ai_running', False) or self.busy_id is not None:
            messagebox.showinfo('Masowa analiza', 'Trwa już analiza AI. Poczekaj na jej zakończenie.', parent=self)
            return
        if not self.confirm_pending():
            return
        ids = sorted(self.bulk_selected_ids | {int(x) for x in self.tree.selection()})
        if not ids:
            messagebox.showinfo('Masowa analiza', 'Najpierw zaznacz produkty albo kliknij „Zaznacz wszystkie produkty”.', parent=self)
            return
        pending = []
        skipped = 0
        for pid in ids:
            row = self.store.get(pid)
            if row is None:
                continue
            if row['generated_title'] or row['generated_description']:
                skipped += 1
            else:
                pending.append(pid)
        if not pending:
            messagebox.showinfo('Masowa analiza', f'Wszystkie {skipped} zaznaczone produkty mają już szkice. Nie nadpisano danych.', parent=self)
            return
        key = legacy.get_api_key()
        if not key:
            messagebox.showinfo('Klucz API', 'Najpierw ustaw klucz OpenAI w Ustawieniach.', parent=self)
            return
        prompt = (f'Rozpocząć analizę AI dla {len(pending)} produktów?\n'
                  f'Pominięte istniejące szkice: {skipped}.\n\n'
                  'Analiza korzysta z płatnego API OpenAI i wyszukiwania internetowego. '
                  'Wyniki zostaną zapisane jako szkice, bez publikacji na Allegro.')
        if not messagebox.askyesno('Masowa analiza produktów', prompt, parent=self):
            return
        self._bulk_ai_running = True
        self._bulk_ai_cancel = False
        self._bulk_ai_ids = pending
        self._bulk_ai_key = key
        self._bulk_ai_done_count = 0
        self._bulk_ai_errors = []
        self._bulk_ai_total = len(pending)
        self._bulk_ai_next()

    def stop_bulk_analysis(self):
        if getattr(self, '_bulk_ai_running', False):
            self._bulk_ai_cancel = True
            self.statusbar.configure(text='Zatrzymuję kolejkę po zakończeniu bieżącego produktu…')
        else:
            messagebox.showinfo('Masowa analiza', 'Nie trwa masowa analiza.', parent=self)

    def _bulk_ai_next(self):
        if self._bulk_ai_cancel or not self._bulk_ai_ids:
            self._bulk_ai_running = False
            text = (f'Zakończono: {self._bulk_ai_done_count}/{self._bulk_ai_total}. '
                    f'Błędy: {len(self._bulk_ai_errors)}.'
                    + (' Kolejka zatrzymana.' if self._bulk_ai_cancel else ''))
            self.statusbar.configure(text=text)
            if self._bulk_ai_errors:
                details = '\n'.join(self._bulk_ai_errors[:12])
                messagebox.showwarning('Masowa analiza — podsumowanie', text + '\n\n' + details, parent=self)
            else:
                messagebox.showinfo('Masowa analiza — podsumowanie', text, parent=self)
            return
        pid = self._bulk_ai_ids.pop(0)
        row = self.store.get(pid)
        if row is None:
            self._bulk_ai_errors.append(f'SS-{pid:05d}: nie znaleziono produktu')
            self.after(10, self._bulk_ai_next)
            return
        self.busy_id = pid
        self.store.invalidate_approval(pid)
        self.statusbar.configure(text=f'Analiza AI {self._bulk_ai_done_count + len(self._bulk_ai_errors) + 1}/{self._bulk_ai_total}: SS-{pid:05d}…')
        data = (row['product_name'], row['asin'], row['ean'], row['category'], row['product_link'])
        threading.Thread(target=self._analyze_worker, args=(pid, data, self._bulk_ai_key), daemon=True).start()

    def _analysis_done(self, product_id, error):
        if not getattr(self, '_bulk_ai_running', False):
            return super()._analysis_done(product_id, error)
        self.busy_id = None
        if error:
            with self.store.connect() as con:
                con.execute("UPDATE products SET ai_status='Błąd analizy' WHERE id=?", (product_id,))
            self._bulk_ai_errors.append(f'SS-{product_id:05d}: {error}')
        else:
            self._bulk_ai_done_count += 1
        self.load_db()
        if self.selected_id == product_id and not self.dirty:
            self.show_product()
        self.after(80, self._bulk_ai_next)

    def archive_selected(self):
        ids=sorted(self.bulk_selected_ids | {int(x) for x in self.tree.selection()})
        if not ids:
            messagebox.showinfo('Magazyn','Zaznacz produkty na liście albo kliknij „Zaznacz wszystkie produkty”.');return
        if messagebox.askyesno('Archiwizacja',
            f'Zarchiwizować {len(ids)} zaznaczonych produktów?\n\n'
            'Produkty i zdjęcia pozostaną w bazie. Operacja nie usuwa ofert z Allegro.',parent=self):
            inventory_sync.archive(self.store,ids)
            self.bulk_selected_ids.clear();self.selected_id=None;self.load_db()
            self.update_bulk_count()


    def restore_product(self):
        pid=simpledialog.askinteger('Przywróć produkt','Podaj numer produktu SS (np. 15 dla SS-00015):',parent=self,minvalue=1)
        if pid is None:return
        if not self.store.get(pid):messagebox.showerror('Magazyn','Nie ma takiego produktu.');return
        inventory_sync.unarchive(self.store,pid);self.load_db()

    def assign_pending(self):
        account=getattr(self,'last_inventory_account',None)
        if not account:
            messagebox.showinfo('Allegro','Najpierw zsynchronizuj zamówienia Allegro.');return
        rows=inventory_sync.pending(self.store,account)
        if not rows:
            messagebox.showinfo('Allegro','Brak nieprzypisanych, potwierdzonych ofert.');return
        offer=rows[0]['offer_id']
        pid=simpledialog.askinteger('Przypisz ofertę',f'Oferta Allegro: {offer}\nNieprzypisane pozycje: {rows[0]["lines"]}\nPodaj numer produktu SS:',parent=self,minvalue=1)
        if pid is None:return
        try:
            inventory_sync.link(self.store,account,offer,pid)
            messagebox.showinfo('Allegro','Przypisano. Przy następnej synchronizacji zostanie odjęty stan, jeśli zamówienie jest potwierdzone.')
        except ValueError as exc:messagebox.showerror('Allegro',str(exc))

    def sync_orders(self):
        if self.sales_running or self.orders_running:return
        self.sync_sales()
    def rates_done(self,book,error):
        self.rate_book=book;self.rate_error=error or ''

    def orders_done(self,snapshot,error):
        self.orders_running=False;self.sales_running=False;self.sync_controls();self.orders_page.received(snapshot,error)
        self.daily_overview=None
        if not error and snapshot is not None:
            self.last_inventory_account=snapshot.account
            try:
                changed,baseline=inventory_sync.reconcile(self.store,snapshot)
                if changed:self.load_db()
                if baseline:messagebox.showinfo('Magazyn Allegro','Pierwsze pobranie zapisano jako punkt startowy. Historycznych zamówień nie odjęto, aby uniknąć podwójnego rozliczenia.')
            except Exception as exc:
                messagebox.showwarning('Synchronizacja magazynu',f'Nie udało się uzgodnić stanów: {exc}')
        if error or snapshot is None:
            self.sales_done(None,error or 'Nie pobrano kompletnej listy zamówień.');return
        try:
            self.daily_overview=today_overview(snapshot)
            daily=daily_from_orders(snapshot)
        except Exception as exc:
            from allegro_api import AllegroError
            text=str(exc) if isinstance(exc,AllegroError) else 'Niepełne dane dzisiejszej sprzedaży. Odśwież listę i spróbuj ponownie.'
            self.sales_done(None,text);return
        self.sales_done(daily,None)
        if daily.day!=today_bounds()[0]:self.after(300,self.sync_sales)
    def sales_done(self,snapshot,error):
        self.sales_running=False;self.sync_controls()
        self.snapshot=snapshot;self.sales_error=error or '';self.render_daily()
    def set_product_focus(self,active):
        self.stats_host.pack_forget();self.compact_stats.pack_forget()
        if not self.stats_expanded_on_product:
            self.compact_stats.pack(fill='x',before=self.top)
        else:
            self.stats_host.pack(fill='x',before=self.top)
        if self.stats_expanded_on_product:
            self.compact_stats.pack(fill='x',before=self.top)

    def toggle_product_stats(self):
        # Detailed stats stay in their own window, leaving the working viewport fixed.
        self.show_sales_details()

    def total_view(self):
        if self.snapshot is None:raise RateError('Najpierw pobierz sprzedaż.')
        return combined_snapshot(self.snapshot,self.rate_book)

    def total_profit(self):
        return combined_profit(self.snapshot,self.rate_book,self.costs,self.total_costs)

    def render_daily(self):
        self.render_shipping()
        day=today_bounds()[0];self.day_label.configure(text='DZISIAJ  ·  '+day+'  ·  ALLEGRO')
        snap=self.snapshot
        if snap is None or snap.day!=day:
            for key in ('units','value'):self.daily_values[key].configure(text='--')
            for key in ('units','value'):self.compact_values[key].configure(text={'units':'Sprzedane: --','value':'Sprzedaż: --'}[key])
            self.sync_hint.configure(text='Dzisiejsze dane niedostępne')
            self.daily_feedback.configure(text=self.sales_error or 'Odśwież dane.',text_color=RED)
            return
        self.daily_values['units'].configure(text=str(snap.units))
        self.daily_notes['units'].configure(text=f'{snap.orders} zamówień · wszystkie waluty')
        self.compact_values['units'].configure(text=f'Sprzedane: {snap.units} szt. / {snap.orders} zam.')
        try:
            total=self.total_view()
        except RateError as exc:
            self.daily_values['value'].configure(text='Brak kursów');self.compact_values['value'].configure(text='Brak kursów NBP')
            raw=' · '.join(amount(group.value,code) for code,group in (snap.by_currency or {snap.currency:snap}).items())
            self.daily_feedback.configure(text=(self.rate_error or str(exc))+'\nSprzedaż z Allegro: '+raw,text_color=RED);return
        self.daily_values['value'].configure(text=pln(total.value))
        self.compact_values['value'].configure(text='Sprzedaż: '+pln(total.value))
        self.daily_notes['value'].configure(text='wszystkie waluty → PLN · bez dostawy')
        stamp=datetime.fromisoformat(snap.fetched_at).strftime('%H:%M');self.sync_hint.configure(text=f'{snap.login} · aktualizacja {stamp}')
        info=self.daily_overview
        feedback=(f"Dzisiaj: {info['total']} zamówień · potwierdzone: {info['ready']} · oczekujące: {info['waiting']} · anulowane / zwrócone: {info['cancelled']}" if info else f'Dane z {day}, czas polski.')
        foreign=any(c!='PLN' for c in (snap.by_currency or {snap.currency:snap}))
        if foreign:
            feedback+='\nŁącznie w PLN — '+('szacunek według '+self.rate_book.source+' z ')+self.rate_book.date+(' (zapisany kurs).' if self.rate_book.cached else '.')+' Kurs wypłaty Allegro może być inny.'
            if self.rate_book.checked_at:feedback+=' Sprawdzono '+datetime.fromisoformat(self.rate_book.checked_at).strftime('%H:%M')+'.'
        self.daily_feedback.configure(text=feedback,text_color=MUTED)
    def auto_rates(self):
        if self.closing:return
        self.after(60000,self.auto_rates)
        snap=self.snapshot
        if snap is None or snap.day!=today_bounds()[0] or self.sales_running or self.orders_running or self.rates_running:return
        currencies=set(snap.by_currency or {snap.currency:snap})
        if not currencies-{'PLN'}:return
        generation=self.sync_generation;account=snap.account;day=snap.day
        self.rates_running=True
        def worker():
            try:book=self.fx_service.fetch(currencies);error=None
            except RateError as exc:book=None;error=str(exc)
            except Exception:book=None;error='Nie udało się odświeżyć kursów NBP. Ponowię automatycznie.'
            self.events.put((self.rates_refresh_done,(generation,account,day,currencies,book,error)))
        threading.Thread(target=worker,daemon=True).start()
    def rates_refresh_done(self,generation,account,day,currencies,book,error):
        self.rates_running=False
        snap=self.snapshot
        if generation!=self.sync_generation or snap is None or snap.account!=account or snap.day!=day:return
        if currencies!=set(snap.by_currency or {snap.currency:snap}):return
        self.rates_done(book,error);self.render_daily()

    def day_watch(self):
        if self.closing:return
        day=today_bounds()[0]
        if day!=self.day_key:
            self.day_key=day;self.snapshot=None;self.render_daily();self.sync_sales()
        self.after(30000,self.day_watch)

    def auto_sync(self):
        if not self.closing:
            self.render_daily();self.sync_sales();self.after(300000,self.auto_sync)

    def show_sales_details(self):
        existing=getattr(self,'cost_dialog',None)
        if existing is not None and existing.winfo_exists():existing.lift();return
        win=ctk.CTkToplevel(self);self.cost_dialog=win;win.title('Dzisiejsza sprzedaż i koszty');win.geometry('780x700');win.minsize(650,600);win.transient(self);win.grab_set()
        body=ctk.CTkScrollableFrame(win,fg_color=BG);body.pack(fill='both',expand=True,padx=15,pady=15)
        Label(body,text='Dzisiejsza sprzedaż',font=ctk.CTkFont(size=24,weight='bold')).pack(anchor='w',pady=(5,12))
        snap=self.snapshot
        if snap is None or snap.day!=today_bounds()[0]:
            Label(body,text=self.sales_error or 'Dane nie zostały jeszcze pobrane.',wraplength=620,justify='left',text_color=MUTED).pack(anchor='w',pady=15)
            Label(body,text='Statystyki wymagają odczytu zamówień Allegro.\nW konfiguracji aplikacji w Allegro zaznacz allegro:api:orders:read,\na następnie połącz konto ponownie w Integracja Allegro.',wraplength=620,justify='left',text_color=MUTED).pack(anchor='w',pady=15)
            def connect():win.destroy();self.integration_info()
            Button(body,'Integracja Allegro',connect,primary=True).pack(anchor='w',pady=10)
            def refresh():win.destroy();self.sync_sales()
            Button(body,'Odśwież sprzedaż',refresh).pack(anchor='w',pady=10)
        else:
            try:snap=self.total_view()
            except RateError as exc:
                Label(body,text=self.rate_error or str(exc),text_color=RED,wraplength=620).pack(pady=15)
                Button(body,'Zamknij',win.destroy).pack(pady=15);return
            Label(body,text='Łączna sprzedaż i koszty: PLN — wszystkie waluty',text_color=RED,font=ctk.CTkFont(size=16,weight='bold')).pack(anchor='w',pady=(0,10))
            if self.total_profit() is None:
                Label(body,text='Sprzedaż jest pobrana. Aby pokazać zysk, wpisz niżej koszty towaru i opłaty.\nBez tych danych można pokazać wartość sprzedaży, ale nie rzetelny zysk.',text_color=RED,wraplength=650,justify='left').pack(anchor='w',pady=(0,15))
            Label(body,text=f'{snap.day}  ·  {snap.login}\n{snap.units} szt. / {snap.orders} zamówień  ·  {amount(snap.value,snap.currency)}',justify='left',font=ctk.CTkFont(size=16)).pack(anchor='w')
            Label(body,text='Zysk szacunkowy: '+(pln(self.total_profit()) if self.total_profit() is not None else 'uzupełnij koszty'),font=ctk.CTkFont(size=24,weight='bold'),text_color=RED).pack(anchor='w',pady=(18,5))
            Label(body,text='Uzupełnij koszty sprzedanych dziś produktów',font=ctk.CTkFont(size=18,weight='bold')).pack(anchor='w',pady=(22,10))
            previous_costs=self.total_costs.get(snap.account,snap.day);fields=[]
            for i,title in enumerate((f'Koszt zakupu sprzedanych sztuk ({snap.currency})',f'Prowizje i opłaty Allegro ({snap.currency})',f'Wysyłka, opakowanie i inne koszty ({snap.currency})')):
                Label(body,text=title,text_color=MUTED).pack(anchor='w')
                var=tk.StringVar(value=str(previous_costs[i]) if previous_costs else '')
                ctk.CTkEntry(body,textvariable=var,height=35).pack(fill='x',pady=(3,10));fields.append(var)
            confirmed=tk.BooleanVar(value=False)
            ctk.CTkCheckBox(body,text='Sprawdziłem koszty sprzedanych dziś sztuk ze wszystkich walut',variable=confirmed).pack(anchor='w',pady=10)
            Label(body,text='Wpisz łączne koszty całej dzisiejszej sprzedaży w PLN.\nZysk szacunkowy = wartość produktów − podane koszty.\nTo wynik przed podatkiem, a nie stan wypłat ani pełne rozliczenie księgowe.',text_color=MUTED,justify='left',wraplength=650,font=ctk.CTkFont(size=14)).pack(anchor='w',pady=5)
            def save_costs():
                if not confirmed.get():messagebox.showinfo('Sprawdź koszty','Potwierdź sprawdzenie kosztów przed obliczeniem wyniku.',parent=win);return
                try:self.total_costs.save(snap.account,snap.day,*(v.get() for v in fields),snapshot=snap)
                except ValueError as exc:messagebox.showwarning('Koszty',str(exc),parent=win);return
                self.render_daily();win.destroy()
            Button(body,'Zapisz koszty i oblicz zysk',save_costs,primary=True,width=230).pack(anchor='w',pady=15)
            Label(body,text='Pozycje dzisiejszej sprzedaży',font=ctk.CTkFont(size=18,weight='bold')).pack(anchor='w',pady=(20,5))
            Label(body,text='Zakupy z dzisiejszego dnia w strefie Europe/Warsaw. Tylko potwierdzone\nzamówienia READY_FOR_PROCESSING, bez anulowanych i zwróconych.\nWartość produktów bez dostawy; obejmuje także pobrania, które nie są jeszcze wpływem.\nCzęściowe zwroty i późniejsze korekty nie są automatycznie rozliczane.',text_color=MUTED,justify='left',wraplength=650,font=ctk.CTkFont(size=14)).pack(anchor='w',pady=14)
            for line in snap.lines[:100]:
                Label(body,text=f"{line['quantity']} × {line['name'][:65]}  —  {amount(money(line['total']),snap.currency)}"+('  [pobranie]' if line['cod'] else ''),text_color=TEXT,wraplength=650,justify='left',anchor='w').pack(fill='x',pady=3)
        Button(body,'Zamknij',win.destroy).pack(anchor='w',pady=15)

    def logout(self):
        if self.busy_id is not None:
            messagebox.showinfo('Trwa analiza','Poczekaj na zakończenie analizy przed wylogowaniem.',parent=self);return
        if not self.confirm_pending():return
        session=getattr(self,'owner_session',None)
        if session is not None:
            try:session.forget()
            except Exception:
                messagebox.showerror('Wylogowanie','Nie udało się usunąć zapamiętanej sesji. Sprawdź dostęp do folderu aplikacji i spróbuj ponownie.',parent=self);return
        self.logout_requested=True;self.closing=True
        for ident in self.tk.call('after','info'):self.tk.call('after','cancel',ident)
        self.destroy()

    def close(self):
        listing=getattr(self,'listing_dialog',None)
        if listing is not None and listing.winfo_exists():
            if listing.busy:
                messagebox.showinfo('Allegro','Poczekaj na wynik zapisu oferty przed zamknięciem.',parent=self);return
            listing.close()
        # Pobieranie statystyk jest wyłącznie odczytem; nie blokuje zamknięcia.
        super().close()

if __name__=='__main__':
    from login_ui import run
    run()
