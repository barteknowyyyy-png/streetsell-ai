"""Shared StreetSell icon for login and application windows."""
from pathlib import Path
import os


def apply_icon(window):
    if os.name != 'nt':
        return
    icon = Path(__file__).with_name('streetsell.ico')
    def set_icon():
        try:
            window.iconbitmap(str(icon))
        except Exception:
            pass  # An icon failure must not prevent access to the inventory.
    set_icon()
    window.after(300, set_icon)  # Apply after CustomTkinter's default icon.
