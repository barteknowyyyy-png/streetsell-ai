"""Create an empty inventory only in a designated fresh installation.

Called after authentication, while the application's Windows instance lock is held.
Never copies, deletes or replaces an existing inventory.
"""
import json
import os
import tempfile
from pathlib import Path


def ensure_inventory(folder):
    folder = Path(folder)
    target = folder / 'streetsell.db'
    if target.exists():
        return False
    marker = folder / 'new_install.json'
    if not marker.is_file() or json.loads(marker.read_text()) .get('type') != 'clean-owner-install':
        raise ValueError('Brak bazy i oznaczenia nowej instalacji. Rozpakuj pełny pakiet do osobnego folderu.')
    # Do not silently enrol a directory containing another person's application data.
    for name in ('owner_auth.json', 'backups', 'media'):
        if (folder / name).exists():
            raise ValueError('Folder zawiera wcześniejsze dane. Rozpakuj pakiet do nowego, pustego folderu.')
    handle, temp_name = tempfile.mkstemp(prefix='fresh-', suffix='.db', dir=folder)
    os.close(handle)
    temp = Path(temp_name)
    try:
        from legacy import init_db
        from storage import Store
        init_db(temp)
        store = Store(temp)
        store.migrate()
        with store.connect() as connection:
            assert connection.execute('PRAGMA integrity_check').fetchone()[0] == 'ok'
            assert connection.execute('SELECT count(*) FROM products').fetchone()[0] == 0
        # Hard linking fails if target already exists: never overwrite an inventory.
        os.link(temp, target)
    finally:
        temp.unlink(missing_ok=True)
    return True
