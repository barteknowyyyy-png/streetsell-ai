import unittest,tempfile,json,sqlite3,hashlib
from pathlib import Path
from first_run import ensure_inventory
from storage import Store
from cloud_sync import Sync
from cloud_api import CloudError
from types import SimpleNamespace

class FreshTests(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name)
  (self.root/'new_install.json').write_text(json.dumps({'type':'clean-owner-install'}))
 def tearDown(self):self.temp.cleanup()
 def test_empty_migrated_inventory_and_repeat_preserves_data(self):
  self.assertTrue(ensure_inventory(self.root));s=Store(self.root/'streetsell.db')
  with s.connect() as c:
   self.assertEqual(c.execute('select count(*) from products').fetchone()[0],0)
   c.execute("insert into products(product_name) values('Drugi właściciel')")
  before=hashlib.sha256(s.path.read_bytes()).hexdigest()
  self.assertFalse(ensure_inventory(self.root));self.assertEqual(hashlib.sha256(s.path.read_bytes()).hexdigest(),before)
 def test_no_marker_no_creation(self):
  (self.root/'new_install.json').unlink()
  with self.assertRaises(ValueError):ensure_inventory(self.root)
  self.assertFalse((self.root/'streetsell.db').exists())
 def test_old_media_rejected(self):
  (self.root/'media').mkdir()
  with self.assertRaises(ValueError):ensure_inventory(self.root)
 def test_existing_database_never_changed_even_without_marker(self):
  p=self.root/'streetsell.db';p.write_bytes(b'existing-data')
  (self.root/'new_install.json').unlink();self.assertFalse(ensure_inventory(self.root));self.assertEqual(p.read_bytes(),b'existing-data')
 def test_owner_binding_blocks_different_user(self):
  ensure_inventory(self.root);s=Store(self.root/'streetsell.db')
  Sync(s,SimpleNamespace(url='https://test.supabase.co',user_id='second-owner'))
  with self.assertRaises(CloudError):Sync(s,SimpleNamespace(url='https://test.supabase.co',user_id='first-owner'))
  with s.connect() as c:self.assertEqual(c.execute('select user_id from ss_v4_owner').fetchone()[0],'second-owner')

if __name__=='__main__':unittest.main(verbosity=2)
