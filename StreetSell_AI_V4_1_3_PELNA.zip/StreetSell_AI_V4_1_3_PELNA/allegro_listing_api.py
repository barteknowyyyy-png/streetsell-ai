"""Versioned Allegro offer API. OAuth stays in WindowsVault; no secrets in payload logs."""
import json,re,ssl,time,urllib.request,urllib.error,urllib.parse
from dataclasses import dataclass
from allegro_api import AllegroClient,AllegroError,NoRedirect

@dataclass
class Response:
    data:dict
    status:int=200
    location:str=''

class ListingError(AllegroError):
    def __init__(self,message,status=0):super().__init__(message);self.status=status

class OfferAPI:
    def __init__(self,client=None,transport=None):
        self.client=client or AllegroClient();self.env=self.client.env;self.transport=transport
        self.profile=self.client.profile();self.account=self.profile['id']

    def request(self,path,method='GET',data=None,binary=None,content_type=None):
        upload=path.startswith('/sale/images')
        origin=('https://upload.allegro.pl' if self.env=='production' else 'https://upload.allegro.pl.allegrosandbox.pl') if upload else self.client.api_url
        if not path.startswith('/') or path.startswith('//') or re.search(r'[\r\n\\]',path):raise ListingError('Nieprawidłowy adres API.')
        for attempt in range(2):
            with self.client.lock:
                config=self.client._config();tokens=self.client.state().get('tokens') or {}
                if not tokens.get('access_token'):raise ListingError('Połącz ponownie Allegro z uprawnieniami do ofert i ustawień sprzedaży.')
                token=tokens['access_token']
                if float(tokens.get('expires_at',0))<time.time()+60:token=self.client._refresh(config,tokens)
                headers=self.client._headers(config,token)
            headers['Content-Type']=content_type or 'application/vnd.allegro.public.v1+json'
            raw=binary if binary is not None else (json.dumps(data,ensure_ascii=False,allow_nan=False).encode() if data is not None else None)
            try:
                if self.transport:return self.transport(origin+path,method,headers,raw)
                try:
                    import certifi
                    context=ssl.create_default_context(cafile=certifi.where())
                except ImportError:context=ssl.create_default_context()
                opener=urllib.request.build_opener(NoRedirect(),urllib.request.HTTPSHandler(context=context))
                req=urllib.request.Request(origin+path,data=raw,headers=headers,method=method)
                with opener.open(req,timeout=30) as r:
                    body=r.read(8*1024*1024+1)
                    if len(body)>8*1024*1024:raise ListingError('Zbyt duża odpowiedź Allegro.')
                    value=json.loads(body) if body else {}
                    if not isinstance(value,dict):raise ListingError('Nieprawidłowa odpowiedź Allegro.')
                    return Response(value,r.status,r.headers.get('Location',''))
            except urllib.error.HTTPError as exc:
                if exc.code==303:
                    location=exc.headers.get('Location','');exc.close();return Response({},303,location)
                status=exc.code
                try:payload=json.loads(exc.read(65536))
                except Exception:payload={}
                finally:exc.close()
                if status==401 and attempt==0:
                    with self.client.lock:self.client._refresh(config,self.client.state().get('tokens') or {})
                    continue
                errors=payload.get('errors') or []
                message='; '.join((str(e.get('path') or '')+': '+str(e.get('userMessage') or e.get('message') or e.get('code') or 'Błąd')).strip(': ') for e in errors if isinstance(e,dict))
                if status in (401,403):message='Połącz ponownie Allegro. Wymagane uprawnienia: odczyt i zapis ofert oraz odczyt ustawień sprzedaży. '+message
                raise ListingError((message or f'Allegro: HTTP {status}')[:3000],status) from None
            except (urllib.error.URLError,TimeoutError,OSError):raise ListingError('Przerwano połączenie z Allegro. Sprawdź status operacji przed ponowieniem.') from None
            except (json.JSONDecodeError,UnicodeError):raise ListingError('Nieprawidłowy JSON z Allegro. Sprawdź status operacji.') from None

    def verify_identity(self):
        current=self.client.profile()
        if current['id']!=self.account:raise ListingError('Konto Allegro zostało zmienione. Otwórz formularz ponownie.')

    def get(self,path):return self.request(path).data
    def collection(self,path,key,limit=None):
        if limit is None:return self.get(path).get(key,[])
        rows=[];offset=0
        while True:
            separator='&' if '?' in path else '?'
            data=self.get(path+separator+urllib.parse.urlencode({'limit':limit,'offset':offset}));page=data.get(key,[])
            rows.extend(page)
            if len(page)<limit or len(rows)>=int(data.get('totalCount',len(rows))):return rows
            offset+=len(page)

    def settings(self):
        resources={'shipping':('/sale/shipping-rates','shippingRates'),
         'returns':('/after-sales-service-conditions/return-policies?limit=60','returnPolicies'),
         'implied':('/after-sales-service-conditions/implied-warranties?limit=60','impliedWarranties'),
         'warranties':('/after-sales-service-conditions/warranties?limit=60','warranties'),
         'producers':('/sale/responsible-producers','responsibleProducers'),
         'persons':('/sale/responsible-persons','responsiblePersons'),
         'rules':('/sale/price-automation/rules','rules')}
        result={};warnings=[]
        for name,(path,key) in resources.items():
            try:result[name]=self.collection(path,key,1000 if name in ('producers','persons') else None)
            except ListingError as e:
                if e.status in (401,403):raise
                result[name]=[];warnings.append(name+': '+str(e))
        result['warnings']=warnings;return result

    def products(self,phrase,gtin=False,page=None):
        params={'phrase':phrase,'language':'pl-PL'}
        if gtin:params['mode']='GTIN'
        if page:params['page.id']=page
        return self.get('/sale/products?'+urllib.parse.urlencode(params))

    def product(self,uid):return self.get('/sale/products/'+urllib.parse.quote(str(uid),safe=''))
    def parameters(self,category):return self.get('/sale/categories/'+urllib.parse.quote(str(category),safe='')+'/parameters').get('parameters',[])
    def offers(self,query=''):
        return self.get('/sale/offers?'+urllib.parse.urlencode({'limit':50,'name':query})).get('offers',[])
    def find_external(self,external):return self.get('/sale/offers?'+urllib.parse.urlencode({'external.id':external,'limit':100})).get('offers',[])
    def offer(self,uid):return self.get('/sale/product-offers/'+str(uid))
    def rules(self,uid):return self.get('/sale/price-automation/offers/'+str(uid)+'/rules').get('rules',[])
    def upload(self,raw,ai=False):
        r=self.request('/sale/images?isAiCoCreated='+('true' if ai else 'false'),'POST',binary=raw,content_type='image/jpeg')
        url=r.data.get('location')
        if not isinstance(url,str) or not url.startswith('https://'):raise ListingError('Allegro nie potwierdziło przesłania zdjęcia.')
        return url

    def operation_path(self,location):
        if location.startswith('/'):
            path=location
        else:
            parsed=urllib.parse.urlsplit(location);base=urllib.parse.urlsplit(self.client.api_url)
            if parsed.scheme!='https' or parsed.hostname!=base.hostname or parsed.username or parsed.password or parsed.port not in (None,443):raise ListingError('Niezaufany adres statusu Allegro.')
            path=parsed.path+('?' + parsed.query if parsed.query else '')
        if not re.fullmatch(r'/sale/product-offers/[A-Za-z0-9-]+/operations/[A-Za-z0-9-]+',path):raise ListingError('Nieprawidłowy adres operacji Allegro.')
        return path
