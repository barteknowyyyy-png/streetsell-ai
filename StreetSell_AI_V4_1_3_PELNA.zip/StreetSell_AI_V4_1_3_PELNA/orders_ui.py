"""Osobna sekcja zamówień i szczegóły odczytywane z Allegro."""
import tkinter as tk
from tkinter import ttk,messagebox
import threading
from datetime import datetime
import webbrowser
import customtkinter as ctk
from allegro_api import AllegroError
from page_scroll import PAGE_SIZE
from ui_performance import visible_rows
from orders import PERIODS,FILTERS,matches,state_text,payment_text,amount_text,timestamp
from daily_sales import WARSAW,money,pln

BG='#0b0e13';PANEL='#141820';FIELD='#1b202a';TEXT='#f4f6fa';MUTED='#96a0b1';RED='#f3344e'

class OrdersPanel(ctk.CTkFrame):
    def __init__(self,parent,app):
        super().__init__(parent,fg_color='transparent');self.app=app;self.snapshot=None;self.details_running=False;self.page_number=0;self.search_pending=None
        tools=ctk.CTkFrame(self,fg_color='transparent');tools.pack(fill='x',pady=(0,10))
        self.period=tk.StringVar(value='Ostatnie 30 dni');self.status=tk.StringVar(value='Wszystkie');self.query=tk.StringVar()
        self.period_menu=ctk.CTkOptionMenu(tools,variable=self.period,values=list(PERIODS),width=180,height=42,font=ctk.CTkFont(size=16),fg_color=FIELD,button_color=FIELD,button_hover_color='#272e3a',
            command=lambda _:self.app.sync_orders())
        self.period_menu.pack(side='left',padx=(0,8))
        ctk.CTkOptionMenu(tools,variable=self.status,values=list(FILTERS),width=220,height=42,font=ctk.CTkFont(size=16),fg_color=FIELD,button_color=FIELD,button_hover_color='#272e3a',
            command=lambda _:self.render()).pack(side='left',padx=(0,8))
        ctk.CTkEntry(tools,textvariable=self.query,placeholder_text='Produkt, kupujący, numer…',width=150,height=42,font=ctk.CTkFont(size=16),fg_color=FIELD,border_color='#272e3a',text_color=TEXT).pack(side='left',fill='x',expand=True)
        self.query.trace_add('write',lambda *_:self.schedule_search())
        self.refresh=ctk.CTkButton(tools,text='Synchronizuj',command=app.sync_orders,width=135,height=42,font=ctk.CTkFont(size=16),fg_color=RED,hover_color='#c92740');self.refresh.pack(side='right',padx=(8,0))
        actions=ctk.CTkFrame(self,fg_color='transparent');actions.pack(fill='x',pady=(0,8))
        ctk.CTkButton(actions,text='Dzisiejsza sprzedaż i koszty',command=app.show_sales_details,width=245,height=42,fg_color=FIELD).pack(side='left')
        ctk.CTkButton(actions,text='Otwórz zamówienia w Allegro',command=lambda:webbrowser.open('https://salescenter.allegro.com/orders'),width=265,height=42,fg_color=FIELD).pack(side='left',padx=8)
        self.hint=ctk.CTkLabel(self,text='Lista nie została jeszcze pobrana. Kliknij Synchronizuj.',text_color=MUTED,anchor='w',wraplength=780)
        self.hint.pack(fill='x',pady=(0,8))
        frame=ctk.CTkFrame(self,fg_color=PANEL);frame.pack(fill='both',expand=True)
        columns=('date','buyer','products','total','payment','state')
        self.tree=ttk.Treeview(frame,columns=columns,displaycolumns=('date','products','total','state'),show='headings',selectmode='browse',height=5)
        for key,title,width in zip(columns,('Zakup (PL)','Kupujący','Produkt / kupujący','Razem','Płatność','Status / płatność'),(130,120,300,155,170,185)):
            self.tree.heading(key,text=title);self.tree.column(key,width=width,minwidth=95,stretch=key=='products')
        ys=ctk.CTkScrollbar(frame,command=self.tree.yview);xs=ctk.CTkScrollbar(frame,orientation='horizontal',command=self.tree.xview)
        self.tree.configure(yscrollcommand=ys.set,xscrollcommand=xs.set)
        ys.grid(row=0,column=1,sticky='ns');ys._wheel_target=self.tree
        frame.rowconfigure(0,weight=1);frame.columnconfigure(0,weight=1)
        self.tree.grid(row=0,column=0,sticky='nsew',padx=(4,0),pady=(4,0))
        self.tree.bind('<<TreeviewSelect>>',lambda _:self.controls());self.tree.bind('<Double-1>',lambda _:self.show_details())
        bottom=ctk.CTkFrame(self,fg_color='transparent');bottom.pack(side='bottom',fill='x',pady=(10,0),before=frame)
        self.detail_button=ctk.CTkButton(bottom,text='Szczegóły zamówienia',command=self.show_details,fg_color=RED,state='disabled',height=44,width=230);self.detail_button.pack(side='left')
        ctk.CTkButton(bottom,text='<',width=40,command=lambda:self.change_page(-1),fg_color=FIELD).pack(side='left',padx=(12,4))
        self.page_label=ctk.CTkLabel(bottom,text='1 / 1');self.page_label.pack(side='left',padx=4)
        ctk.CTkButton(bottom,text='>',width=40,command=lambda:self.change_page(1),fg_color=FIELD).pack(side='left',padx=4)
        self.count=ctk.CTkLabel(bottom,text='0 zamówień',text_color=MUTED);self.count.pack(side='right')
    def schedule_search(self):
        if self.search_pending is not None:self.after_cancel(self.search_pending)
        self.search_pending=self.after(180,self.finish_search)
    def finish_search(self):
        self.search_pending=None;self.page_number=0;self.render()

    def change_page(self,step):
        rows=self.snapshot.orders if self.snapshot else []
        count=sum(matches(o,self.query.get(),self.status.get()) for o in rows)
        self.page_number=max(0,min(max(0,(count-1)//PAGE_SIZE),self.page_number+step))
        self.render();self.app.page_scroll.top()

    def controls(self):
        self.detail_button.configure(state='normal' if self.tree.selection() and not self.details_running else 'disabled')
    def render(self):
        if not hasattr(self,'tree'):return
        selection=self.tree.selection();self.tree.delete(*self.tree.get_children())
        rows=self.snapshot.orders if self.snapshot else []
        filtered=[o for o in rows if matches(o,self.query.get(),self.status.get())]
        pages=max(1,(len(filtered)+PAGE_SIZE-1)//PAGE_SIZE);self.page_number=min(self.page_number,pages-1)
        visible=filtered[self.page_number*PAGE_SIZE:(self.page_number+1)*PAGE_SIZE]
        self.tree.configure(height=visible_rows(len(visible)));self.page_label.configure(text=f'{self.page_number+1} / {pages}')
        for order in visible:
            date=timestamp(order['bought_at']).astimezone(WARSAW).strftime('%d.%m %H:%M')
            products='; '.join(f"{l['quantity']} × {l['name']}" for l in order['lines'])+'\n'+order['buyer']
            payment='Pobranie' if order['payment_type']=='CASH_ON_DELIVERY' else ('Opłacone' if payment_text(order)=='Opłacone' else 'Sprawdź płatność')
            if order['status'] in ('BOUGHT','FILLED_IN'):payment='W trakcie'
            state=state_text(order).replace('Oczekuje na płatność','Nieopłacone')
            self.tree.insert('','end',iid=order['id'],values=(date,order['buyer'],products,amount_text(order),payment_text(order),state+'\n'+payment))
        if selection and self.tree.exists(selection[0]):self.tree.selection_set(selection[0])
        ready=sum(matches(o,status='Do realizacji') for o in filtered)
        self.count.configure(text=f'{len(filtered)} / {len(rows)} zamówień  ·  do realizacji: {ready}')
        self.controls();self.app.page_scroll.schedule()
    def received(self,snapshot,error=''):
        if error:
            # Nie udajemy aktualnego stanu danymi z poprzedniego połączenia.
            self.snapshot=None;self.hint.configure(text='Błąd synchronizacji: '+error,text_color=RED)
        else:
            self.snapshot=snapshot
            period=next(k for k,v in PERIODS.items() if v==snapshot.days)
            stamp=datetime.fromisoformat(snapshot.fetched_at).strftime('%d.%m.%Y %H:%M')
            self.hint.configure(text=f'{snapshot.login}  ·  {period}  ·  aktualizacja {stamp}. Dwuklik otwiera szczegóły. Lista zawiera także nieopłacone i anulowane.',text_color=MUTED)
        self.render()
    def show_details(self):
        if self.details_running or not self.snapshot or not self.tree.selection():return
        ident=self.tree.selection()[0];account=self.snapshot.account;generation=self.app.sync_generation
        self.details_running=True;self.controls()
        self.hint.configure(text='Pobieram aktualne dane zamówienia i numery przesyłek…')
        def worker():
            try:self.app.events.put((self.details_done,(self.app.orders_service.details(account,ident),None,generation)))
            except Exception as exc:
                text=str(exc) if isinstance(exc,AllegroError) else 'Nie udało się pobrać szczegółów. Sprawdź połączenie i spróbuj ponownie.'
                self.app.events.put((self.details_done,(None,text,generation)))
        threading.Thread(target=worker,daemon=True).start()
    def details_done(self,result,error,generation=None):
        self.details_running=False;self.controls()
        if generation is not None and generation!=self.app.sync_generation:return
        if error:self.hint.configure(text=error,text_color=RED);return
        self.hint.configure(text='Pobrano aktualne szczegóły zamówienia.',text_color=MUTED)
        try:text=detail_text(result)
        except Exception:
            self.hint.configure(text='Allegro zwróciło niepełne szczegóły. Odśwież i spróbuj ponownie.',text_color=RED);return
        win=ctk.CTkToplevel(self.app);win.title('Szczegóły zamówienia Allegro');win.geometry('960x800');win.minsize(650,500);win.transient(self.app);win.grab_set()
        form=result['form']
        ctk.CTkLabel(win,text='Zamówienie '+form['id'],font=ctk.CTkFont(size=17,weight='bold')).pack(anchor='w',padx=20,pady=(15,8))
        box=ctk.CTkTextbox(win,wrap='word',fg_color=PANEL,font=ctk.CTkFont(size=17));box.pack(fill='both',expand=True,padx=20,pady=5)
        box.insert('1.0',text);box.configure(state='disabled')
        ctk.CTkButton(win,text='Zamknij',command=win.destroy,fg_color=RED).pack(pady=15)

def detail_text(result):
    form=result['form'];buyer=form.get('buyer') or {};delivery=form.get('delivery') or {};address=delivery.get('address') or {}
    pickup=delivery.get('pickupPoint') or {};payment=form.get('payment') or {};invoice=form.get('invoice') or {}
    from orders import normalized
    row=normalized(form)
    lines=[f"Kupujący: {buyer.get('login') or '—'}",f"Status: {state_text(row)}",f"Płatność: {payment_text(row)}",f"Do zapłaty: {amount_text(row)}"]
    if row['paid']:lines.append(f"Wpłacono według Allegro: {row['paid']} {row['paid_currency']}")
    lines+=['','PRODUKTY']
    for item in row['lines']:
        lines.append(f"{item['quantity']} × {item['name']} — {item['price']} {item['currency']} / szt.\nOferta: {item['offer_id'] or '—'} | numer własny: {item['external_id'] or '—'}")
    lines+=['',f"DOSTAWA: {row['delivery']}"]
    if address:
        lines+=[str(address.get('companyName') or ''),' '.join(str(address.get(k) or '') for k in ('firstName','lastName')),str(address.get('street') or ''),
            ' '.join(str(address.get(k) or '') for k in ('zipCode','city','countryCode')),f"Telefon: {address.get('phoneNumber') or '—'}"]
    else:lines.append('Adres dostawy nie jest dostępny. Dla niepotwierdzonych zakupów dane mogą się jeszcze zmienić.')
    if pickup:
        pa=pickup.get('address') or {}
        lines += [f"Punkt odbioru: {pickup.get('name') or ''} ({pickup.get('id') or ''})",' '.join(str(pa.get(k) or '') for k in ('street','zipCode','city'))]
    if buyer.get('email'):lines.append('E-mail Allegro: '+str(buyer['email']))
    lines+=['','PRZESYŁKI']
    for shipment in result['shipments']:
        lines.append(f"{shipment.get('carrierName') or shipment.get('carrierId') or 'Przewoźnik'}: {shipment.get('waybill') or 'Brak numeru'}")
    if not result['shipments']:lines.append('Brak przypisanych numerów przesyłek.' if not result['warning'] else 'Nie udało się sprawdzić przesyłek: '+result['warning'])
    lines+=['',f"Faktura wymagana: {'tak' if invoice.get('required') else 'nie'}"]
    if invoice.get('required'):
        lines.append(json_invoice(invoice.get('address') or {}))
    if form.get('messageToSeller'):lines+=['','WIADOMOŚĆ OD KUPUJĄCEGO',str(form['messageToSeller'])]
    lines+=['','Pobranie i potwierdzenie zakupu nie oznaczają wypłaty na konto. Etykiety i zmiany statusów obsłużysz obecnie w Allegro.']
    return '\n'.join(line for line in lines if line is not None)

def json_invoice(address):
    company=address.get('company') or {};person=address.get('naturalPerson') or {}
    return '\n'.join(str(value) for value in [company.get('name'),company.get('taxId'),
        ' '.join(str(person.get(k) or '') for k in ('firstName','lastName')),address.get('street'),
        ' '.join(str(address.get(k) or '') for k in ('zipCode','city','countryCode'))] if value)
