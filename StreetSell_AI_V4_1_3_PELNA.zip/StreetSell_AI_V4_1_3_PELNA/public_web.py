"""Ograniczone pobieranie publicznych zasobów HTTPS, bez cookies i tokenów kont."""
import http.client
import ipaddress
import socket
import ssl
import time
from dataclasses import dataclass
from urllib.parse import urlsplit,urlunsplit,urljoin,quote

class WebError(ValueError):pass
class Stopped(WebError):pass

def https_url(value):
    if not isinstance(value,str) or not value.strip() or len(value)>8192:
        raise WebError('Wklej pełny publiczny adres HTTPS.')
    value=value.strip()
    if any(c.isspace() or ord(c)<32 for c in value) or '\\' in value:
        raise WebError('Nieprawidłowy adres internetowy.')
    try:
        p=urlsplit(value)
        if p.scheme.lower()!='https' or not p.hostname or p.username is not None or p.password is not None or p.port not in (None,443):
            raise ValueError()
        host=p.hostname.encode('idna').decode('ascii').lower().rstrip('.')
        if host=='localhost' or host.endswith(('.local','.localhost','.internal')):raise ValueError()
        try:
            ip=ipaddress.ip_address(host)
        except ValueError:ip=None
        if ip is not None and not ip.is_global:raise ValueError()
        netloc='['+host+']' if ':' in host else host
        path=quote(p.path or '/',safe='/%:@&=+$,;~!*()-._')
        query=quote(p.query,safe='/%:@&=+$,;~!*()-._?')
        return urlunsplit(('https',netloc,path,query,''))
    except (ValueError,UnicodeError):
        raise WebError('Użyj publicznego adresu HTTPS bez danych logowania i niestandardowego portu.') from None

class PinnedHTTPS(http.client.HTTPSConnection):
    def __init__(self,host,address,timeout):
        super().__init__(host,timeout=timeout,context=ssl.create_default_context())
        self.address=address
    def connect(self):
        raw=socket.create_connection((self.address,443),timeout=self.timeout)
        try:self.sock=self._context.wrap_socket(raw,server_hostname=self.host)
        except Exception:raw.close();raise

@dataclass
class Fetched:
    url:str
    body:bytes
    content_type:str

class PublicWeb:
    def __init__(self,resolver=socket.getaddrinfo,connection=PinnedHTTPS):
        self.resolver=resolver;self.connection=connection
    def address(self,host):
        try:
            values=self.resolver(host,443,type=socket.SOCK_STREAM)
            addresses=list(dict.fromkeys(r[4][0] for r in values))
            if not addresses or any(not ipaddress.ip_address(ip).is_global for ip in addresses):
                raise WebError('Adres prowadzi do sieci lokalnej lub niepublicznej.')
            return addresses[0]
        except (socket.gaierror,OSError,ValueError):
            raise WebError('Nie można ustalić publicznego adresu serwera.') from None
    def fetch(self,url,max_bytes=3*1024*1024,cancel=None,deadline=None):
        url=https_url(url)
        deadline=deadline or time.monotonic()+25
        for _ in range(5):
            if cancel is not None and cancel.is_set():raise Stopped('Przerwano pobieranie.')
            if time.monotonic()>=deadline:raise WebError('Serwer odpowiada zbyt długo.')
            p=urlsplit(url);address=self.address(p.hostname)
            if time.monotonic()>=deadline:raise WebError('Przekroczono czas pobierania.')
            if cancel is not None and cancel.is_set():raise Stopped('Przerwano pobieranie.')
            con=self.connection(p.hostname,address,min(8,max(.1,deadline-time.monotonic())))
            try:
                con.request('GET',urlunsplit(('','',p.path,p.query,'')),headers={
                    'User-Agent':'StreetSellAI/3.0.6', 'Accept':'text/html,application/ld+json,image/*;q=0.9,*/*;q=0.5',
                    'Accept-Encoding':'identity','Connection':'close'})
                response=con.getresponse()
                if response.status in (301,302,303,307,308):
                    location=response.getheader('Location')
                    if not location:raise WebError('Serwer zwrócił niepełne przekierowanie.')
                    url=https_url(urljoin(url,location));continue
                if response.status!=200:
                    if response.status in (403,429):raise WebError('Serwis ogranicza automatyczny dostęp. Spróbuj linku z innego źródła.')
                    raise WebError('Nie udało się pobrać zasobu ze strony (HTTP '+str(response.status)+').')
                if response.getheader('Content-Encoding','identity').lower() not in ('identity',''):
                    raise WebError('Serwer zwrócił nieobsługiwany format transmisji.')
                length=response.getheader('Content-Length')
                if length:
                    try:size=int(length)
                    except ValueError:raise WebError('Nieprawidłowa długość odpowiedzi.') from None
                    if size>max_bytes:raise WebError('Plik jest zbyt duży do podglądu.')
                chunks=[];total=0
                while True:
                    if cancel is not None and cancel.is_set():raise Stopped('Przerwano pobieranie.')
                    if time.monotonic()>=deadline:raise WebError('Przekroczono czas pobierania.')
                    chunk=response.read(min(65536,max_bytes-total+1))
                    if not chunk:break
                    total+=len(chunk)
                    if total>max_bytes:raise WebError('Plik jest zbyt duży do podglądu.')
                    chunks.append(chunk)
                return Fetched(url,b''.join(chunks),response.getheader('Content-Type','').split(';')[0].lower())
            except WebError:raise
            except (OSError,TimeoutError,http.client.HTTPException):
                raise WebError('Nie można pobrać danych z serwera. Sprawdź połączenie lub wybierz inne źródło.') from None
            finally:con.close()
        raise WebError('Serwis wykonał zbyt wiele przekierowań.')
