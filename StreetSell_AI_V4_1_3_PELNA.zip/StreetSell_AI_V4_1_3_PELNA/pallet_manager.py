"""StreetSell AI: katalog palet i bezpieczna archiwizacja zbiorcza.

Modul nie usuwa produktow, zdjec ani powiazan z Allegro.
Wymaga obiektu Store z metoda connect() oraz modulu inventory_sync.
"""
from datetime import datetime, timezone


def _now():
    return datetime.now(timezone.utc).isoformat()


def setup(store):
    import inventory_sync
    inventory_sync.setup(store)
    with store.connect() as con:
        con.execute('''CREATE TABLE IF NOT EXISTS pallets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            number TEXT NOT NULL UNIQUE,
            invoice TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL,
            archived_at TEXT
        )''')
        con.execute('''CREATE TABLE IF NOT EXISTS pallet_products (
            product_id INTEGER PRIMARY KEY,
            pallet_id INTEGER NOT NULL REFERENCES pallets(id)
        )''')
        con.execute('CREATE INDEX IF NOT EXISTS pallet_products_by_pallet ON pallet_products(pallet_id)')
        con.execute('''CREATE TABLE IF NOT EXISTS pallet_archive_items (
            pallet_id INTEGER NOT NULL,
            product_id INTEGER NOT NULL,
            PRIMARY KEY (pallet_id, product_id)
        )''')


def create_pallet(store, invoice=''):
    setup(store)
    with store.connect() as con:
        con.execute('BEGIN IMMEDIATE')
        cursor = con.execute('INSERT INTO pallets(number,invoice,created_at) VALUES(?,?,?)',
                             ('TEMP-' + _now(), str(invoice).strip(), _now()))
        number = f'PAL-{cursor.lastrowid:04d}'
        con.execute('UPDATE pallets SET number=? WHERE id=?', (number, cursor.lastrowid))
    return number


def list_pallets(store, archived=False):
    setup(store)
    clause = 'IS NOT NULL' if archived else 'IS NULL'
    with store.connect() as con:
        return con.execute(f'''SELECT p.*, COUNT(pp.product_id) AS product_count
            FROM pallets p LEFT JOIN pallet_products pp ON pp.pallet_id=p.id
            WHERE p.archived_at {clause}
            GROUP BY p.id ORDER BY p.id DESC''').fetchall()


def assign_product(store, pallet_number, product_id):
    setup(store)
    with store.connect() as con:
        pallet = con.execute('SELECT id FROM pallets WHERE number=? AND archived_at IS NULL',
                             (pallet_number,)).fetchone()
        if pallet is None:
            raise ValueError('Nie znaleziono aktywnej palety.')
        if con.execute('SELECT 1 FROM products WHERE id=?', (product_id,)).fetchone() is None:
            raise ValueError('Nie znaleziono produktu.')
        previous = con.execute('SELECT pallet_id FROM pallet_products WHERE product_id=?',
                               (product_id,)).fetchone()
        if previous and previous['pallet_id'] != pallet['id']:
            old = con.execute('SELECT archived_at FROM pallets WHERE id=?',
                              (previous['pallet_id'],)).fetchone()
            if old and old['archived_at'] is not None:
                raise ValueError('Nie można przenieść produktu ze zarchiwizowanej palety.')
        con.execute('''INSERT INTO pallet_products(product_id,pallet_id) VALUES(?,?)
            ON CONFLICT(product_id) DO UPDATE SET pallet_id=excluded.pallet_id''',
            (product_id, pallet['id']))


def pallet_products(store, pallet_number):
    setup(store)
    with store.connect() as con:
        return con.execute('''SELECT p.* FROM products p
            JOIN pallet_products pp ON pp.product_id=p.id
            JOIN pallets pl ON pl.id=pp.pallet_id
            WHERE pl.number=? ORDER BY p.id''', (pallet_number,)).fetchall()


def archive_pallet(store, pallet_number):
    setup(store)
    with store.connect() as con:
        con.execute('BEGIN IMMEDIATE')
        pallet = con.execute('SELECT id FROM pallets WHERE number=? AND archived_at IS NULL',
                             (pallet_number,)).fetchone()
        if pallet is None:
            raise ValueError('Nie znaleziono aktywnej palety.')
        ids = [r['product_id'] for r in con.execute(
            'SELECT product_id FROM pallet_products WHERE pallet_id=?', (pallet['id'],))]
        timestamp = _now()
        for pid in ids:
            exists = con.execute('SELECT 1 FROM inventory_archive WHERE product_id=?',
                                 (pid,)).fetchone()
            if exists is None:
                con.execute('INSERT INTO inventory_archive(product_id,archived_at,reason) VALUES(?,?,?)',
                            (pid, timestamp, f'Paleta {pallet_number}'))
                con.execute('INSERT OR IGNORE INTO pallet_archive_items(pallet_id,product_id) VALUES(?,?)',
                            (pallet['id'], pid))
        con.execute('UPDATE pallets SET archived_at=? WHERE id=?', (timestamp, pallet['id']))
    return len(ids)


def restore_pallet(store, pallet_number):
    setup(store)
    with store.connect() as con:
        con.execute('BEGIN IMMEDIATE')
        pallet = con.execute('SELECT id FROM pallets WHERE number=? AND archived_at IS NOT NULL',
                             (pallet_number,)).fetchone()
        if pallet is None:
            raise ValueError('Nie znaleziono zarchiwizowanej palety.')
        ids = [r['product_id'] for r in con.execute(
            'SELECT product_id FROM pallet_archive_items WHERE pallet_id=?', (pallet['id'],))]
        restored = 0
        for pid in ids:
            result = con.execute('DELETE FROM inventory_archive WHERE product_id=? AND reason=?',
                                 (pid, f'Paleta {pallet_number}'))
            restored += result.rowcount
        con.execute('DELETE FROM pallet_archive_items WHERE pallet_id=?', (pallet['id'],))
        con.execute('UPDATE pallets SET archived_at=NULL WHERE id=?', (pallet['id'],))
    return restored


def update_invoice(store, pallet_number, invoice):
    setup(store)
    with store.connect() as con:
        result = con.execute('UPDATE pallets SET invoice=? WHERE number=?',
                             (str(invoice).strip(), pallet_number))
        if result.rowcount == 0:
            raise ValueError('Nie znaleziono palety.')
