"""Odczyt danych galerii bez wykonywania JavaScript ze strony."""
import json
import re
from urllib.parse import urlsplit,unquote

MAX_GALLERY = 24


def asset_key(url):
    """Różne rozdzielczości tego samego zasobu Amazon to jedna propozycja."""
    parts=urlsplit(url)
    host=(parts.hostname or '').lower()
    if host in ('m.media-amazon.com','images-eu.ssl-images-amazon.com','images-na.ssl-images-amazon.com'):
        match=re.search(r'/images/I/([^/.]+)',parts.path)
        if match:return ('amazon',unquote(match.group(1)))
    return ('url',url)

class DataReader:
    """Mały parser samych danych: JSON, klucze w apostrofach, parseJSON(string)."""
    def __init__(self,text):self.text=text[:1000000];self.pos=0;self.nodes=0
    def space(self):
        while self.pos<len(self.text) and self.text[self.pos].isspace():self.pos+=1
    def string(self):
        quote=self.text[self.pos];self.pos+=1;result=[]
        while self.pos<len(self.text):
            c=self.text[self.pos];self.pos+=1
            if c==quote:return ''.join(result)
            if c!='\\':result.append(c);continue
            if self.pos>=len(self.text):break
            c=self.text[self.pos];self.pos+=1
            if c in ('u','x'):
                count=4 if c=='u' else 2
                digits=self.text[self.pos:self.pos+count]
                if len(digits)!=count or not re.fullmatch('[0-9a-fA-F]+',digits):raise ValueError('escape')
                result.append(chr(int(digits,16)));self.pos+=count
            elif c in "\\/'\"":result.append(c)
            elif c in 'bfnrt':result.append(dict(b='\b',f='\f',n='\n',r='\r',t='\t')[c])
            elif c=='\n':pass
            elif c=='\r':
                if self.text[self.pos:self.pos+1]=='\n':self.pos+=1
            else:raise ValueError('unsupported escape')
        raise ValueError('unfinished string')
    def value(self,depth=0):
        self.space();self.nodes+=1
        if depth>25 or self.nodes>3000 or self.pos>=len(self.text):raise ValueError('limit')
        c=self.text[self.pos]
        if c in "'\"":return self.string()
        if c in '[{':
            end=']' if c=='[' else '}';out=[] if c=='[' else {};self.pos+=1;self.space()
            while self.pos<len(self.text) and self.text[self.pos]!=end:
                if c=='{':
                    self.space()
                    if self.text[self.pos] not in "'\"":raise ValueError('key')
                    key=self.string();self.space()
                    if self.text[self.pos:self.pos+1]!=':':raise ValueError('colon')
                    self.pos+=1;out[key]=self.value(depth+1)
                else:out.append(self.value(depth+1))
                self.space()
                if self.text[self.pos:self.pos+1]==',':self.pos+=1;self.space()
                elif self.text[self.pos:self.pos+1]!=end:raise ValueError('separator')
            if self.text[self.pos:self.pos+1]!=end:raise ValueError('end')
            self.pos+=1;return out
        call=re.match(r'(?:A\.\$\.parseJSON|jQuery\.parseJSON|JSON\.parse|parseJSON)\s*\(',self.text[self.pos:])
        if call:
            self.pos+=call.end();self.space()
            if self.text[self.pos:self.pos+1] not in ("'",'"'):raise ValueError('literal required')
            encoded=self.string();self.space()
            if self.text[self.pos:self.pos+1]!=')':raise ValueError('call end')
            self.pos+=1
            return json.loads(encoded)
        match=re.match(r'null|true|false|-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?',self.text[self.pos:])
        if not match:raise ValueError('not data')
        self.pos+=match.end();return json.loads(match.group())


def script_gallery(script):
    results=[];aliases={}
    for match in list(re.finditer(r'''["'](colorImages|imageGalleryData)["']\s*:\s*''',script))[:12]:
        try:data=DataReader(script[match.end():]).value()
        except (ValueError,RecursionError,IndexError):continue
        # initial oznacza bieżący wariant. Nie łącz galerii innych kolorów.
        if match.group(1)=='colorImages':
            if not isinstance(data,dict):continue
            data=data.get('initial',[])
        if not isinstance(data,list):continue
        for record in data[:MAX_GALLERY]:
            if not isinstance(record,dict):continue
            if str(record.get('type','image')).lower() in ('video','360','spin'):continue
            values=[record.get(key) for key in ('hiRes','mainUrl','large','imageUrl')]
            main=record.get('main')
            if isinstance(main,dict):
                def area(item):
                    dims=item[1]
                    return dims[0]*dims[1] if isinstance(dims,list) and len(dims)>=2 and all(isinstance(x,(int,float)) for x in dims[:2]) else 0
                values.extend(url for url,_ in sorted(main.items(),key=area,reverse=True)[:1])
            chosen=next((v for v in values if isinstance(v,str) and v.startswith('https://')),None)
            if chosen:
                results.append((chosen,'Zdjęcie z galerii bieżącego wariantu'))
                for url in values+[record.get('thumb'),record.get('lowRes')]+(list(main) if isinstance(main,dict) else []):
                    if isinstance(url,str) and url.startswith('https://'):aliases[asset_key(url)]=asset_key(chosen)
    return results,aliases
