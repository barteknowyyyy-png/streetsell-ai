"""Bounded page layout and coalesced scrolling for low-powered laptops."""
import sys
import tkinter as tk
import customtkinter as ctk
from ui_performance import WheelBatch,can_scroll

PAGE_SIZE=40

class WholePage(ctk.CTkFrame):
    def __init__(self,parent,root,**kwargs):
        super().__init__(parent,fg_color='transparent',**kwargs)
        self.root=root;self.pending=None;self.closed=False
        self.tag='WholePageWheel'+str(id(self));self._canvas_size=None;self._content_size=None;self._region=None
        self.canvas=tk.Canvas(self,bg='#0b0e13',highlightthickness=0,yscrollincrement=12)
        self.scrollbar=ctk.CTkScrollbar(self,command=self.canvas.yview,width=16,button_color='#555d6b')
        self.scrollbar.pack(side='right',fill='y');self.canvas.pack(side='left',fill='both',expand=True)
        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        self.content=ctk.CTkFrame(self.canvas,fg_color='transparent')
        self.window=self.canvas.create_window(0,0,window=self.content,anchor='nw')
        self.batch=WheelBatch(self)
        self.canvas.bind('<Configure>',self._canvas_resized,add='+')
        self.content.bind('<Configure>',self._content_resized,add='+')
        for seq in ('<MouseWheel>','<Button-4>','<Button-5>'):root.bind_class(self.tag,seq,self.wheel)
        self._register_tree(self)
        # The toplevel tag receives child Map events; do not install a global app binding.
        self._map_binding=root.bind('<Map>',self.register,add='+')
        self.schedule()

    def _belongs(self,widget):
        try:
            if widget.winfo_toplevel()!=self.root:return False
            while widget is not None:
                if widget is self:return True
                widget=getattr(widget,'master',None)
        except (tk.TclError,AttributeError):pass
        return False

    def _register_tree(self,widget):
        try:
            if self._belongs(widget):
                tags=widget.bindtags()
                if self.tag not in tags:widget.bindtags((self.tag,*tags))
            for child in widget.winfo_children():self._register_tree(child)
        except (tk.TclError,AttributeError):pass

    def register(self,event):
        widget=event.widget
        try:
            if self._belongs(widget):
                tags=widget.bindtags()
                if self.tag not in tags:widget.bindtags((self.tag,*tags))
        except (tk.TclError,AttributeError):pass

    def _canvas_resized(self,event):
        size=(event.width,event.height)
        if size==self._canvas_size:return
        old=self._canvas_size;self._canvas_size=size
        try:
            if old is None or old[0]!=event.width:self.canvas.itemconfigure(self.window,width=max(1,event.width))
            self.schedule()
        except tk.TclError:pass

    def _content_resized(self,event):
        size=(event.width,event.height)
        if size!=self._content_size:self._content_size=size;self.schedule()

    def schedule(self,_event=None):
        if not self.closed and self.pending is None:self.pending=self.after(32,self.fit)

    def fit(self):
        if self.pending is not None:
            try:self.after_cancel(self.pending)
            except tk.TclError:pass
        self.pending=None
        if self.closed:return
        try:
            region=(0,0,max(1,self.canvas.winfo_width()),max(self.canvas.winfo_height(),self.content.winfo_reqheight()))
            if region!=self._region:self.canvas.configure(scrollregion=region);self._region=region
        except tk.TclError:pass

    def wheel(self,event):
        try:
            if not self._belongs(event.widget):return
            grab=self.root.grab_current()
            if grab is not None and grab.winfo_toplevel()!=self.root:return
            num=getattr(event,'num',None);delta=getattr(event,'delta',0)
            if num in (4,5):steps=-3 if num==4 else 3
            else:steps=-float(delta)*(1 if sys.platform=='darwin' else 3/120)
            if not steps:return
            widget=event.widget;target=self.canvas
            while widget is not None and widget is not self:
                explicit=getattr(widget,'_wheel_target',None)
                if explicit is not None:
                    if can_scroll(explicit,steps):target=explicit
                    break
                if widget.winfo_class() in ('Text','Listbox','Treeview'):
                    if can_scroll(widget,steps):target=widget
                    break
                # Leave CTkScrollableFrame dialogs to their own scroll handler.
                nested=getattr(widget,'_parent_canvas',None)
                if nested is not None and nested is not self.canvas:return
                widget=getattr(widget,'master',None)
            self.batch.add(target,steps)
            return 'break'
        except (tk.TclError,AttributeError,ValueError,TypeError):return

    def top(self):self.batch.clear();self.canvas.yview_moveto(0)

    def reveal(self,widget):
        self.batch.clear();self.root.update_idletasks();self.fit()
        target=max(0,widget.winfo_rooty()-self.content.winfo_rooty()-16)
        self.canvas.yview_moveto(target/max(1,self.content.winfo_height()))

    def destroy(self):
        if self.closed:return
        self.closed=True;self.batch.close()
        if self.pending is not None:
            try:self.after_cancel(self.pending)
            except tk.TclError:pass
            self.pending=None
        try:
            self.root.unbind('<Map>',self._map_binding)
            for seq in ('<MouseWheel>','<Button-4>','<Button-5>'):self.root.unbind_class(self.tag,seq)
        except tk.TclError:pass
        super().destroy()

class GrowText:
    """Expand only up to a bounded height; long descriptions scroll inside the field."""
    def __init__(self,widget,minimum=3,on_resize=None,maximum=16):
        self.widget=widget;self.minimum=minimum;self.maximum=max(minimum,maximum)
        self.pending=None;self.on_resize=on_resize;self.width=None
        widget.bind('<<Modified>>',self.schedule,add='+');widget.bind('<Configure>',self.configured,add='+')
        widget.bind('<Map>',self.schedule,add='+');widget.bind('<Destroy>',self.destroyed,add='+');self.schedule()
    def configured(self,event):
        if event.width!=self.width:self.width=event.width;self.schedule()
    def schedule(self,_event=None):
        if self.pending is None:self.pending=self.widget.after(120,self.fit)
    def fit(self):
        self.pending=None
        try:
            if not self.widget.winfo_ismapped():return
            # Measure only the first maximum display lines, not the entire description.
            end=self.widget.index(f'1.0 + {self.maximum} display lines')
            count=self.widget.count('1.0',end,'displaylines')
            lines=min(self.maximum,max(self.minimum,(count[0] if count else 0)+2))
            if int(self.widget.cget('height'))!=lines:
                self.widget.configure(height=lines)
                if self.on_resize:self.on_resize()
        except tk.TclError:pass
    def destroyed(self,event):
        if event.widget==self.widget and self.pending is not None:
            try:self.widget.after_cancel(self.pending)
            except tk.TclError:pass
            self.pending=None
