"""Wybór propozycji z internetu; trwały zapis następuje dopiero po wyborze użytkownika."""
import queue
import shutil
import tempfile
import threading
import tkinter as tk
import webbrowser
from tkinter import ttk,messagebox
from urllib.parse import urlsplit
from PIL import Image,ImageOps,ImageTk
import legacy
from image_search import ImageSearch,Candidate
from photo_localize import PhotoLocalizer
from public_web import WebError,Stopped,https_url
from photos import read_image

PANEL,FIELD,TEXT,MUTED='#171a22','#20242e','#f5f6fa','#969eaf'

class InternetPicker(tk.Toplevel):
    def __init__(self,app,product_id,engine=None,local_photo=None):
        super().__init__(app)
        self.app=app;self.product_id=product_id;self.product=dict(app.store.get(product_id))
        self.engine=engine if engine is not None else ImageSearch()
        self.work=tempfile.TemporaryDirectory(prefix='streetsell-propozycje-')
        self.events=queue.Queue();self.cancel=threading.Event();self.running=False;self.importing=False
        self.closed=False;self.timer=None;self.candidates=[];self.images=[];self.preview_image=None
        self.title(f'Zdjęcia z internetu • SS-{product_id:05d}')
        self.geometry(f'{min(1080,self.winfo_screenwidth()-60)}x{min(730,self.winfo_screenheight()-70)}')
        self.minsize(860,600);self.transient(app)
        self.polish=tk.BooleanVar(value=True);self.show_original=tk.BooleanVar(value=False)
        self.status=tk.StringVar(value='Wyszukaj propozycje albo wklej link do strony produktu.')
        self.url=tk.StringVar(value=str(self.product.get('product_link') or ''))
        self.build();self.protocol('WM_DELETE_WINDOW',self.close);self.grab_set()
        self.timer=self.after(100,self.poll)
        if local_photo is not None:self.after(100,lambda:self.start_local_photo(dict(local_photo)))
    def build(self):
        body=ttk.Frame(self,padding=18);body.pack(fill='both',expand=True)
        ttk.Label(body,text=f"SS-{self.product_id:05d} • {str(self.product['product_name'])[:100]}",
            font=('Segoe UI',12,'bold'),wraplength=930).pack(anchor='w')
        ttk.Label(body,text=f"ASIN: {self.product.get('asin') or '—'}   EAN: {self.product.get('ean') or '—'}",
            foreground=MUTED,padding=(0,5,0,10)).pack(anchor='w')
        row=ttk.Frame(body);row.pack(fill='x')
        self.search_button=ttk.Button(row,text='Szukaj w internecie (AI)',style='Accent.TButton',command=self.search_ai)
        self.search_button.pack(side='left')
        ttk.Label(row,text='Korzysta z Twojego klucza OpenAI API.',foreground=MUTED).pack(side='left',padx=12)
        ttk.Label(body,text='Lub wklej link HTTPS do strony produktu / zdjęcia:',padding=(0,12,0,4)).pack(anchor='w')
        urlrow=ttk.Frame(body);urlrow.pack(fill='x')
        self.url_entry=ttk.Entry(urlrow,textvariable=self.url);self.url_entry.pack(side='left',fill='x',expand=True)
        self.page_button=ttk.Button(urlrow,text='Pobierz ze strony',command=self.search_page)
        self.page_button.pack(side='right',padx=(8,0))
        self.url_entry.bind('<Return>',lambda e:self.search_page())
        self.polish_check=ttk.Checkbutton(body,text='Napisy na zdjęciach → polski (AI, domyślnie)',variable=self.polish)
        self.polish_check.pack(anchor='w',pady=(8,0))
        ttk.Label(body,text='Zdjęcia są wysyłane do OpenAI. Płatne API. Oryginały zachowane; sprawdź wynik przed dodaniem.',
                  foreground=MUTED,wraplength=940).pack(anchor='w')
        bottom=ttk.Frame(body);bottom.pack(side='bottom',fill='x',pady=(12,0))
        self.add_button=ttk.Button(bottom,text=f'Dodaj zaznaczone do SS-{self.product_id:05d}',
                                  style='Accent.TButton',state='disabled',command=self.add_selected)
        self.add_button.pack(side='left')
        self.select_all_button=ttk.Button(bottom,text='Zaznacz wszystkie',command=self.select_all,state='disabled')
        self.select_all_button.pack(side='left',padx=8)
        self.clear_button=ttk.Button(bottom,text='Odznacz',command=self.clear_selection,state='disabled')
        self.clear_button.pack(side='left')
        self.cancel_button=ttk.Button(bottom,text='Przerwij',state='disabled',command=self.request_cancel)
        self.cancel_button.pack(side='right')
        ttk.Button(bottom,text='Zamknij',command=self.close).pack(side='right',padx=8)
        ttk.Label(body,text='Propozycje są do sprawdzenia. Porównaj model, kolor, wymiary i zawartość zestawu. '
                  'Zaznacz kilka zdjęć z Ctrl lub Shift.',foreground=MUTED,wraplength=940,
                  padding=(0,10)).pack(fill='x')
        self.status_label=ttk.Label(body,textvariable=self.status,foreground=MUTED,wraplength=930)
        self.status_label.pack(fill='x',pady=(0,10))
        panels=tk.PanedWindow(body,orient='horizontal',sashwidth=10,bg=PANEL,bd=0)
        panels.pack(fill='both',expand=True)
        left,right=ttk.Frame(panels),ttk.Frame(panels)
        panels.add(left,minsize=380,stretch='always');panels.add(right,minsize=260,stretch='always')
        self.tree=ttk.Treeview(left,columns=('source','size'),show='tree headings',selectmode='extended',height=4)
        self.tree.heading('#0',text='Podgląd');self.tree.column('#0',width=110,minwidth=110,stretch=False)
        self.tree.heading('source',text='Źródło — do sprawdzenia');self.tree.column('source',width=240,minwidth=120)
        self.tree.heading('size',text='Wymiary');self.tree.column('size',width=100,minwidth=90,stretch=False)
        # Oddzielny styl nie zmienia wysokości wierszy magazynu produktów.
        style=ttk.Style(self);style.configure('Proposals.Treeview',rowheight=88)
        self.tree.configure(style='Proposals.Treeview')
        self.tree.pack(side='left',fill='both',expand=True)
        scroll=ttk.Scrollbar(left,command=self.tree.yview);scroll.pack(side='right',fill='y')
        self.tree.configure(yscrollcommand=scroll.set);self.tree.bind('<<TreeviewSelect>>',lambda e:self.show_selected())
        self.preview=tk.Canvas(right,bg=FIELD,width=290,height=210,highlightthickness=0)
        right.columnconfigure(0,weight=1);right.rowconfigure(0,weight=1)
        self.preview.configure(height=90)
        self.preview.grid(row=0,column=0,sticky='nsew')
        self.preview.bind('<Configure>',lambda e:self.show_selected())
        self.details=ttk.Label(right,text='Wybierz propozycję z listy.',foreground=MUTED,wraplength=300)
        self.details.grid(row=1,column=0,sticky='ew',pady=8)
        self.source_button=ttk.Button(right,text='Otwórz stronę źródłową',state='disabled',command=self.open_source)
        self.source_button.grid(row=2,column=0,sticky='w')
        self.original_check=ttk.Checkbutton(right,text='Pokaż oryginał do porównania',variable=self.show_original,command=self.show_selected)
        self.original_check.grid(row=3,column=0,sticky='w',pady=6)

    def controls(self):
        for button in (self.search_button,self.page_button):button.state(['disabled' if self.running else '!disabled'])
        self.polish_check.state(['disabled' if self.running else '!disabled'])
        self.url_entry.configure(state='disabled' if self.running else 'normal')
        self.cancel_button.state(['!disabled' if self.running and not self.cancel.is_set() else 'disabled'])
        self.add_button.state(['!disabled' if not self.running and self.tree.selection() else 'disabled'])
        self.add_button.configure(text=f'Dodaj zaznaczone ({len(self.tree.selection())}) do SS-{self.product_id:05d}')
        for button in (self.select_all_button,self.clear_button):button.state(['!disabled' if self.candidates and not self.running else 'disabled'])
    def select_all(self):
        if not self.running:
            self.tree.selection_set(self.tree.get_children());self.show_selected()
    def clear_selection(self):
        if not self.running:
            self.tree.selection_remove(*self.tree.selection());self.show_selected()
    def search_ai(self):
        key=legacy.get_api_key()
        self.start_search(key=key)
    def search_page(self):
        try:page=https_url(self.url.get())
        except WebError as exc:
            messagebox.showinfo('Link do produktu',str(exc),parent=self);return
        self.start_search(page_url=page)
    def start_search(self,**options):
        if self.running:return
        translate=self.polish.get();key=legacy.get_api_key()
        self.cancel.clear();self.running=True;self.controls()
        self.tree.delete(*self.tree.get_children());self.images=[];self.candidates=[]
        self.preview.delete('all');self.source_button.state(['disabled'])
        self.details.config(text='Szukam propozycji. Nie dodano jeszcze zdjęć do galerii.')
        def worker():
            try:
                result=self.engine.search(self.product,self.work.name,self.cancel,
                    progress=lambda text:self.events.put(('progress',text)),model=legacy.MODEL,**options)
                if translate:
                    candidates,warnings=result
                    candidates,translation_warnings=PhotoLocalizer(key,legacy.MODEL).process(candidates,self.work.name,self.cancel,
                        progress=lambda text:self.events.put(('progress',text)))
                    result=(candidates,translation_warnings+warnings)
                self.events.put(('found',result))
            except Stopped:self.events.put(('stopped',None))
            except WebError as exc:self.events.put(('error',str(exc)))
            except Exception:self.events.put(('error','Nie udało się przygotować propozycji. Spróbuj linku konkretnej strony produktu.'))
        threading.Thread(target=worker,daemon=True).start()
    def start_local_photo(self,row):
        if self.running:return
        self.cancel.clear();self.running=True;self.controls()
        key=legacy.get_api_key()
        def worker():
            try:
                source=self.app.gallery.resolve(row.get('original_relative_path') or row['relative_path'])
                local=__import__('pathlib').Path(self.work.name)/('galeria'+source.suffix)
                shutil.copy2(source,local)
                candidate=Candidate(local,row.get('source_page',''),row.get('source_image',''),
                    'Zdjęcie z galerii produktu','Oryginał pozostaje zachowany.',row['width'],row['height'],row['sha256'])
                result=PhotoLocalizer(key,legacy.MODEL).process([candidate],self.work.name,self.cancel,
                    progress=lambda text:self.events.put(('progress',text)))
                self.events.put(('found',result))
            except Stopped:self.events.put(('stopped',None))
            except Exception:self.events.put(('error','Nie udało się przygotować polskiej kopii zdjęcia. Sprawdź oryginał i ustawienia API.'))
        threading.Thread(target=worker,daemon=True).start()

    def request_cancel(self):
        self.cancel.set();self.status.set('Przerywam operację. Czekam na zakończenie bieżącego zapytania…')
        self.cancel_button.state(['disabled'])
    def fill(self,results,warnings):
        self.candidates=results;self.images=[]
        for index,c in enumerate(results):
            im=read_image(c.file,(96,74));photo=ImageTk.PhotoImage(im,master=self);self.images.append(photo)
            self.tree.insert('','end',iid=str(index),image=photo,values=((urlsplit(c.page_url).hostname or 'Galeria')+' • '+{'translated':'PL — sprawdź','checked':'Język sprawdzony','failed':'Napisy niesprawdzone'}.get(c.localization_status,'Oryginał'),f'{c.width} × {c.height}'))
        text=f'Znaleziono {len(results)} propozycji. Zaznacz zdjęcia, które odpowiadają Twojemu produktowi.'
        if len(results)==1:text+=' Ta strona udostępniła jedno dostępne zdjęcie. Możesz sprawdzić link innego sklepu.'
        if not results:text='Nie znaleziono dostępnych zdjęć. Wklej link innej strony produktu lub dodaj własne zdjęcia.'
        if warnings:text+=' '+warnings[0]
        self.status.set(text);self.controls()
    def current(self):
        selected=self.tree.selection()
        if not selected:return None
        focus=self.tree.focus()
        return self.candidates[int(focus if focus in selected else selected[-1])]
    def show_selected(self):
        current=self.current();self.preview.delete('all');self.preview_image=None
        if current:
            preview_file=current.original_file if self.show_original.get() and current.original_file else current.file
            im=read_image(preview_file,(max(80,self.preview.winfo_width()-16),max(80,self.preview.winfo_height()-16)))
            self.preview_image=ImageTk.PhotoImage(im,master=self)
            self.preview.create_image(self.preview.winfo_width()/2,self.preview.winfo_height()/2,image=self.preview_image)
            self.details.config(text=current.title+'\n'+current.note)
            self.source_button.state(['!disabled' if current.page_url else 'disabled'])
            self.original_check.state(['!disabled' if current.original_file else 'disabled'])
        else:
            self.source_button.state(['disabled']);self.original_check.state(['disabled'])
        self.controls()
    def open_source(self):
        c=self.current()
        if c and c.page_url:webbrowser.open(https_url(c.page_url))
    def add_selected(self):
        if self.running:return
        selected=[self.candidates[int(i)] for i in self.tree.selection()]
        if not selected:return
        if self.polish.get() and any(c.localization_status not in ('translated','checked') for c in selected):
            messagebox.showinfo('Napisy niesprawdzone','Nie wszystkie wybrane zdjęcia zostały sprawdzone. Spróbuj ponownie. '
                'Jeśli chcesz świadomie dodać oryginały, odznacz opcję napisów po polsku.',parent=self);return
        if self.app.photo_importing:
            messagebox.showinfo('Trwa import','Poczekaj na zakończenie bieżącego importu zdjęć.',parent=self);return
        self.cancel.clear();self.running=True;self.importing=True;self.app.photo_importing=True;self.controls()
        self.status.set('Dodaję wybrane zdjęcia do galerii produktu…')
        origins={str(c.file):{'source_page':c.page_url,'source_image':c.image_url,'original_file':c.original_file,'localization_language':c.localization_language} for c in selected}
        def worker():
            try:
                result=self.app.gallery.add(self.product_id,[c.file for c in selected],self.cancel,origins=origins)
                self.events.put(('added',result))
            except Exception as exc:self.events.put(('error',str(exc)))
        threading.Thread(target=worker,daemon=True).start()
    def poll(self):
        while True:
            try:event,data=self.events.get_nowait()
            except queue.Empty:break
            if event=='progress':
                if not self.cancel.is_set():self.status.set(data)
            else:
                self.running=False
                if self.importing:
                    self.importing=False;self.app.photo_importing=False
                if event=='found':self.fill(*data)
                elif event=='added':
                    self.app.photos_changed(self.product_id)
                    self.status.set(f'SS-{self.product_id:05d}: dodano {data[0]} zdjęć; pominięto {data[1]} identycznych. Zapisano.')
                    messagebox.showinfo('Zdjęcia dodane',self.status.get(),parent=self)
                elif event=='error':self.status.set(data);messagebox.showinfo('Zdjęcia z internetu',data,parent=self)
                elif event=='stopped':self.status.set('Wyszukiwanie przerwane. Galeria produktu nie została zmieniona.')
                self.controls()
        if not self.closed:self.timer=self.after(100,self.poll)
    def close(self):
        if self.running:self.request_cancel();return
        self.closed=True
        if self.timer:self.after_cancel(self.timer)
        self.work.cleanup();self.grab_release();self.destroy()
