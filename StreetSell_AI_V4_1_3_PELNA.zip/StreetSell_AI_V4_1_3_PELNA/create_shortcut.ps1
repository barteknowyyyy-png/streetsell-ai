$ErrorActionPreference = 'Stop'
$folder = $PSScriptRoot
$python = Join-Path $folder '.venv\Scripts\pythonw.exe'
if (-not (Test-Path -LiteralPath $python)) { throw 'Najpierw uruchom install.bat.' }
$shell = New-Object -ComObject WScript.Shell
$desktop = [Environment]::GetFolderPath('Desktop')
$shortcut = $shell.CreateShortcut((Join-Path $desktop 'StreetSell AI.lnk'))
$shortcut.TargetPath = $python
$shortcut.Arguments = '"' + (Join-Path $folder 'desktop_start.py') + '"'
$shortcut.WorkingDirectory = $folder
$shortcut.IconLocation = (Join-Path $folder 'streetsell.ico') + ',0'
$shortcut.Description = 'StreetSell AI — magazyn i Allegro'
$shortcut.Save()
Write-Host 'Utworzono ikone StreetSell AI na pulpicie.'
