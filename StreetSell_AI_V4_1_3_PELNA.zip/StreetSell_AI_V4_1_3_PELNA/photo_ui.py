"""Galeria w karcie produktu. Import w tle, a zmiany kolejności zapisywane od razu."""
import threading
import webbrowser
from urllib.parse import urlsplit
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from PIL import Image, ImageOps, ImageTk
from photos import read_image,PhotoError, ImportCancelled

PANEL, FIELD, TEXT, MUTED, RED = '#171a22','#20242e','#f5f6fa','#969eaf','#f04455'

class GalleryPane(ttk.Frame):
    def __init__(self, parent, app):
        super().__init__(parent)
        self.app=app
        self.gallery=app.gallery
        self.product_id=None
        self.selected_photo=None
        self.rows=[]
        self.images=[]
        self.preview_source=None
        self.preview_image=None
        self.resize_job=None
        self.cancel=threading.Event()
        self.header=ttk.Label(self,text='Zdjęcia produktu',font=('Segoe UI',11,'bold'))
        self.header.pack(anchor='w')
        toolbar=ttk.Frame(self)
        toolbar.pack(fill='x',pady=(10,6))
        self.add_button=ttk.Button(toolbar,text='+ Dodaj zdjęcia',style='Accent.TButton',command=self.add)
        self.add_button.pack(side='left')
        self.export_button=ttk.Button(toolbar,text='Eksportuj zdjęcia',command=self.export)
        self.export_button.pack(side='right')
        online = ttk.Frame(self)
        online.pack(fill='x', pady=(0,6))
        self.online_button = ttk.Button(online,text='Znajdź zdjęcia w internecie',command=self.open_internet)
        self.online_button.pack(side='left')
        self.source_button = ttk.Button(online,text='Źródło zdjęcia',command=self.open_source,state='disabled')
        self.source_button.pack(side='right')
        self.prepare_button = ttk.Button(self,text='Przygotuj zdjęcie na białym tle',command=self.open_editor)
        self.prepare_button.pack(fill='x',pady=(0,6))
        self.import_cancel=ttk.Button(self,text='Anuluj import',command=self.cancel.set)
        self.info=ttk.Label(self,text='JPG, PNG, WEBP • dwuklik miniatury: podgląd',foreground=MUTED)
        self.info.pack(anchor='w',pady=(3,6))
        self.preview_canvas=tk.Canvas(self,bg=FIELD,highlightthickness=0,width=260,height=190)
        self.preview_canvas.pack(fill='both',expand=True,pady=(3,8))
        self.preview_canvas.bind('<Configure>',self.schedule_preview)
        self.caption=ttk.Label(self,text='Dodaj pierwsze zdjęcie.',foreground=MUTED,wraplength=320)
        self.caption.pack(fill='x',pady=(0,8))
        strip=ttk.Frame(self)
        strip.pack(fill='x')
        self.strip=tk.Canvas(strip,bg=PANEL,highlightthickness=0,height=84,width=240)
        self.strip.pack(fill='x')
        scroll=ttk.Scrollbar(strip,orient='horizontal',command=self.strip.xview)
        scroll.pack(fill='x')
        self.strip.configure(xscrollcommand=scroll.set)
        actions=ttk.Frame(self)
        actions.pack(fill='x',pady=(10,4))
        
        for col in range(4): actions.columnconfigure(col,weight=1)
        self.buttons={}
        for i,(text,action) in enumerate([('Główne','main'),('Usuń','remove'),
                                         ('W lewo','left'),('W prawo','right')]):
            button=ttk.Button(actions,text=text,command=lambda a=action:self.mutate(a))
            button.grid(row=0,column=i,sticky='ew',padx=(0 if i==0 else 5,0),pady=3)
            self.buttons[action]=button
        self.preview_canvas.pack_forget()
        self.caption.pack_forget()
        self.caption.pack(fill='x',pady=(3,8))
        self.preview_canvas.pack(fill='both',expand=True,pady=(3,8))
        self.preview_canvas.bind('<Double-Button-1>',self.full_preview)
        ttk.Label(self,text='Pierwsze zdjęcie jest główne. Zdjęcia i kolejność zapisują się od razu.',
                  foreground=MUTED,wraplength=330,padding=(0,6,0,0)).pack(anchor='w')

    def destroy(self):
        if self.resize_job:
            try:
                self.after_cancel(self.resize_job)
            except tk.TclError:
                pass
            self.resize_job=None
        if self.preview_source is not None:
            self.preview_source.close()
        super().destroy()

    def set_product(self, product_id):
        if product_id != self.product_id:
            self.selected_photo=None
            self.strip.xview_moveto(0)
        self.product_id=product_id
        self.reload()

    def reload(self):
        self.rows=self.gallery.photos(self.product_id) if self.product_id else []
        if not any(r['id']==self.selected_photo for r in self.rows):
            self.selected_photo=self.rows[0]['id'] if self.rows else None
        self.header.config(text=f'Galeria • {len(self.rows)} zdjęć')
        self.draw_strip()
        self.load_preview()
        self.button_states()

    def draw_strip(self):
        self.strip.delete('all')
        self.images=[]
        for i,row in enumerate(self.rows):
            x=i*94
            tag=f"photo-{row['id']}"
            self.strip.create_rectangle(x+2,2,x+90,81,fill=FIELD,
                outline=RED if row['id']==self.selected_photo else FIELD,width=2,tags=(tag,))
            try:
                im=self.gallery.thumbnail(row)
                im.thumbnail((72,50),Image.Resampling.LANCZOS)
                image=ImageTk.PhotoImage(im,master=self)
                self.images.append(image)
                self.strip.create_image(x+46,29,image=image,tags=(tag,))
            except (PhotoError,OSError,ValueError):
                self.strip.create_text(x+46,29,text='Brak pliku',fill=MUTED,tags=(tag,))
            self.strip.create_text(x+46,68,text='GŁÓWNE' if i==0 else str(i+1),fill=RED if i==0 else MUTED,
                                   font=('Segoe UI',8),tags=(tag,))
            self.strip.tag_bind(tag,'<Button-1>',lambda e,pid=row['id']:self.select_photo(pid))
            self.strip.tag_bind(tag,'<Double-Button-1>',lambda e,pid=row['id']:self.open_photo(pid))
        self.strip.configure(scrollregion=(0,0,max(1,len(self.rows)*94),84))

    def select_photo(self, photo_id):
        self.selected_photo=photo_id
        self.draw_strip();self.load_preview();self.button_states()

    def load_preview(self):
        self._preview_render_key=None
        if self.preview_source is not None:
            self.preview_source.close()
        self.preview_source=None
        row=next((r for r in self.rows if r['id']==self.selected_photo),None)
        if row:
            try:
                self.preview_source=self.gallery.preview(row)
                index=next(i for i,r in enumerate(self.rows) if r['id']==row['id'])
                self.caption.config(text=f"{index+1}/{len(self.rows)} • {row['original_name']} • {row['width']} × {row['height']} px"+
                                    (' • Główne' if index==0 else ''))
            except (PhotoError,OSError) as exc:
                self.caption.config(text='Nie można odczytać tego zdjęcia. Możesz usunąć wpis i dodać plik ponownie.')
        else:
            self.caption.config(text='Dodaj pierwsze zdjęcie z komputera.')
        self.draw_preview()

    def schedule_preview(self, _event=None):
        if _event is not None:
            geometry=(_event.width,_event.height)
            if geometry==getattr(self,'_preview_geometry',None):return
            self._preview_geometry=geometry
        if self.resize_job:self.after_cancel(self.resize_job)
        self.resize_job=self.after(80,self.draw_preview)

    def draw_preview(self):
        if self.resize_job:
            try:
                self.after_cancel(self.resize_job)
            except tk.TclError:
                pass
        self.resize_job=None
        canvas=self.preview_canvas
        width,height=max(100,canvas.winfo_width()),max(100,canvas.winfo_height())
        key=(id(self.preview_source),width,height)
        if key==getattr(self,'_preview_render_key',None):return
        self._preview_render_key=key
        canvas.delete('all')
        if self.preview_source is None:
            self.preview_image=None
            canvas.create_text(width/2,height/2,text='Brak zdjęcia' if not self.rows else 'Plik niedostępny',fill=MUTED,font=('Segoe UI',12))
            return
        image=ImageOps.contain(self.preview_source,(max(1,width-16),max(1,height-16)),Image.Resampling.LANCZOS)
        try:self.preview_image=ImageTk.PhotoImage(image,master=self)
        finally:image.close()
        canvas.create_image(width/2,height/2,image=self.preview_image)

    def open_photo(self, photo_id):
        self.select_photo(photo_id)
        self.full_preview()

    def full_preview(self, _event=None):
        if self.preview_source is None:
            return
        image = self.preview_source.copy()
        window = tk.Toplevel(self)
        window.title('Podgląd zdjęcia produktu')
        window.geometry('800x640')
        window.transient(self.app)
        canvas = tk.Canvas(window,bg=FIELD,highlightthickness=0)
        canvas.pack(fill='both',expand=True)
        def draw(_event=None):
            fitted=ImageOps.contain(image,(max(1,canvas.winfo_width()-20),max(1,canvas.winfo_height()-20)),Image.Resampling.LANCZOS)
            canvas.photo=ImageTk.PhotoImage(fitted,master=window)
            canvas.delete('all')
            canvas.create_image(canvas.winfo_width()/2,canvas.winfo_height()/2,image=canvas.photo)
        canvas.bind('<Configure>',draw)
        window.bind('<Escape>',lambda e:window.destroy())
        window.bind('<Destroy>',lambda e:image.close() if e.widget==window else None)

    def button_states(self):
        busy=self.app.photo_importing
        self.add_button.state(['disabled' if busy or not self.product_id else '!disabled'])
        self.export_button.state(['disabled' if busy or not self.rows else '!disabled'])
        self.online_button.state(['disabled' if busy or not self.product_id else '!disabled'])
        row=next((r for r in self.rows if r['id']==self.selected_photo),None)
        self.source_button.state(['!disabled' if row is not None and row['source_page'] else 'disabled'])
        self.prepare_button.state(['!disabled' if not busy and row is not None else 'disabled'])
        if hasattr(self,'translate_button'):
            self.translate_button.state(['!disabled' if not busy and row is not None else 'disabled'])
            self.original_button.state(['!disabled' if row is not None and row['original_relative_path'] else 'disabled'])
        index=next((i for i,r in enumerate(self.rows) if r['id']==self.selected_photo),None)
        for action,button in self.buttons.items():
            enabled=not busy and index is not None
            if action in ('main','left'):enabled=enabled and index!=0
            if action=='right':enabled=enabled and index!=len(self.rows)-1
            button.state(['!disabled' if enabled else 'disabled'])

    def open_localize(self):
        if self.app.photo_importing or self.app.busy_id==self.product_id:return
        row=next((r for r in self.rows if r['id']==self.selected_photo),None)
        if row is None:return
        if not self.app.confirm_pending():return
        from image_picker import InternetPicker
        self.app.internet_dialog=InternetPicker(self.app,self.product_id,local_photo=row)

    def open_original(self):
        row=next((r for r in self.rows if r['id']==self.selected_photo),None)
        if row is None or not row['original_relative_path']:return
        try:image=read_image(self.gallery.resolve(row['original_relative_path']),(1600,1600))
        except (OSError,PhotoError) as exc:
            messagebox.showinfo('Oryginał zdjęcia',str(exc),parent=self);return
        window=tk.Toplevel(self);window.title('Oryginał przed tłumaczeniem — do porównania');window.geometry('850x700')
        canvas=tk.Canvas(window,bg=FIELD,highlightthickness=0);canvas.pack(fill='both',expand=True)
        def draw(_event=None):
            fitted=ImageOps.contain(image,(max(1,canvas.winfo_width()-20),max(1,canvas.winfo_height()-20)),Image.Resampling.LANCZOS)
            canvas.photo=ImageTk.PhotoImage(fitted,master=window);canvas.delete('all')
            canvas.create_image(canvas.winfo_width()/2,canvas.winfo_height()/2,image=canvas.photo)
        canvas.bind('<Configure>',draw)
        window.bind('<Destroy>',lambda e:image.close() if e.widget==window else None)

    def open_editor(self):
        if self.app.photo_importing or not self.product_id:return
        if self.app.busy_id == self.product_id:
            messagebox.showinfo('Trwa analiza','Poczekaj na zakończenie analizy produktu.',parent=self);return
        existing=getattr(self.app,'photo_editor',None)
        if existing is not None and existing.winfo_exists():
            existing.lift();return
        row=next((r for r in self.rows if r['id']==self.selected_photo),None)
        if row is None:return
        from photo_editor import PhotoEditor
        try:self.app.photo_editor=PhotoEditor(self.app,self.product_id,row)
        except (PhotoError,OSError) as exc:messagebox.showerror('Przygotowanie zdjęcia',str(exc),parent=self)

    def open_internet(self):
        if self.app.photo_importing or not self.product_id:
            return
        if self.app.busy_id == self.product_id:
            messagebox.showinfo('Trwa analiza','Poczekaj na zakończenie analizy tego produktu.',parent=self)
            return
        if not self.app.confirm_pending():return
        from image_picker import InternetPicker
        self.app.internet_dialog = InternetPicker(self.app,self.product_id)

    def open_source(self):
        row=next((r for r in self.rows if r['id']==self.selected_photo),None)
        if row is not None and row['source_page']:
            from public_web import https_url,WebError
            try:webbrowser.open(https_url(row['source_page']))
            except WebError:messagebox.showinfo('Źródło zdjęcia','Nieprawidłowy link źródłowy.',parent=self)

    def add(self):
        if self.app.photo_importing or not self.product_id:return
        if self.app.busy_id==self.product_id:
            messagebox.showinfo('Trwa analiza','Poczekaj na zakończenie analizy tego produktu.',parent=self)
            return
        paths=filedialog.askopenfilenames(title=f'Dodaj zdjęcia do SS-{self.product_id:05d}',
            filetypes=[('Zdjęcia JPG / PNG / WEBP','*.jpg *.jpeg *.png *.webp'),('Wszystkie pliki','*.*')])
        if paths:self.start_import(paths)

    def start_import(self, paths):
        if not self.product_id or self.app.photo_importing:return
        product_id=self.product_id
        self.app.photo_importing=True
        self.cancel.clear()
        self.import_cancel.pack(anchor='w',after=self.info,pady=(0,6))
        self.button_states()
        self.app.statusbar.config(text=f'Importuję zdjęcia do SS-{product_id:05d}…')
        def worker():
            try:
                result=self.gallery.add(product_id,paths,self.cancel,
                    progress=lambda i,n:self.app.events.put((self.progress,(product_id,i,n))))
                self.app.events.put((self.import_done,(product_id,result,None)))
            except Exception as exc:
                self.app.events.put((self.import_done,(product_id,None,str(exc))))
        threading.Thread(target=worker,daemon=True).start()

    def progress(self, product_id, index, count):
        self.app.statusbar.config(text=f'SS-{product_id:05d}: sprawdzono zdjęcia {index}/{count}…')

    def import_done(self, product_id, result, error):
        self.app.photo_importing=False
        self.import_cancel.pack_forget()
        self.app.photos_changed(product_id)
        self.button_states()
        if error:
            self.app.statusbar.config(text='Import zdjęć nie zmienił galerii.')
            messagebox.showerror('Import zdjęć',error,parent=self)
        else:
            added,skipped=result
            self.app.statusbar.config(text=f'SS-{product_id:05d}: dodano {added} zdjęć; pominięto {skipped} identycznych. Zapisano.')

    def mutate(self, action):
        if self.app.photo_importing or self.selected_photo is None:return
        if self.app.busy_id==self.product_id:
            messagebox.showinfo('Trwa analiza','Poczekaj na zakończenie analizy produktu.',parent=self);return
        if action=='remove' and not messagebox.askyesno('Usuń zdjęcie z galerii',
                'Usunąć to zdjęcie z galerii produktu? Oryginalny plik na Twoim komputerze pozostanie bez zmian.',parent=self):return
        try:
            if action=='remove':self.gallery.remove(self.product_id,self.selected_photo)
            else:self.gallery.reorder(self.product_id,self.selected_photo,action)
            self.app.photos_changed(self.product_id)
            self.app.statusbar.config(text='Zapisano galerię. Po zmianie zdjęć ponownie sprawdź zatwierdzenie oferty.')
        except (PhotoError,OSError) as exc:
            messagebox.showerror('Galeria zdjęć',str(exc),parent=self)

    def export(self):
        if self.app.photo_importing or not self.product_id:return
        target=filedialog.askdirectory(title='Wybierz miejsce na eksport zdjęć')
        if target:
            try:
                path=self.gallery.export(self.product_id,target)
                messagebox.showinfo('Zdjęcia wyeksportowane',
                    'Zapisano zdjęcia w kolejności galerii (01 jest główne):\n'+str(path),parent=self)
            except Exception as exc:
                messagebox.showerror('Eksport zdjęć',str(exc),parent=self)
