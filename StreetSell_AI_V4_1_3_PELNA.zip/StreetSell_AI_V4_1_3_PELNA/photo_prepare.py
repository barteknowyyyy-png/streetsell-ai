"""Przygotowanie kopii zdjęcia. Segmentacja lokalna w osobnym środowisku."""
import os
import json
import shutil
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path
from PIL import Image, ImageOps
from photos import read_image, PhotoError, ImportCancelled

class SetupNeeded(PhotoError):
    pass

def compose_white(image, margin=8, size=1600):
    """Przycina tylko przezroczystość; pełne zdjęcie nigdy nie traci krawędzi."""
    margin = int(margin)
    if not 3 <= margin <= 25:
        raise PhotoError('Margines musi mieć od 3 do 25 procent.')
    if not 400 <= size <= 2400:
        raise PhotoError('Nieprawidłowy rozmiar obrazu.')
    rgba = image.convert('RGBA')
    alpha = rgba.getchannel('A')
    bounds = alpha.point(lambda p: 255 if p > 8 else 0).getbbox()
    if bounds is None:
        raise PhotoError('Po usunięciu tła nie pozostał produkt. Zachowaj tło lub wybierz inne zdjęcie.')
    # Mały zapas wokół maski zachowuje miękkie krawędzie.
    left, top, right, bottom = bounds
    bounds = (max(0,left-2),max(0,top-2),min(rgba.width,right+2),min(rgba.height,bottom+2))
    subject = rgba.crop(bounds)
    available = round(size * (1 - 2 * margin / 100))
    fitted = ImageOps.contain(subject, (available,available), Image.Resampling.LANCZOS)
    canvas = Image.new('RGB', (size,size), 'white')
    canvas.paste(fitted, ((size-fitted.width)//2,(size-fitted.height)//2), fitted)
    return canvas

WINDOWS = os.name == 'nt'
PYTHON_DOWNLOAD_URL = 'https://www.python.org/downloads/release/python-31317/'

class CompatiblePythonMissing(PhotoError):
    pass

def probe_python(command):
    """Sprawdź rzeczywisty interpreter, także gdy launcher wybierze inną architekturę."""
    code = ('import json,sys,struct; print(json.dumps({'
            '"path":sys.executable,"version":list(sys.version_info[:2]),'
            '"bits":struct.calcsize("P")*8}))')
    try:
        result = subprocess.run([*command,'-c',code],capture_output=True,text=True,
            timeout=12,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        if result.returncode:return None
        info = json.loads(result.stdout.strip())
        version=tuple(info['version'])
        if (3,10) <= version < (3,14) and info['bits']==64 and info['path']:
            return str(Path(info['path']).resolve())
    except (OSError,subprocess.TimeoutExpired,ValueError,KeyError,TypeError):
        pass
    return None

def find_python(existing=None, cancel=None):
    candidates=[]
    if existing is not None and Path(existing).is_file():candidates.append([str(existing)])
    candidates.append([sys.executable])
    if WINDOWS:
        launcher=shutil.which('py')
        if launcher:
            candidates.extend([[launcher,f'-3.{minor}'] for minor in (13,12,11,10)])
        # Instalacja domyślna działa również bez PATH i bez launchera py.
        for minor in (13,12,11,10):
            for root in (Path(os.environ.get('LOCALAPPDATA',''))/'Programs'/'Python',
                         Path(os.environ.get('ProgramFiles','C:/Program Files'))):
                exe=root/f'Python3{minor}'/'python.exe'
                if exe.is_file():candidates.append([str(exe)])
        try:
            import winreg
            for hive in (winreg.HKEY_CURRENT_USER,winreg.HKEY_LOCAL_MACHINE):
                for view in (winreg.KEY_WOW64_64KEY,winreg.KEY_WOW64_32KEY):
                    for minor in (13,12,11,10):
                        try:
                            with winreg.OpenKey(hive,fr'SOFTWARE\Python\PythonCore\3.{minor}\InstallPath',0,winreg.KEY_READ|view) as key:
                                folder=winreg.QueryValueEx(key,'')[0]
                                exe=Path(folder)/'python.exe'
                                if exe.is_file():candidates.append([str(exe)])
                        except OSError:pass
        except ImportError:pass
    seen=set()
    for command in candidates:
        if cancel is not None and cancel.is_set():raise ImportCancelled('Anulowano instalację modułu tła.')
        marker=tuple(command)
        if marker in seen:continue
        seen.add(marker)
        found=probe_python(command)
        if found:return found
    raise CompatiblePythonMissing(
        'Nie znaleziono Python 3.10–3.13 (64-bit) dla modułu tła. '
        'Kliknij „Pobierz Python 3.13”, zainstaluj Windows installer (64-bit), '
        'a potem ponownie kliknij „Zainstaluj moduł tła”. '
        'Obecny Python i środowisko głównej aplikacji pozostają bez zmian.')

class LocalRemover:
    def __init__(self, base):
        self.base = Path(base).resolve()
        self.envdir = self.base / '.venv_photos'
        self.python = self.envdir / ('Scripts/python.exe' if os.name=='nt' else 'bin/python')

    def ready(self):
        return self.python.is_file() and (self.envdir / 'streetsell-ready-2.0.67').is_file()

    def run(self, command, cancel, timeout=900):
        env = dict(os.environ, OMP_NUM_THREADS='2', U2NET_HOME=str(self.base / 'photo_models'))
        started = time.monotonic()
        # Plik zamiast PIPE: pobieranie bibliotek nie może zablokować procesu.
        with tempfile.TemporaryFile() as log:
            process = subprocess.Popen(command, stdout=log, stderr=log, env=env,
                creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0), cwd=self.base)
            try:
                while process.poll() is None:
                    if cancel.is_set():
                        raise ImportCancelled('Anulowano. Galeria pozostała bez zmian.')
                    if time.monotonic()-started > timeout:
                        raise PhotoError('Operacja trwała zbyt długo. Sprawdź internet i spróbuj ponownie.')
                    cancel.wait(.15)
                if cancel.is_set():
                    raise ImportCancelled('Anulowano. Galeria pozostała bez zmian.')
                if process.returncode:
                    raise PhotoError('Moduł usuwania tła nie zakończył operacji. Sprawdź połączenie, wolne miejsce i instalację modułu. Na Windows może być potrzebny Microsoft Visual C++ Redistributable x64.')
            finally:
                if process.poll() is None:
                    process.terminate()
                    try: process.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        process.kill(); process.wait()

    def install(self, cancel, progress=lambda text:None):
        progress('Szukam zgodnego Pythona dla modułu tła…')
        python = find_python(self.python, cancel)
        # Gdy poprzednia instalacja miała złą wersję, odłóż tylko opcjonalne
        # środowisko modułu. Główna .venv, baza i zdjęcia pozostają nietknięte.
        existing_ok = self.python.is_file() and probe_python([str(self.python)])
        if self.envdir.exists() and not existing_ok:
            from uuid import uuid4
            self.envdir.rename(self.base / ('.venv_photos_poprzednia_' + uuid4().hex[:8]))
        (self.envdir / 'streetsell-ready-2.0.67').unlink(missing_ok=True)
        progress('Tworzę osobne środowisko modułu zdjęć…')
        if not existing_ok:
            self.run([python,'-m','venv',str(self.envdir)],cancel,120)
        progress('Pobieram moduł usuwania tła. Pierwsza instalacja może potrwać kilka minut…')
        self.run([str(self.python),'-m','pip','install','--disable-pip-version-check','rembg[cpu]==2.0.67'],cancel)
        self.run([str(self.python),'-c','from rembg import remove, new_session'],cancel,120)
        (self.envdir / 'streetsell-ready-2.0.67').write_text('ok',encoding='ascii')

    def remove(self, source, destination, cancel, progress=lambda text:None):
        if not self.ready():
            raise SetupNeeded('Najpierw kliknij „Zainstaluj moduł tła”. Kadrowanie bez usuwania tła działa od razu.')
        progress('Usuwam tło lokalnie. Przy pierwszym użyciu pobieram model (około 176 MB)…')
        self.run([str(self.python),str(Path(__file__).resolve()),'--remove',str(source),str(destination)],cancel)


def remove_cli(source, destination):
    from rembg import new_session, remove
    image = read_image(source, (2048,2048))
    # Model segmentuje maskę; nie generuje nowego wyglądu produktu.
    session = new_session('u2net', providers=['CPUExecutionProvider'])
    cutout = remove(image, session=session)
    cutout.save(destination,format='PNG')

if __name__=='__main__':
    if len(sys.argv)==4 and sys.argv[1]=='--remove':
        remove_cli(sys.argv[2],sys.argv[3])
    else:
        raise SystemExit('Moduł uruchamiany przez StreetSell AI.')
