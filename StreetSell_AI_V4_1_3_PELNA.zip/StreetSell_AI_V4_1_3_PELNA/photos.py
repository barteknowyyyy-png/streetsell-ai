"""Lokalna galeria produktów: pliki źródłowe, miniatury, kolejność i kopie ZIP."""
import hashlib
import os
import shutil
import sqlite3
import tempfile
import warnings
import zipfile
from datetime import datetime
from pathlib import Path, PurePosixPath
from uuid import uuid4
from PIL import Image, ImageOps, UnidentifiedImageError

MAX_BYTES = 40 * 1024 * 1024
MAX_PIXELS = 50_000_000
FORMATS = {'JPEG':'.jpg','PNG':'.png','WEBP':'.webp'}

class PhotoError(ValueError):
    pass

class ImportCancelled(PhotoError):
    pass


def read_image(path, size=None):
    """Podgląd respektuje EXIF. Plik źródłowy pozostaje bez zmian."""
    try:
        with warnings.catch_warnings():
            warnings.simplefilter('error', Image.DecompressionBombWarning)
            with Image.open(path) as im:
                if im.format not in FORMATS:
                    raise PhotoError('Obsługiwane są pliki JPG, PNG i WEBP. Zapisz zdjęcie w jednym z tych formatów.')
                if im.width * im.height > MAX_PIXELS:
                    raise PhotoError('Zdjęcie jest zbyt duże. Maksymalnie 50 megapikseli.')
                if getattr(im, 'n_frames', 1) != 1:
                    raise PhotoError('Wybierz pojedyncze zdjęcie zamiast animacji.')
                image = ImageOps.exif_transpose(im)
                if size:
                    image.thumbnail(size, Image.Resampling.LANCZOS)
                return image.convert('RGBA')
    except PhotoError:
        raise
    except (OSError, ValueError, UnidentifiedImageError, Image.DecompressionBombWarning, Image.DecompressionBombError):
        raise PhotoError('Nie można odczytać zdjęcia. Plik jest uszkodzony albo ma nieobsługiwany format.') from None

class Gallery:
    def __init__(self, store):
        self.store = store
        self.base = store.path.resolve().parent
        self.media = self.base / 'media'

    def resolve(self, relative):
        if not isinstance(relative, str):
            raise PhotoError('Nieprawidłowa ścieżka zdjęcia.')
        p = PurePosixPath(relative)
        if p.is_absolute() or not p.parts or p.parts[0] != 'media' or any(x in ('.','..') for x in p.parts) or '\\' in relative or ':' in relative:
            raise PhotoError('Nieprawidłowa ścieżka zdjęcia.')
        candidate = (self.base / Path(*p.parts)).resolve()
        if not candidate.is_relative_to(self.media.resolve()):
            raise PhotoError('Zdjęcie znajduje się poza folderem aplikacji.')
        return candidate

    def photos(self, product_id):
        with self.store.connect() as con:
            return con.execute('SELECT * FROM product_photos WHERE product_id=? ORDER BY position,id', (product_id,)).fetchall()

    def main_photos(self):
        with self.store.connect() as con:
            rows = con.execute('SELECT * FROM product_photos ORDER BY product_id,position,id').fetchall()
        result = {}
        for row in rows:
            result.setdefault(row['product_id'],row)
        return result

    def _touch(self, con, product_id):
        con.execute("UPDATE products SET status=CASE WHEN status='Zatwierdzony' THEN 'Szkic' ELSE status END, updated_at=? WHERE id=?",
                    (datetime.now().isoformat(timespec='seconds'), product_id))

    def add(self, product_id, files, cancel=None, progress=None, origins=None):
        files=list(files)
        if not files:
            return (0,0)
        if len(files) > 40:
            raise PhotoError('Dodawaj maksymalnie 40 zdjęć jednocześnie.')
        self.media.mkdir(parents=True,exist_ok=True)
        added_files=[]
        def cancelled():
            if cancel is not None and cancel.is_set():
                raise ImportCancelled('Import zdjęć anulowano. Nie dodano żadnych zdjęć z tej partii.')
        with tempfile.TemporaryDirectory(prefix='.import-',dir=self.media) as temp:
            prepared=[]
            for index, source in enumerate(files,1):
                cancelled()
                source=Path(source)
                if not source.is_file():
                    raise PhotoError(f'Nie znaleziono pliku: {source.name}')
                if source.stat().st_size > MAX_BYTES:
                    raise PhotoError(f'{source.name}: maksymalny rozmiar zdjęcia to 40 MB.')
                staged=Path(temp)/f'{index}.source'
                digest=hashlib.sha256()
                count=0
                with source.open('rb') as src,staged.open('wb') as target:
                    while chunk:=src.read(1024*1024):
                        cancelled()
                        count+=len(chunk)
                        if count>MAX_BYTES:
                            raise PhotoError(f'{source.name}: maksymalny rozmiar zdjęcia to 40 MB.')
                        digest.update(chunk);target.write(chunk)
                try:
                    im=read_image(staged, (1280,1280))
                    with Image.open(staged) as header:
                        extension=FORMATS[header.format]
                        width,height=header.size
                    im.thumbnail((80,80),Image.Resampling.LANCZOS)
                    thumbnail=Path(temp)/f'{index}.thumb.png'
                    im.save(thumbnail,format='PNG')
                    im.close()
                except PhotoError as exc:
                    raise PhotoError(f'{source.name}: {exc}') from None
                origin = (origins or {}).get(str(source), {})
                archived=None;archive_ext=''
                original_file=origin.get('original_file')
                if original_file:
                    original_file=Path(original_file)
                    if original_file.stat().st_size>MAX_BYTES:raise PhotoError('Oryginał zdjęcia przekracza 40 MB.')
                    archived=Path(temp)/f'{index}.original'
                    with original_file.open('rb') as src,archived.open('wb') as dst:
                        size=0
                        while chunk:=src.read(1024*1024):
                            cancelled();size+=len(chunk)
                            if size>MAX_BYTES:raise PhotoError('Oryginał zdjęcia przekracza 40 MB.')
                            dst.write(chunk)
                    checked=read_image(archived,(80,80));checked.close()
                    with Image.open(archived) as header:archive_ext=FORMATS[header.format]
                prepared.append((staged,thumbnail,extension,digest.hexdigest(),source.name,width,height,
                                 str(origin.get('source_page', ''))[:8192], str(origin.get('source_image', ''))[:8192], archived,archive_ext,
                                 'pl' if origin.get('localization_language')=='pl' else ''))
                if progress:
                    progress(index,len(files))
            cancelled()
            try:
                with self.store.connect() as con:
                    con.execute('BEGIN IMMEDIATE')
                    if not con.execute('SELECT 1 FROM products WHERE id=?',(product_id,)).fetchone():
                        raise PhotoError('Nie znaleziono produktu. Wybierz go ponownie.')
                    folder=self.media/f'SS-{product_id:05d}'
                    folder.mkdir(parents=True,exist_ok=True)
                    pos=con.execute('SELECT COALESCE(MAX(position),-1)+1 FROM product_photos WHERE product_id=?',(product_id,)).fetchone()[0]
                    added=skipped=0
                    for original,thumb,ext,digest,name,width,height,source_page,source_image,archived,archive_ext,language in prepared:
                        cancelled()
                        if con.execute('SELECT 1 FROM product_photos WHERE product_id=? AND sha256=?',(product_id,digest)).fetchone():
                            skipped+=1;continue
                        uid=uuid4().hex
                        dest,thumb_dest=folder/(uid+ext),folder/(uid+'.thumb.png')
                        os.replace(original,dest);added_files.append(dest)
                        os.replace(thumb,thumb_dest);added_files.append(thumb_dest)
                        archive_relative=''
                        if archived is not None:
                            archive_dest=folder/(uid+'.original'+archive_ext)
                            os.replace(archived,archive_dest);added_files.append(archive_dest)
                            archive_relative=archive_dest.relative_to(self.base).as_posix()
                        con.execute('''INSERT INTO product_photos (product_id,relative_path,thumbnail_path,original_name,sha256,position,width,height,source_page,source_image,original_relative_path,localization_language)
                                       VALUES (?,?,?,?,?,?,?,?,?,?,?,?)''',
                            (product_id,dest.relative_to(self.base).as_posix(),thumb_dest.relative_to(self.base).as_posix(),name,digest,pos,width,height,source_page,source_image,archive_relative,language))
                        added+=1;pos+=1
                    cancelled()
                    if added:self._touch(con,product_id)
                return added,skipped
            except Exception:
                for path in added_files:
                    path.unlink(missing_ok=True)
                raise

    def thumbnail(self, photo):
        try:
            path=self.resolve(photo['thumbnail_path'])
            with Image.open(path) as image:
                if image.width>100 or image.height>100:
                    raise PhotoError('Nieprawidłowa miniatura.')
                return image.convert('RGBA')
        except (OSError,ValueError):
            return read_image(self.resolve(photo['relative_path']),(80,80))

    def preview(self, photo):
        return read_image(self.resolve(photo['relative_path']),(1280,1280))

    def reorder(self, product_id, photo_id, action):
        with self.store.connect() as con:
            con.execute('BEGIN IMMEDIATE')
            ids=[r[0] for r in con.execute('SELECT id FROM product_photos WHERE product_id=? ORDER BY position,id',(product_id,))]
            if photo_id not in ids:
                raise PhotoError('Nie znaleziono zdjęcia w tym produkcie.')
            index=ids.index(photo_id)
            if action=='main':target=0
            elif action=='left':target=max(0,index-1)
            elif action=='right':target=min(len(ids)-1,index+1)
            else:raise PhotoError('Nieprawidłowa operacja.')
            if target==index:return False
            ids.insert(target,ids.pop(index))
            con.executemany('UPDATE product_photos SET position=? WHERE id=? AND product_id=?',
                            [(i,pid,product_id) for i,pid in enumerate(ids)])
            self._touch(con,product_id)
        return True

    def remove(self, product_id, photo_id):
        with self.store.connect() as con:
            con.execute('BEGIN IMMEDIATE')
            result=con.execute('DELETE FROM product_photos WHERE product_id=? AND id=?',(product_id,photo_id))
            if not result.rowcount:
                raise PhotoError('Nie znaleziono zdjęcia w tym produkcie.')
            ids=[r[0] for r in con.execute('SELECT id FROM product_photos WHERE product_id=? ORDER BY position,id',(product_id,))]
            con.executemany('UPDATE product_photos SET position=? WHERE id=?',[(i,pid) for i,pid in enumerate(ids)])
            self._touch(con,product_id)
        # Pliki robocze zostają w media, aby wcześniejsze kopie bazy mogły je odtworzyć.
        # Nie usuwamy źródłowych zdjęć użytkownika.

    def export(self, product_id, destination):
        rows=self.photos(product_id)
        if not rows:raise PhotoError('Produkt nie ma zdjęć.')
        base=Path(destination)
        base.mkdir(parents=True,exist_ok=True)
        folder=Path(tempfile.mkdtemp(prefix=f'SS-{product_id:05d}_',dir=base))
        try:
            for index,row in enumerate(rows,1):
                source=self.resolve(row['relative_path'])
                shutil.copy2(source,folder/f'SS-{product_id:05d}_{index:02d}{source.suffix}')
        except Exception:
            shutil.rmtree(folder)
            raise
        return folder

    def backup_zip(self, destination):
        dest=Path(destination).resolve()
        if dest==self.store.path.resolve():
            raise PhotoError('Nie możesz nadpisać aktywnej bazy.')
        # Ochrona przed nadpisaniem zdjęcia dowolnego produktu.
        with self.store.connect() as con:
            files=con.execute('SELECT relative_path,thumbnail_path,original_relative_path FROM product_photos').fetchall()
        protected={self.resolve(r[k]) for r in files for k in ('relative_path','thumbnail_path','original_relative_path') if r[k]}
        if dest in protected:raise PhotoError('Wybierz inny plik docelowy niż zdjęcie produktu.')
        dest.parent.mkdir(parents=True,exist_ok=True)
        with tempfile.TemporaryDirectory(prefix='.streetsell-backup-',dir=dest.parent) as temporary:
            temporary=Path(temporary)
            db=temporary/'streetsell.db'
            self.store.backup(db)
            with sqlite3.connect(db) as con:
                rows=con.execute('SELECT relative_path,thumbnail_path,original_relative_path FROM product_photos').fetchall()
            archive=temporary/'backup.zip'
            with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
                z.write(db,'streetsell.db')
                archived_names=set()
                for row in rows:
                    for relative in row:
                        if relative and relative not in archived_names:
                            path=self.resolve(relative)
                            if path.is_file():z.write(path,relative);archived_names.add(relative)
                            elif relative!=row[1]:raise PhotoError('Brakuje pliku zdjęcia lub jego oryginału. Kopia nie została utworzona.')
                z.writestr('PRZYWRACANIE.txt','Zamknij aplikację. Zachowaj dotychczasowe dane. Rozpakuj streetsell.db i folder media do folderu aplikacji. Poświadczenia Allegro i OpenAI pozostają w magazynie Windows, poza tą kopią.\n')
            os.replace(archive,dest)
        return dest
