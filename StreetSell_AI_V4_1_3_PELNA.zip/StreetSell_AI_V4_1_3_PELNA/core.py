"""StreetSell AI V3 — lokalny panel przygotowania ofert."""
import csv
import json
import queue
import sqlite3
import threading
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path
from datetime import datetime
import legacy
from storage import Store, STATUSES, CONDITIONS

BG = '#101014'
PANEL = '#1b1b22'
FIELD = '#24242d'
TEXT = '#f1f1f5'
MUTED = '#ababba'
RED = '#d32f45'

class App(legacy.App):
    def __init__(self):
        # Zachowujemy istniejącą bazę i format klucza z V2.
        self.store = Store(legacy.DB_PATH)
        if legacy.DB_PATH.exists():
            backup = legacy.APP_DIR / 'backups' / 'przed_V3.db'
            if not backup.exists():
                backup.parent.mkdir(exist_ok=True)
                self.store.backup(backup)
        legacy.init_db()
        self.store.migrate()
        self.dirty = False
        self.loading = False
        self.busy_id = None
        self.events = queue.Queue()
        self.closing = False
        super().__init__()
        self.title('StreetSell AI V3 — przygotowanie ofert')
        self.geometry('1420x900')
        self.minsize(1100, 730)
        self.protocol('WM_DELETE_WINDOW', self.close)
        self.after(100, self.poll_events)

    def _build_ui(self):
        self.configure(bg=BG)
        style = ttk.Style(self)
        style.theme_use('clam')
        style.configure('.', background=PANEL, foreground=TEXT, font=('Segoe UI', 10))
        style.configure('TFrame', background=BG)
        style.configure('TLabel', background=BG, foreground=TEXT)
        style.configure('Muted.TLabel', foreground=MUTED)
        style.configure('TButton', background=FIELD, foreground=TEXT, padding=(12, 8), borderwidth=0)
        style.map('TButton', background=[('active', '#383842'), ('disabled', '#202027')])
        style.configure('Accent.TButton', background=RED)
        style.map('Accent.TButton', background=[('active', '#f0445c'), ('disabled', '#642631')])
        style.configure('TEntry', fieldbackground=FIELD, foreground=TEXT, insertcolor=TEXT, padding=6)
        style.configure('TCombobox', fieldbackground=FIELD, background=FIELD, foreground=TEXT, padding=5)
        style.map('TCombobox', fieldbackground=[('readonly', FIELD)], foreground=[('readonly', TEXT)])
        style.configure('Treeview', background=PANEL, fieldbackground=PANEL, foreground=TEXT,
                        rowheight=32, borderwidth=0)
        style.configure('Treeview.Heading', background=FIELD, foreground=MUTED, padding=8)
        style.map('Treeview', background=[('selected', '#672331')], foreground=[('selected', '#ffffff')])
        style.configure('TPanedwindow', background=BG)

        top = ttk.Frame(self, padding=(18, 14))
        top.pack(fill='x')
        ttk.Label(top, text='STREETSELL', font=('Segoe UI', 23, 'bold'), foreground=RED).pack(side='left')
        ttk.Label(top, text=' AI  /  V3', font=('Segoe UI', 16, 'bold')).pack(side='left')
        ttk.Label(top, text='PRZYGOTOWANIE OFERT', style='Muted.TLabel').pack(side='right')
        tk.Frame(self, bg=RED, height=3).pack(fill='x')

        actions = ttk.Frame(self, padding=(18, 12))
        actions.pack(fill='x')
        ttk.Button(actions, text='Import Excel / CSV', command=self.import_file).pack(side='left')
        self.analyze_button = ttk.Button(actions, text='Analizuj produkt AI', style='Accent.TButton', command=self.analyze_selected)
        self.analyze_button.pack(side='left', padx=8)
        ttk.Button(actions, text='Klucz OpenAI', command=self.configure_key).pack(side='left')
        ttk.Button(actions, text='Eksport CSV', command=self.export_csv).pack(side='left', padx=8)
        ttk.Button(actions, text='Kopia bazy', command=self.backup_db).pack(side='left')
        ttk.Button(actions, text='Etapy integracji', command=self.integration_info).pack(side='right')

        filters = ttk.Frame(self, padding=(18, 0, 18, 10))
        filters.pack(fill='x')
        ttk.Label(filters, text='Szukaj:').pack(side='left')
        self.search_var = tk.StringVar()
        search = ttk.Entry(filters, textvariable=self.search_var, width=36)
        search.pack(side='left', padx=8)
        search.bind('<Return>', lambda e: self.refresh())
        self.filter_var = tk.StringVar(value='Wszystkie')
        combo = ttk.Combobox(filters, textvariable=self.filter_var, values=('Wszystkie', *STATUSES), state='readonly', width=18)
        combo.pack(side='left')
        combo.bind('<<ComboboxSelected>>', lambda e: self.refresh())
        ttk.Button(filters, text='Szukaj / odśwież', command=self.refresh).pack(side='left', padx=8)
        self.summary = ttk.Label(filters, text='', style='Muted.TLabel')
        self.summary.pack(side='right')

        main = ttk.Panedwindow(self, orient='vertical')
        main.pack(fill='both', expand=True, padx=18)
        table = ttk.Frame(main)
        cols = ('number', 'name', 'asin', 'ean', 'qty', 'condition', 'status', 'ai_status')
        self.tree = ttk.Treeview(table, columns=cols, show='headings', selectmode='browse', height=9)
        labels = ('Numer', 'Produkt z palety', 'ASIN', 'EAN z pliku', 'Szt.', 'Stan', 'Weryfikacja', 'Analiza AI')
        widths = (95, 360, 115, 125, 45, 110, 120, 145)
        for key, label, width in zip(cols, labels, widths):
            self.tree.heading(key, text=label)
            self.tree.column(key, width=width, minwidth=45, stretch=key == 'name')
        self.tree.grid(row=0, column=0, sticky='nsew')
        ttk.Scrollbar(table, orient='vertical', command=self.tree.yview).grid(row=0, column=1, sticky='ns')
        sy = table.grid_slaves(row=0, column=1)[0]
        self.tree.configure(yscrollcommand=sy.set)
        sx = ttk.Scrollbar(table, orient='horizontal', command=self.tree.xview)
        sx.grid(row=1, column=0, sticky='ew')
        self.tree.configure(xscrollcommand=sx.set)
        table.columnconfigure(0, weight=1)
        table.rowconfigure(0, weight=1)
        self.tree.bind('<<TreeviewSelect>>', self.on_select)
        main.add(table, weight=2)

        detail = ttk.Frame(main, padding=(0, 12))
        head = ttk.Frame(detail)
        head.pack(fill='x')
        self.product_label = ttk.Label(head, text='Wybierz produkt z tabeli', font=('Segoe UI', 12, 'bold'))
        self.product_label.pack(side='left')
        self.save_label = ttk.Label(head, text='', foreground=RED)
        self.save_label.pack(side='right')
        fields = ttk.Frame(detail, padding=(0, 10))
        fields.pack(fill='x')
        self.vars = {}
        for name, label, width in [('condition', 'Stan produktu', 18), ('quantity', 'Ilość', 7), ('sale_price', 'Cena sprzedaży (zł)', 15)]:
            ttk.Label(fields, text=label).pack(side='left', padx=(0, 6))
            var = tk.StringVar()
            self.vars[name] = var
            if name == 'condition':
                widget = ttk.Combobox(fields, textvariable=var, values=CONDITIONS, state='readonly', width=width)
            else:
                widget = ttk.Entry(fields, textvariable=var, width=width)
            widget.pack(side='left', padx=(0, 18))
            var.trace_add('write', self.mark_dirty)
        ttk.Button(fields, text='Kopiuj tytuł', command=lambda: self.copy_text(self.title_box)).pack(side='right')
        ttk.Button(fields, text='Kopiuj opis', command=lambda: self.copy_text(self.description_box)).pack(side='right', padx=6)

        ttk.Label(detail, text='Tytuł oferty').pack(anchor='w')
        self.title_box = self.textbox(detail, 2)
        columns = ttk.Panedwindow(detail, orient='horizontal')
        columns.pack(fill='both', expand=True, pady=(8, 0))
        left, right = ttk.Frame(columns), ttk.Frame(columns)
        ttk.Label(left, text='Opis — sprawdź wariant, wymiary i liczbę sztuk').pack(anchor='w')
        self.description_box = self.textbox(left, 8)
        ttk.Label(right, text='Zawartość zestawu (Twoje ustalenia)').pack(anchor='w')
        self.contents_box = self.textbox(right, 2)
        ttk.Label(right, text='Braki / wady (Twoje ustalenia)').pack(anchor='w', pady=(6, 0))
        self.defects_box = self.textbox(right, 2)
        ttk.Label(right, text='Dopasowanie, niepewne dane i źródła AI').pack(anchor='w', pady=(6, 0))
        self.notes_box = self.textbox(right, 4)
        columns.add(left, weight=3)
        columns.add(right, weight=2)
        main.add(detail, weight=3)
        bottom = ttk.Frame(self, padding=(18, 8))
        bottom.pack(fill='x')
        ttk.Button(bottom, text='Zapisz szkic', command=self.save_draft).pack(side='left')
        ttk.Button(bottom, text='Sprawdziłem — zatwierdź', style='Accent.TButton', command=self.approve).pack(side='left', padx=8)
        self.statusbar = ttk.Label(bottom, text='Gotowy. Publikacja na Allegro jest obecnie ręczna.', style='Muted.TLabel')
        self.statusbar.pack(side='right')
        self.bind('<Control-s>', lambda e: self.save_draft())

    def textbox(self, parent, height):
        box = tk.Text(parent, height=height, bg=FIELD, fg=TEXT, insertbackground=TEXT,
                      selectbackground='#672331', relief='flat', wrap='word', padx=9, pady=7,
                      font=('Segoe UI', 10), undo=True)
        box.pack(fill='both', expand=True, pady=(4, 0))
        box.bind('<<Modified>>', self.text_modified)
        return box

    def text_modified(self, event):
        if event.widget.edit_modified():
            self.mark_dirty()
            event.widget.edit_modified(False)

    def mark_dirty(self, *_):
        if not self.loading and self.selected_id is not None:
            self.dirty = True
            self.save_label.config(text='Niezapisane zmiany')

    def values(self):
        result = {k: v.get() for k, v in self.vars.items()}
        for name, box in [('generated_title', self.title_box), ('generated_description', self.description_box),
                          ('contents', self.contents_box), ('defects', self.defects_box), ('research_notes', self.notes_box)]:
            result[name] = box.get('1.0', 'end-1c')
        return result

    def save_draft(self, approved=False):
        if self.selected_id is None:
            return False
        if self.busy_id == self.selected_id:
            messagebox.showinfo('Trwa analiza', 'Poczekaj na zakończenie analizy tego produktu.')
            return False
        try:
            self.store.save(self.selected_id, self.values(), approved)
        except ValueError as exc:
            messagebox.showwarning('Sprawdź dane', str(exc))
            return False
        self.dirty = False
        self.save_label.config(text='Zatwierdzono' if approved else 'Zapisano szkic')
        self.load_db()
        self.statusbar.config(text='Zapisano lokalnie. Oferta nie została opublikowana na Allegro.')
        return True

    def approve(self):
        if self.selected_id is not None:
            self.save_draft(approved=True)

    def confirm_pending(self):
        if not self.dirty:
            return True
        answer = messagebox.askyesnocancel('Niezapisane zmiany', 'Zapisać zmiany w aktualnym produkcie?\nTak — zapisz. Nie — odrzuć. Anuluj — zostań przy produkcie.')
        if answer is None:
            return False
        if answer:
            return self.save_draft()
        self.dirty = False
        return True

    def load_db(self):
        rows = self.store.products(self.search_var.get(), self.filter_var.get())
        # Edytowany wiersz zostaje widoczny również po zmianie statusu.
        if self.selected_id and not any(r['id'] == self.selected_id for r in rows):
            row = self.store.get(self.selected_id)
            if row:
                rows.append(row)
        self.loading = True
        self.tree.delete(*self.tree.get_children())
        for r in rows:
            self.tree.insert('', 'end', iid=str(r['id']), values=(f"SS-{r['id']:05d}", r['product_name'],
                r['asin'], r['ean'], r['quantity'], r['condition'], r['status'],
                'Analizuję…' if r['id'] == self.busy_id else r['ai_status']))
        if self.selected_id and self.tree.exists(str(self.selected_id)):
            self.tree.selection_set(str(self.selected_id))
        all_rows = self.store.products()
        qty = sum(r['quantity'] or 0 for r in all_rows)
        approved = sum(r['status'] == 'Zatwierdzony' for r in all_rows)
        self.summary.config(text=f'Produkty: {len(all_rows)}  •  Sztuki: {qty}  •  Zatwierdzone: {approved}')
        self.loading = False

    def refresh(self):
        if not self.confirm_pending():
            return
        self.selected_id = None
        self.clear_detail()
        self.load_db()

    def clear_detail(self):
        self.loading = True
        for var in self.vars.values():
            var.set('')
        for box in (self.title_box, self.description_box, self.contents_box, self.defects_box, self.notes_box):
            self._set_text(box, '')
            box.edit_modified(False)
        self.product_label.config(text='Wybierz produkt z tabeli')
        self.save_label.config(text='')
        self.dirty = False
        self.loading = False

    def on_select(self, _event=None):
        selected = self.tree.selection()
        if self.loading or not selected:
            return
        target = int(selected[0])
        if target == self.selected_id:
            return
        old = self.selected_id
        if not self.confirm_pending():
            if old and self.tree.exists(str(old)):
                self.tree.selection_set(str(old))
            return
        self.selected_id = target
        self.tree.selection_set(str(target))
        self.show_product()

    def show_product(self):
        row = self.store.get(self.selected_id)
        if not row:
            return
        self.loading = True
        for key, var in self.vars.items():
            var.set(str(row[key] if row[key] is not None else ''))
        for key, box in [('generated_title', self.title_box), ('generated_description', self.description_box),
                         ('contents', self.contents_box), ('defects', self.defects_box), ('research_notes', self.notes_box)]:
            self._set_text(box, row[key] or '')
            box.edit_modified(False)
            box.edit_reset()
        self.product_label.config(text=f"SS-{row['id']:05d}  •  {(row['product_name'] or '')[:95]}")
        self.save_label.config(text=row['status'])
        self.dirty = False
        self.loading = False

    def copy_text(self, box):
        self.clipboard_clear()
        self.clipboard_append(box.get('1.0', 'end-1c'))
        self.statusbar.config(text='Skopiowano do schowka.')

    def analyze_selected(self):
        if self.selected_id is None:
            messagebox.showinfo('Wybierz produkt', 'Zaznacz produkt do analizy.')
            return
        if self.busy_id is not None or not self.confirm_pending():
            return
        row = self.store.get(self.selected_id)
        if row['generated_title'] or row['generated_description']:
            if not messagebox.askyesno('Nowa analiza', 'Nowa analiza zastąpi zapisany tytuł, opis i notatki AI tego produktu. Kontynuować?'):
                return
        key = legacy.get_api_key()
        if not key:
            messagebox.showinfo('Klucz API', 'Ustaw klucz OpenAI, aby uruchomić analizę.')
            return
        self.busy_id = self.selected_id
        self.store.invalidate_approval(self.busy_id)
        self.analyze_button.state(['disabled'])
        self.load_db()
        self.statusbar.config(text='Trwa analiza AI. Możesz przeglądać pozostałe produkty.')
        data = (row['product_name'], row['asin'], row['ean'], row['category'], row['product_link'])
        # V2 odpowiada za wywołanie API; wynik trafia przez kolejkę na główny wątek.
        threading.Thread(target=self._analyze_worker, args=(self.busy_id, data, key), daemon=True).start()

    def after(self, ms, func=None, *args):
        if threading.current_thread() is not threading.main_thread() and func is not None:
            self.events.put((func, args))
            return None
        return super().after(ms, func, *args)

    def poll_events(self):
        while True:
            try:
                func, args = self.events.get_nowait()
            except queue.Empty:
                break
            func(*args)
        if not self.closing:
            self.after(100, self.poll_events)

    def _analysis_done(self, product_id, error):
        self.busy_id = None
        self.analyze_button.state(['!disabled'])
        if error:
            with self.store.connect() as con:
                con.execute("UPDATE products SET ai_status='Błąd analizy' WHERE id=?", (product_id,))
        self.load_db()
        if self.selected_id == product_id and not self.dirty:
            self.show_product()
        if error:
            self.statusbar.config(text='Analiza nie powiodła się — wcześniejszy szkic zachowany.')
            messagebox.showerror('Błąd analizy AI', str(error))
        else:
            self.statusbar.config(text=f'Analiza SS-{product_id:05d} zakończona. Sprawdź wynik i zapisz zatwierdzenie.')
            messagebox.showinfo('Gotowy szkic', f'SS-{product_id:05d}: szkic AI zapisano. Sprawdź dokładny wariant, zawartość, stan i źródła.')

    def import_file(self):
        if not self.confirm_pending():
            return
        path = filedialog.askopenfilename(title='Specyfikacja palety', filetypes=[('Excel / CSV', '*.xlsx *.xls *.csv')])
        if not path:
            return
        try:
            digest = self.store.digest(path)
            with self.store.connect() as con:
                duplicate = con.execute('SELECT filename FROM imports WHERE digest=?', (digest,)).fetchone()
            if duplicate and not messagebox.askyesno('Ten plik był importowany', 'Zawartość tego pliku już zaimportowano w V3. Dodać kolejne egzemplarze produktów?'):
                return
            if path.lower().endswith('.csv'):
                with open(path, encoding='utf-8-sig', newline='') as f:
                    sample = f.read(8192)
                    f.seek(0)
                    try:
                        dialect = csv.Sniffer().sniff(sample, delimiters=';,\t')
                    except csv.Error:
                        dialect = csv.excel
                    reader = csv.DictReader(f, dialect=dialect)
                    headers, rows = reader.fieldnames or [], list(reader)
            else:
                import pandas as pd
                df = pd.read_excel(path, sheet_name=0, dtype=str).fillna('')
                headers, rows = list(df.columns), df.to_dict(orient='records')
            mapped = {k: legacy.find_col(headers, v) for k, v in legacy.COLUMN_ALIASES.items()}
            if not mapped['name'] and not mapped['asin']:
                raise ValueError('Nie znaleziono kolumny nazwy produktu ani ASIN. Sprawdź nagłówki pliku.')
            inserted = 0
            with self.store.connect() as con:
                for number, row in enumerate(rows, 2):
                    def get(k):
                        return str(row.get(mapped[k], '') or '').strip() if mapped[k] else ''
                    if not get('name') and not get('asin'):
                        continue
                    from decimal import Decimal, InvalidOperation
                    try:
                        quantity = Decimal(get('qty').replace(',', '.') or '1')
                        if not quantity.is_finite() or quantity < 0 or quantity != quantity.to_integral_value():
                            raise InvalidOperation
                        qty = int(quantity)
                    except (ValueError, InvalidOperation):
                        raise ValueError(f'Wiersz {number}: nieprawidłowa ilość. Popraw plik; import anulowano.')
                    con.execute('''INSERT INTO products (source_file, product_name, asin, ean, sku, category,
                        quantity, gross_price, net_price, product_link) VALUES (?,?,?,?,?,?,?,?,?,?)''',
                        (Path(path).name, get('name'), get('asin'), get('ean'), get('sku'), get('category'),
                         qty, get('price_gross'), get('price_net'), get('link')))
                    inserted += 1
                if not inserted:
                    raise ValueError('Plik nie zawiera produktów. Nie zmieniono bazy.')
                con.execute('INSERT OR REPLACE INTO imports VALUES (?,?,?)', (digest, Path(path).name, datetime.now().isoformat()))
            self.load_db()
            messagebox.showinfo('Import zakończony', f'Dodano {inserted} produktów. Numery SS są stałe i niezależne od sortowania.')
        except Exception as exc:
            messagebox.showerror('Błąd importu', str(exc))

    def export_csv(self):
        if not self.confirm_pending():
            return
        path = filedialog.asksaveasfilename(defaultextension='.csv', filetypes=[('CSV', '*.csv')])
        if not path:
            return
        fields = [('Numer', 'id'), ('Nazwa', 'product_name'), ('ASIN', 'asin'), ('EAN z palety', 'ean'),
                  ('SKU', 'sku'), ('Ilość', 'quantity'), ('Stan', 'condition'), ('Cena sprzedaży PLN', 'sale_price'),
                  ('Tytuł', 'generated_title'), ('Opis', 'generated_description'), ('Zawartość', 'contents'),
                  ('Wady i braki', 'defects'), ('Notatki i źródła', 'research_notes'), ('Status', 'status')]
        try:
            rows = self.store.products()
            with open(path, 'w', encoding='utf-8-sig', newline='') as f:
                writer = csv.writer(f, delimiter=';')
                writer.writerow([name for name, _ in fields])
                for row in rows:
                    writer.writerow([f"SS-{row['id']:05d}" if key == 'id' else row[key] for _, key in fields])
            messagebox.showinfo('Eksport gotowy', f'Wyeksportowano {len(rows)} produktów. To plik roboczy, nie automatyczny import ofert Allegro.')
        except OSError as exc:
            messagebox.showerror('Błąd eksportu', str(exc))

    def backup_db(self):
        if not self.confirm_pending():
            return
        path = filedialog.asksaveasfilename(initialfile=f'streetsell_{datetime.now():%Y%m%d_%H%M%S}.db',
                                            defaultextension='.db', filetypes=[('Baza StreetSell', '*.db')])
        if path:
            try:
                self.store.backup(path)
                messagebox.showinfo('Kopia gotowa', 'Zapisano pełną kopię danych produktów.')
            except Exception as exc:
                messagebox.showerror('Błąd kopii', str(exc))

    def integration_info(self):
        messagebox.showinfo('StreetSell AI V3 — etapy',
            'DZIAŁA W TEJ WERSJI\nImport Excel/CSV, numery produktów, wyszukiwanie, analiza AI z V2, '
            'edytor szkiców, ręczne zatwierdzanie, eksport i kopie bazy.\n\n'
            'DO DALSZEJ ROZBUDOWY\nPołączenie konta Allegro, publikacja, pobieranie zamówień, '
            'przygotowanie etykiet z zatwierdzeniem druku, powiadomienia oraz licznik zamówień i sprzedaży. '
            'Import PDF/skanów i obróbka zdjęć wymagają osobnych modułów.\n\n'
            'Zatwierdzenie szkicu obecnie zapisuje decyzję lokalnie.')

    def close(self):
        if self.busy_id is not None:
            messagebox.showinfo('Trwa analiza', 'Poczekaj na zakończenie analizy przed zamknięciem aplikacji.')
            return
        if self.confirm_pending():
            self.closing = True
            self.destroy()

if __name__ == '__main__':
    App().mainloop()
