"""Prawdziwe zamówienia Allegro, odczyt i lokalna kopia listy bez adresów."""
import json
import re
from dataclasses import dataclass
from datetime import datetime,timedelta,timezone
from urllib.parse import urlencode,quote
from allegro_api import AllegroClient,AllegroError,ApiError
from daily_sales import WARSAW,today_bounds,money,pln,aggregate

FULFILLMENT={'NEW':'Nowe','PROCESSING':'W realizacji','READY_FOR_SHIPMENT':'Do wysłania',
 'READY_FOR_PICKUP':'Do odbioru','SENT':'Wysłane','PICKED_UP':'Odebrane','CANCELLED':'Anulowane',
 'SUSPENDED':'Wstrzymane','RETURNED':'Zwrócone'}
ORDER_STATUS={'BOUGHT':'Zakup bez formularza','FILLED_IN':'Oczekuje na płatność',
 'READY_FOR_PROCESSING':'Potwierdzone','CANCELLED':'Anulowane'}
PERIODS={'Dzisiaj':1,'Ostatnie 7 dni':7,'Ostatnie 30 dni':30,'Ostatnie 90 dni':90}
FILTERS=('Wszystkie','Do realizacji','Oczekuje na płatność','Wysłane / odebrane','Anulowane / zwrócone')

def timestamp(value):
    try:
        result=datetime.fromisoformat(str(value).replace('Z','+00:00'))
        if result.tzinfo is None:raise ValueError()
        return result
    except (ValueError,TypeError):raise AllegroError('Allegro zwróciło nieprawidłową datę zamówienia.') from None

def period_bounds(days,now):
    if days not in PERIODS.values():raise ValueError('Nieprawidłowy zakres dat.')
    _,start,end=today_bounds(now)
    local_start=start.astimezone(WARSAW)-timedelta(days=days-1)
    return local_start.astimezone(timezone.utc),end

def normalized(form):
    """Nie zapisujemy adresów, e-maili, telefonu, faktur i wiadomości do cache."""
    try:
        ident=form['id'];items=form['lineItems']
        if not isinstance(ident,str) or not ident or not isinstance(items,list) or not items:raise ValueError()
        lines=[]
        for item in items:
            qty=item['quantity'];price=item['price'];offer=item.get('offer') or {}
            if type(qty) is not int or qty<1:raise ValueError()
            currency=price['currency']
            if not isinstance(currency,str) or not re.fullmatch('[A-Z]{3}',currency):raise ValueError()
            line_id=item['id']
            if not isinstance(line_id,str) or not line_id:raise ValueError()
            bought=timestamp(item['boughtAt']).isoformat()
            lines.append(dict(id=line_id,quantity=qty,price=str(money(price['amount'])),currency=currency,
                bought_at=bought,name=str(offer.get('name') or 'Produkt')[:1000],offer_id=str(offer.get('id') or '')[:128],
                external_id=str((offer.get('external') or {}).get('id') or '')[:128]))
        summary=(form.get('summary') or {}).get('totalToPay') or {}
        payment=form.get('payment') or {};paid=payment.get('paidAmount') or {}
        fulfillment=form.get('fulfillment') or {};delivery=form.get('delivery') or {}
        return dict(id=ident,updated_at=str(form.get('updatedAt') or ''),
            status=str(form.get('status') or ''),fulfillment=str(fulfillment.get('status') or ''),
            buyer=str((form.get('buyer') or {}).get('login') or 'Kupujący')[:300],
            lines=lines,bought_at=max((line['bought_at'] for line in lines),key=timestamp),
            total=str(money(summary['amount'])) if summary.get('amount') is not None else '',
            currency=str(summary.get('currency') or ''),payment_type=str(payment.get('type') or ''),
            paid=str(money(paid['amount'])) if paid.get('amount') is not None else '',paid_currency=str(paid.get('currency') or ''),
            delivery=str((delivery.get('method') or {}).get('name') or 'Nie wybrano'),
            parcels=str((fulfillment.get('shipmentSummary') or {}).get('lineItemsSent') or ''))
    except (KeyError,ValueError,TypeError,AttributeError):
        raise AllegroError('Niepełne dane zamówienia z Allegro. Nie zapisano częściowej listy.') from None

def state_text(order):
    if order['status']=='CANCELLED':return 'Anulowane'
    if order['status']!='READY_FOR_PROCESSING':return ORDER_STATUS.get(order['status'],order['status'] or 'Nieznany')
    return FULFILLMENT.get(order['fulfillment'],order['fulfillment'] or 'Potwierdzone')

def payment_text(order):
    if order['payment_type']=='CASH_ON_DELIVERY':return 'Pobranie — nie oznacza wpływu'
    if order['status']=='CANCELLED':return 'Anulowane — sprawdź rozliczenie'
    if order['paid'] and order['currency']==order['paid_currency'] and order['total'] and money(order['paid'])>=money(order['total']):return 'Opłacone'
    if order['status']=='READY_FOR_PROCESSING':return 'Potwierdzone — sprawdź rozliczenie'
    return 'Oczekuje / niepotwierdzona'

def matches(order,query='',status='Wszystkie'):
    if query.strip().casefold() not in ' '.join([order['id'],order['buyer'],*(v for l in order['lines'] for v in (l['name'],l['offer_id'],l['external_id']))]).casefold():return False
    fulfilled=order['fulfillment'];cancelled=order['status']=='CANCELLED' or fulfilled in ('CANCELLED','RETURNED')
    if status=='Do realizacji':return order['status']=='READY_FOR_PROCESSING' and fulfilled in ('','NEW','PROCESSING','READY_FOR_SHIPMENT') and not cancelled
    if status=='Oczekuje na płatność':return order['status'] in ('BOUGHT','FILLED_IN') and not cancelled
    if status=='Wysłane / odebrane':return fulfilled in ('SENT','PICKED_UP','READY_FOR_PICKUP') and not cancelled
    if status=='Anulowane / zwrócone':return cancelled
    return True

def amount_text(order):
    if order['total'] and order['currency']:
        return pln(money(order['total'])) if order['currency']=='PLN' else order['total']+' '+order['currency']
    return 'Brak pełnej kwoty'

@dataclass
class OrdersSnapshot:
    account:str
    login:str
    days:int
    fetched_at:str
    orders:list

class OrdersService:
    def __init__(self,store,client_factory=AllegroClient):
        self.store=store;self.factory=client_factory
        with store.connect() as con:
            con.execute('''CREATE TABLE IF NOT EXISTS allegro_order_lists (
                account TEXT NOT NULL,days INTEGER NOT NULL,login TEXT NOT NULL,
                fetched_at TEXT NOT NULL,payload TEXT NOT NULL,PRIMARY KEY(account,days))''')
    def session(self):
        client=self.factory('production');profile=client.profile()
        config=client._config();token=(client.state().get('tokens') or {}).get('access_token')
        if not token:raise AllegroError('Połącz konto Allegro, aby pobrać zamówienia.')
        return client,profile,config,token
    @staticmethod
    def request(client,config,token,path):
        try:return client.transport.request(client.api_url+path,'GET',client._headers(config,token))
        except ApiError as exc:
            if exc.status==403:raise AllegroError('Brak odczytu zamówień. Włącz allegro:api:orders:read i połącz konto ponownie.') from None
            raise
    def fetch(self,days=30,now=None):
        now=now or datetime.now(timezone.utc);start,end=period_bounds(days,now)
        client,profile,config,token=self.session();raw={};offset=0
        while True:
            params={'lineItems.boughtAt.gte':start.isoformat().replace('+00:00','Z'),
                'lineItems.boughtAt.lte':(end-timedelta(milliseconds=1)).isoformat().replace('+00:00','Z'),
                'limit':100,'offset':offset,'sort':'-lineItems.boughtAt'}
            payload=self.request(client,config,token,'/order/checkout-forms?'+urlencode(params))
            forms=payload.get('checkoutForms')
            if not isinstance(forms,list) or any(not isinstance(o,dict) for o in forms):raise AllegroError('Nieprawidłowa lista zamówień Allegro.')
            for form in forms:
                row=normalized(form);previous=raw.get(row['id'])
                if previous is None or row['updated_at']>=previous['updated_at']:raw[row['id']]=row
            offset+=len(forms);total=payload.get('totalCount')
            if not forms:
                if type(total) is int and offset<total:raise AllegroError('Lista zamówień zmieniła się podczas pobierania. Odśwież ponownie; nie zapisano częściowej listy.')
                break
            if type(total) is int:
                if offset>=total:break
            elif len(forms)<100:break
            if offset>=2000:raise AllegroError('Ponad 2000 zamówień w wybranym okresie. Wybierz krótszy zakres; nie zapisano częściowej listy.')
        orders=sorted(raw.values(),key=lambda o:timestamp(o['bought_at']),reverse=True)
        snapshot=OrdersSnapshot(profile['id'],profile['login'],days,now.astimezone(WARSAW).isoformat(timespec='seconds'),orders)
        with self.store.connect() as con:
            con.execute('INSERT OR REPLACE INTO allegro_order_lists VALUES(?,?,?,?,?)',
                (snapshot.account,days,snapshot.login,snapshot.fetched_at,json.dumps(orders,ensure_ascii=False)))
        return snapshot
    def details(self,account,ident):
        if not isinstance(ident,str) or not re.fullmatch('[0-9a-fA-F-]{36}',ident):raise AllegroError('Nieprawidłowy numer zamówienia.')
        client,profile,config,token=self.session()
        if profile['id']!=account:raise AllegroError('Konto Allegro zostało zmienione. Odśwież listę zamówień.')
        path='/order/checkout-forms/'+quote(ident,safe='')
        form=self.request(client,config,token,path)
        if not isinstance(form,dict) or form.get('id')!=ident:raise AllegroError('Allegro zwróciło inne zamówienie. Odśwież listę.')
        normalized(form)
        warning=''
        try:
            payload=self.request(client,config,token,path+'/shipments');shipments=payload.get('shipments')
            if not isinstance(shipments,list):raise AllegroError('Nieprawidłowa lista przesyłek.')
        except AllegroError as exc:shipments=[];warning=str(exc)
        return dict(form=form,shipments=shipments,warning=warning)


def daily_from_orders(snapshot):
    """Pasek i lista korzystają z jednego, kompletnego pobrania i jednego konta."""
    now=timestamp(snapshot.fetched_at);day,start,end=today_bounds(now)
    raw=[]
    for row in snapshot.orders:
        raw.append(dict(id=row['id'],updatedAt=row['updated_at'],status=row['status'],
            fulfillment={'status':row['fulfillment']},payment={'type':row['payment_type']},
            lineItems=[dict(id=line['id'],quantity=line['quantity'],boughtAt=line['bought_at'],
                price={'amount':line['price'],'currency':line['currency']},offer={'name':line['name']}) for line in row['lines']]))
    return aggregate(raw,day,start,end,snapshot.account,snapshot.login,now)

def today_overview(snapshot):
    now=timestamp(snapshot.fetched_at);_,start,end=today_bounds(now)
    seen=set();counts={'total':0,'ready':0,'waiting':0,'cancelled':0,'other':0}
    for row in sorted(snapshot.orders,key=lambda o:o['updated_at'],reverse=True):
        current=[]
        for line in row['lines']:
            if line['id'] in seen:continue
            seen.add(line['id'])
            if start<=timestamp(line['bought_at'])<end:current.append(line)
        if not current:continue
        counts['total']+=1
        if row['status']=='CANCELLED' or row['fulfillment'] in ('CANCELLED','RETURNED'):counts['cancelled']+=1
        elif row['status']=='READY_FOR_PROCESSING':counts['ready']+=1
        elif row['status'] in ('BOUGHT','FILLED_IN'):counts['waiting']+=1
        else:counts['other']+=1
    return counts
