"""Opt-in, expiring local session. Random token in Windows Credential Manager."""
import hashlib,secrets,sys,time
from owner_auth import AuthError

class SessionError(ValueError):pass

def windows_vault():
    if sys.platform!='win32':raise SessionError('Zapamiętywanie sesji wymaga magazynu poświadczeń Windows.')
    from keyring.backends.Windows import WinVaultKeyring
    return WinVaultKeyring()

class OwnerSession:
    def __init__(self,auth,backend=None):
        self.auth=auth;self.backend_factory=backend or windows_vault
        scope=str(auth.path.resolve())
        if sys.platform=='win32':scope=scope.casefold()
        self.service='StreetSellAI.OwnerSession.'+hashlib.sha256(scope.encode()).hexdigest()[:24]
        self.username='owner'
    def remember(self):
        data=self.auth.read();token=secrets.token_urlsafe(32);now=time.time()
        record=dict(token_hash=hashlib.sha256(token.encode()).hexdigest(),created=now,expires=now+30*86400,password_hash=data['password']['hash'])
        try:
            backend=self.backend_factory();backend.set_password(self.service,self.username,token)
            data['session']=record;self.auth.write(data)
        except Exception:
            try:backend.delete_password(self.service,self.username)
            except Exception:pass
            raise SessionError('Nie udało się zapamiętać sesji w Windows. Możesz zalogować się bez tej opcji.') from None
    def resume(self):
        try:
            data=self.auth.read();record=data.get('session') or {};now=time.time()
            if not record or not record['created']<=now<record['expires'] or record['expires']-record['created']>30*86400 or record['password_hash']!=data['password']['hash']:return None
            token=self.backend_factory().get_password(self.service,self.username)
            if not token or not secrets.compare_digest(hashlib.sha256(token.encode()).hexdigest(),record['token_hash']):return None
            return data['login']
        except Exception:return None
    def forget(self):
        # Revoke before deleting credentials: a vault error cannot leave a usable token.
        if self.auth.exists():
            data=self.auth.read();data.pop('session',None);self.auth.write(data)
        try:self.backend_factory().delete_password(self.service,self.username)
        except Exception:pass
