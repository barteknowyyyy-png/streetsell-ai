"""Offer preparation and recoverable publication. No network calls at import/startup."""
import copy,hashlib,html,io,json,re,threading,uuid
from html.parser import HTMLParser
from decimal import Decimal,InvalidOperation,ROUND_HALF_UP
from datetime import datetime,timezone
from PIL import Image
from allegro_listing_api import ListingError
from cloud_sync import backup_database

LOCKS={};LOCK_GUARD=threading.Lock()

def money(value,positive=True):
    try:
        n=Decimal(str(value).strip().replace(',','.'))
        if not n.is_finite() or (n<=0 if positive else n<0) or n.as_tuple().exponent < -2:raise ValueError()
        return format(n.quantize(Decimal('.01')),'f')
    except (ValueError,InvalidOperation):raise ListingError('Podaj poprawną kwotę z maksymalnie 2 miejscami po przecinku.') from None

def calculate_price(mode,value,percent='0',floor='',ceiling=''):
    base=Decimal(money(value))
    try:p=Decimal(str(percent).strip().replace(',','.'))
    except InvalidOperation:raise ListingError('Nieprawidłowy procent ceny.') from None
    if not p.is_finite() or p<0 or (mode=='discount' and p>=100):raise ListingError('Nieprawidłowy procent ceny.')
    if mode=='markup':base*=1+p/100
    elif mode=='discount':base*=1-p/100
    elif mode!='fixed':raise ListingError('Nieznany sposób wyliczenia ceny.')
    base=base.quantize(Decimal('.01'),rounding=ROUND_HALF_UP)
    if floor:base=max(base,Decimal(money(floor)))
    if ceiling:
        cap=Decimal(money(ceiling))
        if floor and Decimal(money(floor))>cap:raise ListingError('Cena minimalna jest większa od maksymalnej.')
        base=min(base,cap)
    return money(base)

def plain_description(text):
    paragraphs=[html.escape(p).replace('\n','<br>') for p in str(text).strip().split('\n\n') if p.strip()]
    # Allegro permits a restricted HTML subset; use paragraphs, never arbitrary AI HTML.
    content=''.join('<p>'+p.replace('<br>','</p><p>')+'</p>' for p in paragraphs)
    if len(content.encode())>39000:raise ListingError('Opis jest zbyt długi dla Allegro.')
    if not content:raise ListingError('Uzupełnij opis oferty.')
    return {'sections':[{'items':[{'type':'TEXT','content':content}]}]}

def catalog_text(description):
    class Text(HTMLParser):
        def __init__(self):super().__init__();self.parts=[]
        def handle_data(self,data):self.parts.append(data)
        def handle_endtag(self,tag):
            if tag in ('p','li','h1','h2','h3'):self.parts.append('\n')
    parser=Text()
    for section in (description or {}).get('sections',[]):
        for item in section.get('items',[]):
            if item.get('type')=='TEXT':parser.feed(item.get('content',''));parser.parts.append('\n')
    return ''.join(parser.parts).strip()

def normalize_parameter(p):
    return {k:copy.deepcopy(p[k]) for k in ('id','values','valuesIds','rangeValue') if p.get(k) is not None and p.get(k)!=[]}

def seller_template(offer):
    result={}
    delivery=offer.get('delivery') or {}
    if (delivery.get('shippingRates') or {}).get('id'):result['shipping'] = delivery['shippingRates']['id']
    if delivery.get('handlingTime'):result['handlingTime']=delivery['handlingTime']
    for source,target in [('returnPolicy','returns'),('impliedWarranty','implied'),('warranty','warranty')]:
        value=(offer.get('afterSalesServices') or {}).get(source) or {}
        if value.get('id'):result[target]=value['id']
    result['location']={k:v for k,v in (offer.get('location') or {}).items() if k in ('city','countryCode','postCode','province')}
    result['invoice']=(offer.get('payments') or {}).get('invoice','NO_INVOICE')
    return result

def prepare_payload(local,catalog,parameters,choices,external,images=None):
    title=str(choices.get('title') or local.get('generated_title') or '').strip()
    if not 12<=len(title)<=75 or len(title.split())<3:raise ListingError('Tytuł Allegro musi mieć 12–75 znaków i co najmniej 3 słowa.')
    try:quantity=int(str(choices.get('quantity',local.get('quantity',0))))
    except ValueError:raise ListingError('Ilość musi być liczbą całkowitą.') from None
    if quantity<1:raise ListingError('Do wystawienia potrzebna jest co najmniej 1 sztuka.')
    if quantity>int(local.get('quantity') or 0):raise ListingError('Ilość w ofercie nie może przekraczać stanu magazynu.')
    price=money(choices.get('price',''))
    category=str((catalog.get('category') or {}).get('id') or '')
    creating=bool(catalog.get('_new'))
    if (not catalog.get('id') and not creating) or not category:raise ListingError('Wybierz produkt z katalogu Allegro albo kategorię nowego produktu.')
    supplied={str(p['id']):normalize_parameter(p) for p in choices.get('parameters',[]) if p.get('id')}
    product_params={str(p['id']):normalize_parameter(p) for p in catalog.get('parameters',[]) if p.get('id')}
    missing=[];offer_params=[];new_product_params=[]
    for definition in parameters:
        pid=str(definition['id']);is_product=(definition.get('options') or {}).get('describesProduct',False)
        value=supplied.get(pid) or (product_params.get(pid) if is_product else None)
        if (definition.get('required') or (creating and definition.get('requiredForProduct'))) and not value:missing.append(definition.get('name',pid))
        if creating and value and is_product:new_product_params.append(value)
        if value and not is_product:offer_params.append(value)
    if missing:raise ListingError('Uzupełnij parametry Allegro: '+', '.join(missing))
    loc=copy.deepcopy(choices.get('location') or {})
    if not loc.get('countryCode') or not loc.get('city') or not loc.get('postCode'):raise ListingError('Uzupełnij lokalizację wysyłki.')
    if loc['countryCode']=='PL' and (not re.fullmatch(r'\d{2}-\d{3}',loc['postCode']) or not loc.get('province')):raise ListingError('Uzupełnij polski kod pocztowy i województwo.')
    if not choices.get('shipping'):raise ListingError('Wybierz cennik dostawy pobrany z Allegro.')
    product={'product':{'name':catalog['name'],'category':{'id':category},'parameters':new_product_params}} if creating else {'product':{'id':catalog['id']}}
    if choices.get('producer'):product['responsibleProducer']={'type':'ID','id':choices['producer']}
    if choices.get('person'):product['responsiblePerson']={'id':choices['person']}
    if choices.get('safety'):product['safetyInformation']={'type':'TEXT','description':choices['safety']}
    # Optional GPSR data are never invented. Allegro validates category-specific obligations.
    if not product.get('safetyInformation') and (catalog.get('productSafety') or {}).get('safetyInformation'):
        product['safetyInformation']=copy.deepcopy(catalog['productSafety']['safetyInformation'])
    if choices.get('safety') and len(choices['safety'])>5000:raise ListingError('Informacje bezpieczeństwa mogą mieć maksymalnie 5000 znaków.')
    after={}
    for key,name in [('returns','returnPolicy'),('implied','impliedWarranty'),('warranty','warranty')]:
        if choices.get(key):after[name]={'id':choices[key]}
    payload={'name':title,'productSet':[product],'category':{'id':category},'parameters':offer_params,
        'sellingMode':{'format':'BUY_NOW','price':{'amount':price,'currency':'PLN'}},
        'stock':{'available':quantity,'unit':'UNIT'},'delivery':{'shippingRates':{'id':choices['shipping']},'handlingTime':choices.get('handlingTime') or 'PT24H'},
        'afterSalesServices':after,'payments':{'invoice':choices.get('invoice') or 'NO_INVOICE'},'location':loc,
        'description':plain_description(choices.get('description') or local.get('generated_description','')),
        'external':{'id':external},'publication':{'status':'INACTIVE','republish':False},'language':'pl-PL'}
    if images:payload['images']=images
    if choices.get('rule'):
        minimum=Decimal(money(choices.get('minimum','')));maximum=Decimal(money(choices.get('maximum','')))
        if not minimum<=Decimal(price)<=maximum:raise ListingError('Cena początkowa musi mieścić się pomiędzy minimum i maksimum reguły.')
    return payload

class ListingService:
    def __init__(self,store,api,wait=None):
        self.store=store;self.api=api;self.wait=wait or threading.Event().wait
        with store.connect() as c:exists=c.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='ss_allegro_listings'").fetchone()
        if not exists:backup_database(store.path,'przed_wystawianiem')
        with store.connect() as c:
            c.execute('''CREATE TABLE IF NOT EXISTS ss_allegro_listings(
             env TEXT,account TEXT,product_id INTEGER,external_id TEXT NOT NULL,offer_id TEXT NOT NULL DEFAULT '',
             phase TEXT NOT NULL DEFAULT 'READY',operation TEXT NOT NULL DEFAULT '',last_error TEXT NOT NULL DEFAULT '',last_price TEXT NOT NULL DEFAULT '',
             updated_at TEXT NOT NULL,PRIMARY KEY(env,account,product_id))''')
            c.execute('CREATE TABLE IF NOT EXISTS ss_allegro_defaults(env TEXT,account TEXT,data TEXT NOT NULL,PRIMARY KEY(env,account))')
        with LOCK_GUARD:self.lock=LOCKS.setdefault((str(store.path.resolve()),api.env,api.account),threading.RLock())
    def row(self,pid):
        with self.store.connect() as c:
            c.execute('INSERT OR IGNORE INTO ss_allegro_listings(env,account,product_id,external_id,updated_at) VALUES(?,?,?,?,?)',(self.api.env,self.api.account,pid,'SS4-'+str(uuid.uuid4()),datetime.now(timezone.utc).isoformat()))
            return dict(c.execute('SELECT * FROM ss_allegro_listings WHERE env=? AND account=? AND product_id=?',(self.api.env,self.api.account,pid)).fetchone())
    def state(self,pid,**fields):
        allowed={'offer_id','phase','operation','last_error','last_price'}
        if set(fields)-allowed:raise ValueError('Invalid state')
        fields['updated_at']=datetime.now(timezone.utc).isoformat()
        with self.store.connect() as c:c.execute('UPDATE ss_allegro_listings SET '+','.join(k+'=?' for k in fields)+' WHERE env=? AND account=? AND product_id=?',(*fields.values(),self.api.env,self.api.account,pid))
    def defaults(self):
        with self.store.connect() as c:r=c.execute('SELECT data FROM ss_allegro_defaults WHERE env=? AND account=?',(self.api.env,self.api.account)).fetchone()
        return json.loads(r['data']) if r else {}
    def save_defaults(self,choices):
        # Producer/condition/product-specific parameters never become global defaults.
        data={k:choices[k] for k in ('shipping','returns','implied','warranty','location','handlingTime','invoice') if k in choices}
        with self.store.connect() as c:c.execute('INSERT OR REPLACE INTO ss_allegro_defaults VALUES(?,?,?)',(self.api.env,self.api.account,json.dumps(data,ensure_ascii=False)))
    def link_existing(self,pid,offer_id,catalog_id):
        with self.lock:
            offer=self.api.offer(str(offer_id))
            product_set=offer.get('productSet') or []
            if len(product_set)!=1 or (product_set[0].get('product') or {}).get('id')!=catalog_id:
                raise ListingError('Wybrana oferta dotyczy innego produktu lub zestawu. Wybierz zgodny produkt z katalogu.')
            self.row(pid)
            with self.store.connect() as c:
                c.execute('BEGIN IMMEDIATE')
                other=c.execute('SELECT product_id FROM ss_allegro_listings WHERE env=? AND account=? AND offer_id=? AND product_id<>?',(self.api.env,self.api.account,str(offer_id),pid)).fetchone()
                if other:raise ListingError('Ta oferta jest już powiązana z innym produktem w magazynie.')
            changes={'offer_id':str(offer_id),'phase':(offer.get('publication') or {}).get('status','LINKED'),'operation':'','last_error':''}
            external=(offer.get('external') or {}).get('id')
            self.state(pid,**changes)
            if external:
                with self.store.connect() as c:c.execute('UPDATE ss_allegro_listings SET external_id=? WHERE env=? AND account=? AND product_id=?',(external,self.api.env,self.api.account,pid))
            if self.api.env=='production':
                import inventory_sync
                inventory_sync.link(self.store,self.api.account,str(offer_id),pid)
            self.record_price(pid,offer,self.store.get(pid)['sale_price'] or '')
            return self.check(pid)

    def recover(self,pid):
        r=self.row(pid)
        if r['offer_id']:return r
        found=self.api.find_external(r['external_id'])
        if len(found)>1:raise ListingError('Znaleziono kilka ofert o tym identyfikatorze. Uzgodnij je ręcznie, aby nie utworzyć duplikatu.')
        if found:self.state(pid,offer_id=str(found[0]['id']),phase='LINKED',last_error='')
        elif r['phase']=='REQUESTING':raise ListingError('Wynik poprzedniego tworzenia jest niepewny. Nie wysłano kolejnego POST. Sprawdź ofertę w Allegro i ponów „Sprawdź status” później.')
        return self.row(pid)
    def settle(self,pid,response):
        if response.status==202:
            path=self.api.operation_path(response.location)
            self.state(pid,operation=path,phase='PROCESSING')
            for _ in range(6):
                try:result=self.api.request(path)
                except ListingError as exc:
                    if exc.status==422:self.state(pid,operation='',phase='REJECTED')
                    raise
                if result.status==303 or result.data.get('operation',{}).get('status')=='COMPLETED':
                    self.state(pid,operation='',phase='LINKED');return
                self.wait(1)
            raise ListingError('Allegro nadal przetwarza operację. Użyj „Sprawdź status”; nie twórz nowej oferty.')
    def check(self,pid):
        r=self.recover(pid)
        if r['operation']:
            try:response=self.api.request(r['operation'])
            except ListingError as exc:
                if exc.status==422:self.state(pid,operation='',phase='REJECTED')
                raise
            if response.status!=303 and response.data.get('operation',{}).get('status')!='COMPLETED':return {'state':'PROCESSING','offer':r['offer_id']}
            self.state(pid,operation='',phase='LINKED')
        if not r['offer_id']:return {'state':'NOT_CREATED','external':r['external_id']}
        offer=self.api.offer(r['offer_id']);status=(offer.get('publication') or {}).get('status','UNKNOWN')
        self.state(pid,phase=status,last_error='')
        self.record_price(pid,offer)
        return {'state':status,'offer':r['offer_id'],'details':offer,'rules':self.api.rules(r['offer_id'])}
    def apply_rule(self,uid,choices):
        rule=choices.get('rule')
        if rule and Decimal(money(choices.get('minimum','')))>Decimal(money(choices.get('maximum',''))):raise ListingError('Minimum reguły przekracza maksimum.')
        existing=self.api.rules(uid)
        current=[x for x in existing if (x.get('marketplace') or {}).get('id')=='allegro-pl']
        if not rule and not current:return
        if rule:
            cfg={'priceRange':{'type':'MARKETPLACE_CURRENCY','minPrice':{'amount':money(choices['minimum']),'currency':'PLN'},'maxPrice':{'amount':money(choices['maximum']),'currency':'PLN'}}}
            modification={'set':[{'marketplace':{'id':'allegro-pl'},'rule':{'id':rule},'configuration':cfg}]}
        else:modification={'remove':[{'marketplace':{'id':'allegro-pl'}}]}
        command=str(uuid.uuid4())
        self.api.request('/sale/offer-price-automation-commands','POST',{'id':command,'modification':modification,'offerCriteria':[{'type':'CONTAINS_OFFERS','offers':[{'id':uid}]}]})
        for _ in range(8):
            tasks=self.api.get('/sale/offer-price-automation-commands/'+command+'/tasks').get('tasks',[])
            own=[t for t in tasks if (t.get('offer') or {}).get('id')==uid]
            if any(t.get('status')=='FAIL' for t in own):raise ListingError('Allegro odrzuciło regułę ceny: '+str(own[0].get('message') or own[0].get('errors') or 'Sprawdź regułę i zakres.'))
            if own and all(t.get('status')=='SUCCESS' for t in own):
                assigned=[x for x in self.api.rules(uid) if (x.get('marketplace') or {}).get('id')=='allegro-pl']
                def same_range(value):
                    try:
                        return value.get('type')==cfg['priceRange']['type'] and all(value[k]['currency']=='PLN' and money(value[k]['amount'])==cfg['priceRange'][k]['amount'] for k in ('minPrice','maxPrice'))
                    except (KeyError,TypeError,ListingError):return False
                if rule and not any((x.get('rule') or {}).get('id')==rule and same_range((x.get('configuration') or {}).get('priceRange') or {}) for x in assigned):raise ListingError('Nie potwierdzono reguły i zakresu ceny. Publikacja wstrzymana.')
                if not rule and assigned:raise ListingError('Nie potwierdzono wyłączenia reguły cenowej.')
                return
            self.wait(1)
        raise ListingError('Reguła ceny nadal jest przetwarzana. Sprawdź status przed publikacją.')
    def record_price(self,pid,offer,expected=None):
        price=(offer.get('sellingMode') or {}).get('price') or {}
        if price.get('currency')!='PLN':return False
        amount=money(price.get('amount',''));row=self.row(pid)
        original=self.store.get(pid)['sale_price'] or '';same=expected is not None and str(expected)==original
        for base in (row['last_price'],expected):
            if base is not None and str(base)!='':
                try:same=same or money(base)==money(original)
                except ListingError:pass
        changed=False
        with self.store.connect() as c:
            if same and original!=amount:
                changed=bool(c.execute("UPDATE products SET sale_price=? WHERE id=? AND coalesce(sale_price,'')=?",(amount,pid,original)).rowcount)
        self.state(pid,last_price=amount)
        return changed

    def image_urls(self,paths,ai,progress):
        urls=[]
        if not paths:raise ListingError('Dodaj co najmniej jedno zdjęcie produktu.')
        if len(paths)>16:raise ListingError('Wybierz maksymalnie 16 zdjęć oferty.')
        for i,path in enumerate(paths):
            progress(f'Zdjęcie {i+1}/{len(paths)}')
            with Image.open(path) as source:
                source.load();im=source.convert('RGBA')
                try:
                    im.thumbnail((2560,2560));base=Image.new('RGB',im.size,'white');base.paste(im,mask=im.getchannel('A'))
                    try:buffer=io.BytesIO();base.save(buffer,format='JPEG',quality=93)
                    finally:base.close()
                finally:im.close()
            urls.append(self.api.upload(buffer.getvalue(),ai))
        return urls
    def send(self,pid,payload,choices,paths,source_quantity,publish=False,progress=lambda text:None):
        with self.lock:
            try:
                self.api.verify_identity()
                if self.store.get(pid)['quantity']!=source_quantity:raise ListingError('Stan magazynu zmienił się w tle. Otwórz formularz ponownie przed wystawieniem.')
                with self.store.connect() as c:
                    if c.execute('SELECT 1 FROM inventory_archive WHERE product_id=?',(pid,)).fetchone():raise ListingError('Produkt jest w archiwum. Przywróć go przed wystawieniem.')
                row=self.recover(pid);uid=row['offer_id']
                if row['operation']:raise ListingError('Poprzednia operacja nadal jest przetwarzana. Kliknij „Sprawdź status”.')
                body=copy.deepcopy(payload)
                if body.get('sellingMode',{}).get('price',{}).get('currency')!='PLN':raise ListingError('Obsługiwane są ceny PLN.')
                money(body.get('sellingMode',{}).get('price',{}).get('amount',''))
                if len(body.get('productSet',[]))!=1:raise ListingError('Edytor wystawia pojedynczy produkt, nie zestaw wielu produktów.')
                if int(body.get('stock',{}).get('available',0))<1:raise ListingError('Ilość musi być dodatnia.')
                if int(body.get('stock',{}).get('available',0))>source_quantity:raise ListingError('Ilość w ofercie przekracza magazyn.')
                body['external']={'id':row['external_id']}
                body['publication']={'status':'INACTIVE','republish':False}
                if uid:
                    existing=self.api.offer(uid)
                    if (existing.get('sellingMode') or {}).get('price',{}).get('currency') not in (None,'PLN'):raise ListingError('Ten edytor obsługuje oferty PLN na allegro.pl.')
                    # Never turn an active offer into a draft as a side effect of saving edits.
                    body.pop('publication',None)
                    if not choices.get('update_stock'):body.pop('stock',None)
                    if not choices.get('rule'):self.apply_rule(uid,{})
                if not uid or choices.get('update_images'):
                    progress('Przesyłanie zdjęć')
                    if paths:body['images']=self.image_urls(paths,choices.get('ai_images',False),progress)
                    elif not body.get('images'):raise ListingError('Brak zdjęć w galerii lokalnej i katalogu Allegro.')
                    if len(body['images'])>16:raise ListingError('Maksymalnie 16 zdjęć oferty.')
                    if choices.get('ai_images'):body['aiCoCreatedContent']={'images':[{'url':u} for u in body['images']]}
                else:
                    body.pop('images',None);body.pop('aiCoCreatedContent',None)
                if not body['productSet'][0]['product'].get('id'):
                    images=body.get('images') or (existing.get('images') if uid else [])
                    if not images:raise ListingError('Nowy produkt katalogowy wymaga zdjęć.')
                    body['productSet'][0]['product']['images']=copy.deepcopy(images)
                if self.store.get(pid)['quantity']!=source_quantity:raise ListingError('Stan zmienił się podczas przesyłania zdjęć. Odśwież formularz.')
                progress('Zapis oferty w Allegro')
                if not uid:
                    self.state(pid,phase='REQUESTING')
                    try:response=self.api.request('/sale/product-offers','POST',body)
                    except ListingError as e:
                        if e.status in (400,401,403,404,422,429):self.state(pid,phase='REJECTED')
                        raise
                    uid=str(response.data.get('id') or (response.data.get('offer') or {}).get('id') or '')
                    if not uid and response.location:
                        path=self.api.operation_path(response.location);uid=path.split('/')[3]
                    if not re.fullmatch(r'\d+',uid):raise ListingError('Brak potwierdzonego numeru oferty. Sprawdź status przed ponowieniem.')
                    self.state(pid,offer_id=uid,phase='LINKED')
                else:response=self.api.request('/sale/product-offers/'+uid,'PATCH',body)
                self.settle(pid,response)
                progress('Ustawianie reguły cenowej')
                self.apply_rule(uid,choices)
                if publish:
                    if self.store.get(pid)['quantity']!=source_quantity:raise ListingError('Stan zmienił się przed publikacją. Szkic pozostał w Allegro; odśwież formularz.')
                    progress('Publikacja oferty')
                    response=self.api.request('/sale/product-offers/'+uid,'PATCH',{'publication':{'status':'ACTIVE','republish':False}})
                    self.settle(pid,response)
                result=self.check(pid)
                if self.api.env=='production':
                    import inventory_sync
                    inventory_sync.link(self.store,self.api.account,uid,pid)
                if result.get('details'):self.record_price(pid,result['details'],choices.get('_original_price') or '')
                return result
            except Exception as exc:
                self.state(pid,last_error=str(exc)[:3000]);raise


def refresh_linked_prices(store,api):
    from urllib.parse import urlencode
    service=ListingService(store,api)
    with store.connect() as c:
        rows=[dict(r) for r in c.execute("SELECT product_id,offer_id FROM ss_allegro_listings WHERE env=? AND account=? AND offer_id<>''",(api.env,api.account))]
    with service.lock:
        changed=0
        for start in range(0,len(rows),25):
            page=rows[start:start+25]
            params=[('offer.id',r['offer_id']) for r in page]+[('limit','100')]
            offers=api.get('/sale/offers?'+urlencode(params)).get('offers',[])
            ids={r['offer_id']:r['product_id'] for r in page}
            for offer in offers:
                if str(offer['id']) in ids:changed+=service.record_price(ids[str(offer['id'])],offer)
        return changed
