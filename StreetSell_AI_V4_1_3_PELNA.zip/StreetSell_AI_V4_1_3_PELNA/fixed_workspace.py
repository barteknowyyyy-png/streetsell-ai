"""Fixed desktop workspace: wheel input never moves a whole tree of CTk widgets."""
import threading
import tkinter as tk
from tkinter import ttk
import customtkinter as ctk

BG='#0b0e13';PANEL='#141820';FIELD='#1b202a';BORDER='#272e3a';TEXT='#f4f6fa';MUTED='#96a0b1';RED='#f3344e'

class FixedPage(ctk.CTkFrame):
    """Compatible page host with no canvas window, layout timers or wheel hooks."""
    def __init__(self,parent,root,**kwargs):
        super().__init__(parent,fg_color='transparent',**kwargs)
        self.content=ctk.CTkFrame(self,fg_color='transparent')
        self.content.pack(fill='both',expand=True)
    def schedule(self,*args):pass
    def top(self):pass
    def reveal(self,widget):widget.focus_set()


def textfield(app,parent,lines=4,expand=True):
    # Native Text handles long content internally, without growing the parent.
    holder=tk.Frame(parent,bg=FIELD,highlightbackground=BORDER,highlightthickness=1)
    holder.pack(fill='both' if expand else 'x',expand=expand,pady=(3,7))
    box=tk.Text(holder,bg=FIELD,fg=TEXT,insertbackground=TEXT,relief='flat',borderwidth=0,
        font=('Segoe UI',12),wrap='word',undo=True,height=lines,width=12,padx=9,pady=6,selectbackground='#522432')
    scroll=ttk.Scrollbar(holder,command=box.yview);scroll.pack(side='right',fill='y')
    box.configure(yscrollcommand=scroll.set);box.pack(side='left',fill='both',expand=True)
    box.bind('<<Modified>>',app.text_modified)
    return box


def build_product(app,parent):
    # Import after modern_ui finishes defining App; this module has no circular imports.
    from modern_ui import Label,Button,Tabs,ModernGallery
    app.editor_parent=parent
    app.editor_content=ctk.CTkFrame(parent,fg_color='transparent')
    app.empty_editor=ctk.CTkFrame(parent,fg_color='transparent')
    Label(app.empty_editor,text='Wybierz produkt w magazynie',text_color=MUTED).pack(pady=35)
    header=ctk.CTkFrame(app.editor_content,fg_color='transparent');header.pack(fill='x',pady=(0,5))
    app.product_label=Label(header,text='')
    app.identifiers=Label(header,text='',text_color=MUTED,font=ctk.CTkFont(size=13));app.identifiers.pack(side='left')
    app.save_label=Label(header,text='',text_color=RED);app.save_label.pack(side='right')
    footer=ctk.CTkFrame(app.editor_content,fg_color='transparent');footer.pack(side='bottom',fill='x',pady=(5,0))
    app.analyze_button=Button(footer,'Analizuj AI',app.analyze_selected,width=125);app.analyze_button.pack(side='left')
    Button(footer,'Opis',lambda:app.editor_tabs.select(0),width=75).pack(side='left',padx=5)
    Button(footer,'Zdjęcia',lambda:app.editor_tabs.select(3),width=80).pack(side='left')
    Button(footer,'Wystaw Allegro',app.open_allegro_offer,primary=True,width=140).pack(side='left',padx=5)
    Button(footer,'Zatwierdź ofertę',app.approve,primary=True,width=145).pack(side='right')
    Button(footer,'Zapisz szkic',app.save_draft,width=120).pack(side='right',padx=6)
    app.editor_tabs=Tabs(app.editor_content,height=280,command=app.card_tab_changed)
    app.editor_tabs.pack(fill='both',expand=True)
    offer=app.editor_tabs.add('Opis oferty');details=app.editor_tabs.add('Dane produktu')
    sources=app.editor_tabs.add('Źródła AI');photos=app.editor_tabs.add('Zdjęcia')
    Label(offer,text='Tytuł oferty',text_color=MUTED,anchor='w').pack(fill='x')
    app.title_box=textfield(app,offer,2,False);app.title_box.bind('<KeyRelease>',lambda e:app.update_title_count(),add='+')
    tools=ctk.CTkFrame(offer,fg_color='transparent');tools.pack(fill='x',pady=2)
    app.title_count=Label(tools,text='0 znaków',text_color=MUTED);app.title_count.pack(side='left')
    for name,callback in [('Kopiuj tytuł',lambda:app.copy_text(app.title_box)),('Kopiuj opis',lambda:app.copy_text(app.description_box))]:
        b=Button(tools,name,callback,width=115);b.configure(height=28);b.pack(side='right',padx=3)
    Label(offer,text='Opis produktu',text_color=MUTED,anchor='w').pack(fill='x')
    app.description_box=textfield(app,offer,5,True)
    # Split long detail forms into two native notebook pages; no nested page scrolling.
    notebook=ttk.Notebook(details);notebook.pack(fill='both',expand=True)
    pricing=ctk.CTkFrame(notebook,fg_color=PANEL);contents=ctk.CTkFrame(notebook,fg_color=PANEL)
    notebook.add(pricing,text='Cena i stan');notebook.add(contents,text='Zawartość i wady')
    app.vars={}
    app.price_display=Label(pricing,text='Ustal cenę',font=ctk.CTkFont(size=25,weight='bold'),anchor='w');app.price_display.pack(fill='x',pady=6)
    app.pricing_fields(pricing);app.vars['sale_price'].trace_add('write',lambda *_:app.update_price_display())
    Label(contents,text='Zawartość zestawu',text_color=MUTED,anchor='w').pack(fill='x')
    app.contents_box=textfield(app,contents,3,True)
    Label(contents,text='Braki i wady',text_color=MUTED,anchor='w').pack(fill='x')
    app.defects_box=textfield(app,contents,3,True)
    for key,title in (('asin','ASIN produktu'),('product_link','Link do produktu (HTTPS)')):
        Label(sources,text=title,text_color=MUTED,anchor='w').pack(fill='x')
        var=tk.StringVar();app.vars[key]=var;var.trace_add('write',app.mark_dirty)
        ctk.CTkEntry(sources,textvariable=var,fg_color=FIELD,border_color=BORDER,height=32).pack(fill='x',pady=(2,5))
    Label(sources,text='Notatki i dopasowanie produktu',text_color=MUTED,anchor='w').pack(fill='x')
    app.notes_box=textfield(app,sources,4,True)

    class CompactGallery(ModernGallery):
        def __init__(self,parent,app):
            ttk.Frame.__init__(self,parent)
            self.app=app;self.gallery=app.gallery;self.product_id=None;self.selected_photo=None
            self.rows=[];self.images=[];self.preview_source=None;self.preview_image=None;self.resize_job=None;self.cancel=threading.Event()
            self._requested=None;self._needs_load=False
            self.header=Label(self,text='Galeria produktu',text_color=TEXT);self.header.pack(anchor='w')
            body=ctk.CTkFrame(self,fg_color='transparent');body.pack(fill='both',expand=True)
            actions=ctk.CTkFrame(body,fg_color='transparent',width=290);actions.pack(side='right',fill='y',padx=(10,0))
            rail=tk.Frame(body,bg=PANEL);rail.pack(side='left',fill='y',padx=(0,8))
            self.strip=tk.Canvas(rail,bg=PANEL,highlightthickness=0,height=160,width=86)
            self.strip.pack(side='left',fill='y')
            scroll=ttk.Scrollbar(rail,command=self.strip.yview);scroll.pack(side='right',fill='y');self.strip.configure(yscrollcommand=scroll.set)
            self.strip.bind('<MouseWheel>',lambda e:self._scroll_strip(e))
            self.strip.bind('<Button-4>',lambda e:self._scroll_strip(e));self.strip.bind('<Button-5>',lambda e:self._scroll_strip(e))
            self.preview_canvas=tk.Canvas(body,bg='white',height=160,width=220,highlightthickness=0)
            self.preview_canvas.pack(fill='both',expand=True)
            # A fixed viewport needs no aspect-dependent geometry feedback loop.
            self.preview_canvas.bind('<Configure>',self.schedule_preview)
            self.preview_canvas.bind('<Double-Button-1>',self.full_preview)
            self.caption=Label(actions,text='Dodaj zdjęcia produktu',text_color=MUTED,wraplength=270);self.caption.pack(fill='x',pady=(0,4))
            self.zoom_button=Button(actions,'Powiększ zdjęcie',self.full_preview,width=270);self.zoom_button.configure(height=28);self.zoom_button.pack(fill='x',pady=3)
            mutations=ctk.CTkFrame(actions,fg_color='transparent');mutations.pack(fill='x',pady=3);self.buttons={}
            for title,action in (('Główne','main'),('<','left'),('>','right'),('Usuń','remove')):
                b=Button(mutations,title,lambda a=action:self.mutate(a),width=55,font=ctk.CTkFont(size=13));b.configure(height=28);b.pack(side='left',padx=2);self.buttons[action]=b
            grid=ctk.CTkFrame(actions,fg_color='transparent');grid.pack(fill='x')
            specs=[('add_button','Dodaj zdjęcia',self.add),('online_button','Z internetu',self.open_internet),
             ('prepare_button','Białe tło',self.open_editor),('export_button','Eksportuj',self.export),
             ('source_button','Źródło',self.open_source),('translate_button','Napisy → PL',self.open_localize),
             ('original_button','Oryginał',self.open_original)]
            for i,(attr,label,fn) in enumerate(specs):
                b=Button(grid,label,fn,width=130,font=ctk.CTkFont(size=13));b.configure(height=30);b.grid(row=i//2,column=i%2,padx=2,pady=3,sticky='ew');setattr(self,attr,b)
            self.info=Label(actions,text='Zmiany zdjęć zapisują się od razu.',text_color=MUTED,wraplength=270,font=ctk.CTkFont(size=12));self.info.pack(fill='x',pady=3)
            self.import_cancel=Button(actions,'Anuluj import',self.cancel.set,width=260)
            self.bind('<Map>',lambda e:self.ensure_loaded() if e.widget is self else None,add='+')
        def _scroll_strip(self,event):
            number=getattr(event,'num',None)
            steps=-3 if number==4 else (3 if number==5 else (-3 if event.delta>0 else 3))
            self.strip.yview_scroll(steps,'units');return 'break'
        def set_product(self,product_id):
            self._requested=product_id;self._needs_load=True
            if self.winfo_ismapped():self.ensure_loaded()
        def ensure_loaded(self):
            if self._needs_load:
                self._needs_load=False;super().set_product(self._requested)

    app.photo_pane=CompactGallery(photos,app);app.photo_pane.pack(fill='both',expand=True)
    app.set_editor_visible(False)
