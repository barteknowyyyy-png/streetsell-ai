"""Szacunkowa łączna wartość PLN, publiczne kursy NBP bez danych kupujących."""
import json
import re
import urllib.request
import urllib.error
import ssl
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from datetime import date,datetime,timezone
from decimal import Decimal,ROUND_HALF_UP
from allegro_api import NoRedirect
from daily_sales import DailySnapshot,DailyCosts,ZERO,today_bounds

def nbp_https_handler():
    """System roots plus Mozilla roots; hostname and chain checks stay enabled."""
    context = ssl.create_default_context()
    try:
        import certifi
    except ImportError:
        pass  # System trust remains usable before the launcher installs certifi.
    else:
        context.load_verify_locations(cafile=certifi.where())
    return urllib.request.HTTPSHandler(context=context)

class RateError(Exception):pass

@dataclass
class RateBook:
    rates:dict
    date:str=''
    number:str=''
    cached:bool=False
    source:str="NBP API"
    checked_at:str=""

def validate_table(payload,now):
    try:
        table=payload[0]
        if table.get('table')!='A':raise ValueError()
        published=date.fromisoformat(table['effectiveDate']);today=date.fromisoformat(today_bounds(now)[0])
        if not 0<=(today-published).days<=7:raise ValueError()
        rates={'PLN':Decimal('1')}
        for item in table['rates']:
            code=item['code'];rate=Decimal(str(item['mid']))
            if not re.fullmatch('[A-Z]{3}',code) or not rate.is_finite() or not 0<rate<=100000:raise ValueError()
            rates[code]=rate
        return RateBook(rates,published.isoformat(),str(table['no']),source=str(table.get('source') or 'NBP API'))
    except (KeyError,ValueError,TypeError,IndexError,ArithmeticError,AttributeError):raise RateError('Nieprawidłowa lub zbyt stara tabela kursów NBP. Odśwież statystyki.') from None

class ExchangeRates:
    def __init__(self,store,fetcher=None):
        self.store=store;self.fetcher=fetcher or self.download;self.fallback=self.download_xml if fetcher is None else None
        with store.connect() as con:
            con.execute('CREATE TABLE IF NOT EXISTS nbp_rate_cache (id INTEGER PRIMARY KEY CHECK(id=1),payload TEXT NOT NULL)')
    @staticmethod
    def download():
        request=urllib.request.Request('https://api.nbp.pl/api/exchangerates/tables/A/?format=json',headers={'Accept':'application/json','User-Agent':'StreetSellAI/3.6.3'})
        opener=urllib.request.build_opener(NoRedirect(), nbp_https_handler())
        with opener.open(request,timeout=12) as response:
            body=response.read(200001)
        if len(body)>200000:raise RateError('Odpowiedź NBP jest zbyt duża.')
        return json.loads(body,parse_float=Decimal)
    @staticmethod
    def download_xml():
        request=urllib.request.Request('https://static.nbp.pl/dane/kursy/xml/LastA.xml',headers={'User-Agent':'StreetSellAI/3.6.3','Accept':'text/xml, application/xml;q=0.9, */*;q=0.8'})
        with urllib.request.build_opener(NoRedirect(), nbp_https_handler()).open(request,timeout=12) as response:body=response.read(200001)
        if len(body)>200000 or b'<!DOCTYPE' in body.upper() or b'<!ENTITY' in body.upper():raise RateError('Nieprawidłowy plik XML NBP.')
        root=ET.fromstring(body)
        if root.tag!='tabela_kursow' or root.get('typ')!='A':raise RateError('Nieprawidłowa tabela XML NBP.')
        rates=[]
        for item in root.findall('pozycja'):
            unit=Decimal(item.findtext('przelicznik','').replace(',','.'))
            rate=Decimal(item.findtext('kurs_sredni','').replace(',','.'))
            if not unit.is_finite() or unit<=0:raise RateError('Nieprawidłowy przelicznik XML NBP.')
            rates.append({'code':item.findtext('kod_waluty',''),'mid':str(rate/unit)})
        return [{'table':'A','no':root.findtext('numer_tabeli'),'effectiveDate':root.findtext('data_publikacji'),'rates':rates,'source':'NBP XML'}]
    def fetch(self,currencies,now=None):
        now=now or datetime.now(timezone.utc);needed=set(currencies)-{'PLN'}
        if not needed:return RateBook({'PLN':Decimal('1')})
        failures=[]
        for label,fetch in (('API',self.fetcher),('XML',self.fallback)):
            if fetch is None:continue
            try:
                payload=fetch();book=validate_table(payload,now)
                missing=needed-set(book.rates)
                if missing:raise RateError('Brak kursu dla: '+', '.join(sorted(missing)))
                with self.store.connect() as con:con.execute('INSERT OR REPLACE INTO nbp_rate_cache VALUES(1,?)',(json.dumps(payload,default=str),))
                book.checked_at=now.isoformat();return book
            except Exception as exc:failures.append(label+': '+rate_problem(exc))
        for table_name in ('nbp_rate_cache',):
            with self.store.connect() as con:row=con.execute('SELECT payload FROM '+table_name+' WHERE id=1').fetchone()
            if row:
                try:
                    book=validate_table(json.loads(row['payload']),now)
                    if not needed-set(book.rates):book.cached=True;book.checked_at=now.isoformat();return book
                except (RateError,ValueError,TypeError):pass
        raise RateError('Nie pobrano kursów '+', '.join(sorted(needed))+'. '+'; '.join(failures)+'. Ponowię automatycznie za minutę.') from None

def rate_problem(exc):
    if isinstance(exc,RateError):return str(exc)
    if isinstance(exc,urllib.error.HTTPError):return 'HTTP '+str(exc.code)
    reason=getattr(exc,'reason',exc)
    if isinstance(reason,ssl.SSLCertVerificationError):
        code=getattr(reason,'verify_code',None)
        if code in (9,10):return 'certyfikat poza okresem ważności — sprawdź datę i godzinę Windows'
        if code in (18,19,20,21):return 'niezaufany wystawca certyfikatu — uruchom run.bat, aby zaktualizować certyfikaty; sprawdź ochronę HTTPS antywirusa'
        return 'nie można zweryfikować certyfikatu HTTPS — sprawdź datę Windows i ochronę HTTPS antywirusa'
    if isinstance(reason,ssl.SSLError):return 'błąd bezpiecznego połączenia HTTPS — sprawdź ustawienia sieci i ochronę HTTPS antywirusa'
    if isinstance(reason,(TimeoutError,ConnectionError)):return 'przekroczono czas połączenia'
    if isinstance(exc,(ValueError,ET.ParseError,ArithmeticError)):return 'nieprawidłowy format odpowiedzi'
    return 'nie udało się połączyć z NBP'

def converted(value,currency,book):
    if currency=='PLN':return value
    if book is None or currency not in book.rates:raise RateError('Brak kursu '+currency+'. Odśwież statystyki.')
    return value*book.rates[currency]

def combined_snapshot(snapshot,book):
    groups=snapshot.by_currency or {snapshot.currency:snapshot}
    total=ZERO;cod=ZERO;lines=[]
    for currency,group in groups.items():
        total+=converted(group.value,currency,book).quantize(Decimal('.01'),rounding=ROUND_HALF_UP)
        cod+=converted(group.cod,currency,book).quantize(Decimal('.01'),rounding=ROUND_HALF_UP)
        for line in group.lines:
            entry=dict(line);entry['total']=str(converted(Decimal(line['total']),currency,book).quantize(Decimal('.01'),rounding=ROUND_HALF_UP))
            entry['source_currency']=currency;entry['source_total']=line['total'];entry['currency']='PLN';lines.append(entry)
    return DailySnapshot(snapshot.day,snapshot.account,snapshot.login,snapshot.units,snapshot.orders,total,cod,snapshot.fetched_at,lines)

class CombinedCosts(DailyCosts):
    def __init__(self,store):
        super().__init__(store)
        with store.connect() as con:con.execute("CREATE TABLE IF NOT EXISTS daily_combined_costs (account TEXT NOT NULL,day TEXT NOT NULL,goods TEXT NOT NULL,fees TEXT NOT NULL,other TEXT NOT NULL,basis TEXT NOT NULL,PRIMARY KEY(account,day))")
    def _row(self,account,day,currency):
        with self.store.connect() as con:return con.execute('SELECT goods,fees,other,basis FROM daily_combined_costs WHERE account=? AND day=?',(account,day)).fetchone()
    def save(self,account,day,goods,fees,other,snapshot=None,currency=None):
        from daily_sales import money
        values=tuple(money(v) for v in (goods,fees,other))
        with self.store.connect() as con:con.execute('INSERT OR REPLACE INTO daily_combined_costs VALUES(?,?,?,?,?,?)',(account,day,*(str(v) for v in values),self.signature(snapshot) if snapshot else ''))
        return values

def combined_profit(snapshot,book,costs,total_costs):
    result=total_costs.profit(combined_snapshot(snapshot,book))
    if result is not None:return result
    total=ZERO
    for currency,group in (snapshot.by_currency or {snapshot.currency:snapshot}).items():
        profit=costs.profit(group)
        if profit is None:return None
        total+=converted(profit,currency,book)
    return total.quantize(Decimal('.01'),rounding=ROUND_HALF_UP)
