import unittest,tempfile
from pathlib import Path
from types import SimpleNamespace as NS
from legacy import init_db
from storage import Store
import inventory_sync as inv

class SharedTests(unittest.TestCase):
 def test_all_orders_but_separate_stock_with_same_sku(self):
  with tempfile.TemporaryDirectory() as tmp:
   stores=[]
   for who in ['first','second']:
    path=Path(tmp)/(who+'.db');init_db(path);s=Store(path);s.migrate()
    with s.connect() as c:c.execute("INSERT INTO products(id,product_name,quantity,sku) VALUES(1,?,5,'SAME-SKU')",(who,))
    inv.reconcile(s,NS(account='shared',orders=[]));stores.append(s)
   inv.link(stores[0],'shared','111',1);inv.link(stores[1],'shared','222',1)
   snapshot=NS(account='shared',orders=[{'status':'READY_FOR_PROCESSING','lines':[{'id':'a','quantity':1,'offer_id':'111','external_id':'SAME-SKU'},{'id':'b','quantity':2,'offer_id':'222','external_id':'SAME-SKU'},{'id':'c','quantity':1,'offer_id':'333','external_id':'SAME-SKU'}]}])
   self.assertEqual(inv.reconcile(stores[0],snapshot),(1,False));self.assertEqual(inv.reconcile(stores[1],snapshot),(2,False))
   self.assertEqual(stores[0].get(1)['quantity'],4);self.assertEqual(stores[1].get(1)['quantity'],3)
   for s in stores:
    self.assertEqual(inv.reconcile(s,snapshot),(0,False))
    with s.connect() as c:
     self.assertEqual(c.execute('select count(*) from inventory_order_lines').fetchone()[0],3)
     self.assertIsNone(c.execute("select product_id from inventory_order_lines where offer_id='333'").fetchone()[0])

if __name__=='__main__':unittest.main(verbosity=2)
