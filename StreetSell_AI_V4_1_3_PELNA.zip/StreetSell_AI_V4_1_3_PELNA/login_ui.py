"""Owner login before constructing the inventory or starting Allegro sync."""
import queue,threading
import tkinter as tk
from tkinter import messagebox
from tkinter import font as tkfont
from pathlib import Path
import customtkinter as ctk
from PIL import Image
from owner_auth import OwnerAuth,AuthError
from owner_session import OwnerSession,SessionError

BG='#0b0e13';PANEL='#171b24';FIELD='#222733';TEXT='#f5f5f7';MUTED='#a0a6b4';RED='#f3344e'
class LoginWindow(ctk.CTk):
    def __init__(self,auth,session=None):
        super().__init__();ctk.set_appearance_mode('dark');self.auth=auth;self.session=session or OwnerSession(auth);self.remember_var=tk.BooleanVar(self,value=False);self.result=None;self.busy=False;self.events=queue.Queue();self.mode='login' if auth.exists() else 'create'
        ctk.DrawEngine.preferred_drawing_method='polygon_shapes'
        available={name.casefold():name for name in tkfont.families(self)}
        family=next((available[n.casefold()] for n in ('Segoe UI','DejaVu Sans','Nimbus Sans','Helvetica') if n.casefold() in available),'Arial')
        ctk.ThemeManager.theme['CTkFont']['family']=family;ctk.ThemeManager.theme['CTkFont']['size']=15
        self.title('StreetSell AI • Właściciel');self.geometry('600x800');self.minsize(520,740);self.configure(fg_color=BG)
        self.panel=ctk.CTkFrame(self,fg_color=PANEL,corner_radius=28,width=440);self.panel.pack(expand=True,fill='x',padx=55,pady=28)
        self.draw();self.after(50,self.poll)
    def destroy(self):
        for ident in self.tk.call('after','info'):
            self.tk.call('after','cancel',ident)
        super().destroy()
    def draw(self):
        for w in self.panel.winfo_children():w.destroy()
        p=self.panel
        try:
            with Image.open(Path(__file__).with_name('brand_ss.png')) as im:self.logo=ctk.CTkImage(im.copy(),size=(76,76))
            ctk.CTkLabel(p,text='',image=self.logo).pack(pady=(28,10))
        except OSError:ctk.CTkLabel(p,text='SS',text_color=RED,font=ctk.CTkFont(size=44,weight='bold')).pack(pady=25)
        title={'create':'Twoja przestrzeń sprzedaży','login':'Witaj ponownie','recover':'Odzyskaj dostęp'}[self.mode]
        ctk.CTkLabel(p,text=title,font=ctk.CTkFont(size=24,weight='bold')).pack(padx=20,pady=5)
        ctk.CTkLabel(p,text='STREETSELL AI  /  WŁAŚCICIEL',text_color=MUTED,font=ctk.CTkFont(size=12)).pack(pady=(0,20))
        self.fields={}
        names=[('login','Login właściciela',False),('secret','Kod odzyskiwania' if self.mode=='recover' else 'Hasło',True)]
        if self.mode in ('create','recover'):names += [('new','Nowe hasło' if self.mode=='recover' else 'Powtórz hasło',True)]
        for key,label,hidden in names:
            ctk.CTkLabel(p,text=label,text_color=MUTED,anchor='w').pack(fill='x',padx=28)
            e=ctk.CTkEntry(p,height=46,corner_radius=12,fg_color=FIELD,border_width=0,show='•' if hidden else '')
            e.pack(fill='x',padx=28,pady=(3,12));e.bind('<Return>',lambda e:self.submit());self.fields[key]=e
        if self.mode in ('login','create'):
            ctk.CTkCheckBox(p,text='Zapamiętaj mnie przez 30 dni',variable=self.remember_var,fg_color=RED,hover_color='#d9233d',font=ctk.CTkFont(size=14)).pack(anchor='w',padx=28,pady=(3,8))
        self.hint=ctk.CTkLabel(p,text='Ustal własny login i hasło (minimum 10 znaków).' if self.mode=='create' else '',text_color=MUTED,wraplength=360,justify='left');self.hint.pack(fill='x',padx=28,pady=5)
        self.button=ctk.CTkButton(p,text={'login':'Zaloguj się','create':'Utwórz konto właściciela','recover':'Ustaw nowe hasło'}[self.mode],height=48,corner_radius=14,fg_color=RED,hover_color='#d9233d',command=self.submit);self.button.pack(fill='x',padx=28,pady=12)
        if self.auth.exists():ctk.CTkButton(p,text='Wróć do logowania' if self.mode=='recover' else 'Nie pamiętam hasła',fg_color='transparent',text_color=MUTED,command=self.toggle).pack(pady=(0,10))
        ctk.CTkLabel(p,text='Konto na tym komputerze.\nHasło niezależne od Allegro.',text_color=MUTED,font=ctk.CTkFont(size=12)).pack(pady=(10,24))
    def toggle(self):
        if self.busy:return
        self.mode='login' if self.mode=='recover' else 'recover';self.draw()
    def submit(self):
        if self.busy:return
        values={k:e.get() for k,e in self.fields.items()}
        if self.mode=='create' and values['secret']!=values['new']:
            self.hint.configure(text='Hasła muszą być identyczne.',text_color=RED);return
        self.busy=True;self.button.configure(state='disabled');self.hint.configure(text='Chwilę…',text_color=MUTED)
        mode=self.mode;remember=bool(self.remember_var.get()) and mode!='recover'
        def work():
            try:
                if mode=='create':code=self.auth.create(values['login'],values['secret']);result=('code',code,values['login'].strip())
                elif mode=='recover':code=self.auth.verify(values['login'],values['secret'],True,values['new']);result=('code',code,values['login'].strip())
                else:
                    login=self.auth.verify(values['login'],values['secret'])
                    if remember:self.session.remember()
                    else:self.session.forget()
                    result=('ok',login)
            except (AuthError,SessionError) as exc:result=('error',str(exc))
            except Exception:result=('error','Nie udało się zapisać lub sprawdzić konta. Sprawdź dostęp do folderu aplikacji.')
            self.events.put(result)
        threading.Thread(target=work,daemon=True).start()
    def poll(self):
        try:result=self.events.get_nowait()
        except queue.Empty:self.after(50,self.poll);return
        self.busy=False
        if result[0]=='error':self.button.configure(state='normal');self.hint.configure(text=result[1],text_color=RED)
        elif result[0]=='ok':self.result=result[1];self.destroy();return
        else:
            self.show_code(result[1],result[2])
        self.after(50,self.poll)
    def show_code(self,code,login):
        for w in self.panel.winfo_children():w.destroy()
        ctk.CTkLabel(self.panel,text='Zapisz kod odzyskiwania',font=ctk.CTkFont(size=24,weight='bold')).pack(pady=(32,18))
        ctk.CTkLabel(self.panel,text='Pozwoli ustawić nowe hasło.\nZachowaj go poza aplikacją.\nPoprzedni kod przestaje działać.',text_color=MUTED).pack(padx=25,pady=10)
        entry=ctk.CTkEntry(self.panel,width=360,height=48);entry.pack(padx=25,pady=15);entry.insert(0,code);entry.configure(state='readonly')
        def copy():self.clipboard_clear();self.clipboard_append(code)
        ctk.CTkButton(self.panel,text='Kopiuj kod',command=copy,fg_color=FIELD).pack(pady=8)
        def done():
            if self.mode=='create' and self.remember_var.get():
                try:self.session.remember()
                except SessionError as exc:
                    messagebox.showinfo('Zapamiętaj mnie',str(exc)+' Zalogowano tylko na teraz.',parent=self)
            self.result=login;self.destroy()
        ctk.CTkButton(self.panel,text='Zapisałem kod — przejdź do aplikacji',command=done,fg_color=RED,height=48).pack(padx=25,pady=(15,32))

def authenticate(path,session=None,allow_resume=True):
    auth=OwnerAuth(path);session=session or OwnerSession(auth)
    owner=session.resume() if allow_resume else None
    if owner:return owner
    window=LoginWindow(auth,session);window.mainloop();return window.result

def run():
    import legacy
    auth=OwnerAuth(legacy.APP_DIR/'owner_auth.json');session=OwnerSession(auth);allow_resume=True
    while True:
        owner=authenticate(auth.path,session,allow_resume=allow_resume)
        if not owner:return
        from modern_ui import App
        app=App();app.owner_login=owner;app.owner_session=session;app.owner_label.configure(text=owner+' · Właściciel');app.mainloop()
        if not getattr(app,'logout_requested',False):return
        allow_resume=False
