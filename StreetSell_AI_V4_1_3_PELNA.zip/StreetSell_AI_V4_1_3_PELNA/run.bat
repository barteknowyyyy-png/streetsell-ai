@echo off
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
 echo Najpierw uruchom install.bat.
 pause
 exit /b 1
)
.venv\Scripts\python.exe -c "from PIL import Image, ImageTk, ImageOps, __version__; assert tuple(int(v) for v in __version__.split('.')[:2]) >= (10,4)" >nul 2>&1
if errorlevel 1 (
 echo Pierwsze uruchomienie modulu zdjec: instalowanie Pillow. Wymagany internet.
 .venv\Scripts\python.exe -m pip install "Pillow>=10.4,<14"
 if errorlevel 1 (
  echo Instalacja Pillow nie powiodla sie. Sprawdz internet i uruchom run.bat ponownie.
  pause
  exit /b 1
 )
)
.venv\Scripts\python.exe -c "import customtkinter; from zoneinfo import ZoneInfo; ZoneInfo('Europe/Warsaw')" >nul 2>&1
if errorlevel 1 (
 echo Pierwsze uruchomienie nowego wygladu: instalowanie interfejsu. Wymagany internet.
 .venv\Scripts\python.exe -m pip install "customtkinter==5.2.2" "tzdata>=2025.1"
 if errorlevel 1 (
  echo Instalacja interfejsu nie powiodla sie. Sprawdz internet i uruchom run.bat ponownie.
  pause
  exit /b 1
 )
)
if not exist .venv\streetsell_tls_363.ok (
 echo Aktualizacja certyfikatow HTTPS do kursow NBP. Wymagany internet.
 .venv\Scripts\python.exe -m pip install --upgrade "certifi>=2026.1.4"
 if errorlevel 1 (
  echo Aktualizacja certyfikatow nie powiodla sie. Sprawdz date Windows i polaczenie z internetem.
  echo Aplikacja sprobuje uzyc obecnych certyfikatow.
 ) else (
  type nul > .venv\streetsell_tls_363.ok
 )
)
.venv\Scripts\python.exe app.py
if errorlevel 1 pause
