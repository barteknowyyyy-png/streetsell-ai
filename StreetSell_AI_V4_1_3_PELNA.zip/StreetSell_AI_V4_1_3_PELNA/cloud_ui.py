"""Black/red Supabase login and cloud controls for the existing desktop UI."""
import json
import queue
import threading
from pathlib import Path
import tkinter as tk
from tkinter import messagebox
import customtkinter as ctk
from cloud_api import Supabase,CloudError,load_config
from cloud_sync import Sync,backup_database

ROOT=Path(__file__).resolve().parent
RED='#f3344e';BG='#0b0e13';PANEL='#171b24'

class Login(ctk.CTk):
    def __init__(self):
        super().__init__();ctk.set_appearance_mode('dark');self.configure(fg_color=BG)
        from branding import apply_icon
        apply_icon(self)
        self.title('StreetSell AI V4.1.3');self.geometry('610x740');self.result=None;self.busy=False;self.queue=queue.Queue()
        config=load_config(ROOT/'supabase_config.json')
        panel=ctk.CTkFrame(self,fg_color=PANEL);panel.pack(fill='both',expand=True,padx=35,pady=30)
        from PIL import Image
        heading=ctk.CTkFrame(panel,fg_color='transparent');heading.pack(pady=(15,4))
        with Image.open(ROOT/'brand_ss.png') as source:
            self.brand_image=ctk.CTkImage(light_image=source.copy(),dark_image=source.copy(),size=(52,52))
        ctk.CTkLabel(heading,text='',image=self.brand_image).pack(side='left',padx=(0,12))
        ctk.CTkLabel(heading,text='STREETSELL AI',text_color=RED,font=ctk.CTkFont(size=28,weight='bold')).pack(side='left')
        ctk.CTkLabel(panel,text='Własny magazyn • wspólne Allegro').pack(pady=10)
        self.entries={}
        for key,label,secret,value in [('url','Adres projektu Supabase',False,config.get('url','')),('publishable_key','Klucz publishable / anon',True,config.get('publishable_key','')),('email','E-mail konta Supabase',False,''),('password','Hasło',True,'')]:
            ctk.CTkLabel(panel,text=label,anchor='w').pack(fill='x',padx=25,pady=(8,0))
            e=ctk.CTkEntry(panel,height=42,show='•' if secret else '');e.pack(fill='x',padx=25,pady=5);e.insert(0,value);self.entries[key]=e
        self.remember=tk.BooleanVar(value=False)
        ctk.CTkCheckBox(panel,text='Zapamiętaj sesję w magazynie Windows',variable=self.remember,fg_color=RED).pack(padx=25,pady=15)
        self.hint=ctk.CTkLabel(panel,text='Użyj konta utworzonego w Supabase Auth.\nKażdy właściciel ma własne palety. Konto Allegro jest wspólne.',wraplength=470);self.hint.pack(padx=25,pady=10)
        self.button=ctk.CTkButton(panel,text='Zaloguj się',fg_color=RED,height=44,command=self.submit);self.button.pack(fill='x',padx=25,pady=10)
        self.resume_button=ctk.CTkButton(panel,text='Wznów zapamiętaną sesję',fg_color='#222733',command=lambda:self.submit(True));self.resume_button.pack(fill='x',padx=25,pady=5)
        self.protocol('WM_DELETE_WINDOW',lambda:None if self.busy else self.destroy())
        self.after(100,self.poll)

    def submit(self,resume=False):
        if self.busy:return
        values={k:e.get() for k,e in self.entries.items()};remember=self.remember.get()
        self.busy=True;self.button.configure(state='disabled');self.resume_button.configure(state='disabled');self.hint.configure(text='Łączenie z Supabase…')
        def work():
            try:
                api=Supabase(values)
                email=api.resume() if resume else api.login(values['email'],values['password'],remember)
                if not email:raise CloudError('Brak aktywnej zapisanej sesji. Zaloguj się hasłem.')
                # Public project configuration only. Never persist password or session tokens here.
                config={k:values[k] for k in ('url','publishable_key')}
                tmp=ROOT/'supabase_config.json.tmp';tmp.write_text(json.dumps(config,indent=2),encoding='utf-8');tmp.replace(ROOT/'supabase_config.json')
                self.queue.put(('ok',api,email))
            except Exception as exc:self.queue.put(('error',str(exc) if isinstance(exc,CloudError) else 'Nie udało się przygotować logowania. Sprawdź uprawnienia do folderu.'))
        threading.Thread(target=work,daemon=True).start()

    def poll(self):
        try:r=self.queue.get_nowait()
        except queue.Empty:self.after(100,self.poll);return
        if r[0]=='ok':self.result=(r[1],r[2]);self.destroy();return
        self.busy=False;self.button.configure(state='normal');self.resume_button.configure(state='normal');self.hint.configure(text=r[1],text_color=RED);self.after(100,self.poll)


def run():
    while True:
        login=Login();login.mainloop()
        if not login.result:return
        api,email=login.result
        # This backup precedes even the legacy startup migrations.
        try:
            from first_run import ensure_inventory
            ensure_inventory(ROOT)
            backup_database(ROOT/'streetsell.db','start_v4')
            from storage import Store
            from pallet_manager import setup
            # Ownership check must run BEFORE the App constructor starts Allegro jobs.
            store=Store(ROOT/'streetsell.db')
            api.list_rows('pallets')  # Verify protocol and authenticated RLS access before binding local data.
            setup(store)
            sync=Sync(store,api)
        except Exception as exc:
            root=tk.Tk();root.withdraw();messagebox.showerror('StreetSell AI V4',str(exc));root.destroy();return
        from modern_ui import App,Button

        class CloudApp(App):
            def __init__(self):
                self.cloud_running=False;self.cloud_is_manual=False;self.cloud_queue=queue.Queue();self.cloud_sync=sync;self.cloud_api=api
                super().__init__();self.title('StreetSell AI • V4.1.3')
                self.owner_login=email;self.owner_label.configure(text=email+' · Supabase')
                foot=self.owner_label.master
                self.cloud_label=ctk.CTkLabel(foot,text='Chmura: oczekuje',wraplength=175);self.cloud_label.pack(fill='x')
                Button(foot,'Synchronizacja',self.manual_sync).pack(fill='x',pady=4)
                Button(foot,'Konflikty',self.show_conflicts).pack(fill='x',pady=4)
                self.after(200,self.cloud_poll);self.after(1500,self.auto_cloud)

            def manual_sync(self):
                if self.cloud_running:return
                if self.busy_id is not None or getattr(self,'photo_importing',False):return
                if not self.confirm_pending():return
                self.start_cloud(manual=True)

            def auto_cloud(self):
                # Do not modify a product while the user is editing or a dialog is open.
                if not self.cloud_running and not self.dirty and self.busy_id is None and self.current_view=='inventory' and self.grab_current() is None:
                    self.start_cloud()
                self.after(60000,self.auto_cloud)

            def start_cloud(self,manual=False):
                self.cloud_is_manual=manual
                self.cloud_running=True;self.cloud_label.configure(text='Chmura: synchronizacja…')
                self.cloud_overlay=ctk.CTkToplevel(self);self.cloud_overlay.title('Synchronizacja V4');self.cloud_overlay.geometry('420x140');self.cloud_overlay.transient(self)
                ctk.CTkLabel(self.cloud_overlay,text='Synchronizowanie danych…\nZmiany lokalne są zabezpieczone.',wraplength=380).pack(expand=True,padx=20,pady=20)
                self.cloud_overlay.protocol('WM_DELETE_WINDOW',lambda:None);self.cloud_overlay.grab_set()
                def work():
                    try:self.cloud_queue.put(('ok',self.cloud_sync.cycle()))
                    except Exception as exc:self.cloud_queue.put(('error',str(exc) if isinstance(exc,CloudError) else 'Synchronizacja przerwana. Dane lokalne zachowane; sprawdź zgodność schematu V4.'))
                threading.Thread(target=work,daemon=True).start()

            def refresh_cloud_view(self):
                self.load_db()
                if self.current_view=='product' and self.selected_id and not self.dirty:
                    self.show_product()

            def cloud_poll(self):
                try:r=self.cloud_queue.get_nowait()
                except queue.Empty:self.after(200,self.cloud_poll);return
                self.cloud_running=False;self.cloud_overlay.grab_release();self.cloud_overlay.destroy()
                if r[0]=='ok':
                    d=r[1];self.cloud_label.configure(text=f"Chmura: ↑{d['uploaded']} ↓{d['downloaded']}\nKonflikty: {d['conflicts']}")
                    if d['downloaded']:self.refresh_cloud_view()
                else:
                    self.cloud_label.configure(text='Chmura: błąd — kliknij Synchronizacja')
                    self.refresh_cloud_view()
                    self.last_cloud_error=r[1]
                    if self.cloud_is_manual:messagebox.showerror('Synchronizacja Supabase',r[1],parent=self)
                self.after(200,self.cloud_poll)

            def show_conflicts(self):
                if self.cloud_running or not self.confirm_pending():return
                records=self.cloud_sync.conflicts()
                if not records:messagebox.showinfo('Synchronizacja','Brak konfliktów.',parent=self);return
                win=ctk.CTkToplevel(self);win.title('Konflikty synchronizacji');win.geometry('850x650');win.transient(self);win.grab_set()
                body=ctk.CTkScrollableFrame(win);body.pack(fill='both',expand=True,padx=15,pady=15)
                for m in records:
                    remote=json.loads(m['conflict'])
                    with self.store.connect() as c:local=self.cloud_sync.payload(c,m['kind'],m['local_id'])
                    ctk.CTkLabel(body,text=f"{m['kind']} #{m['local_id']} • {m['uid']}",text_color=RED).pack(anchor='w',pady=(15,4))
                    box=ctk.CTkTextbox(body,height=200);box.pack(fill='x');box.insert('1.0',json.dumps({'Ten komputer':local,'Chmura':remote['data']},ensure_ascii=False,indent=2));box.configure(state='disabled')
                    def resolve(choice,record=m):
                        self.cloud_sync.resolve(record['kind'],record['local_id'],choice);win.destroy();self.refresh_cloud_view();self.show_conflicts()
                    ctk.CTkButton(body,text='Zachowaj wersję z komputera',fg_color=RED,command=lambda f=resolve:f('local')).pack(pady=4)
                    ctk.CTkButton(body,text='Przyjmij wersję z chmury',command=lambda f=resolve:f('remote')).pack(pady=4)

            def logout(self):
                if self.cloud_running:return
                if self.busy_id is not None or not self.confirm_pending():return
                try:self.cloud_api.logout()
                except CloudError as exc:messagebox.showerror('Wylogowanie',str(exc),parent=self);return
                super().logout()

            def close(self):
                if self.cloud_running:return
                super().close()

        app=CloudApp();app.mainloop()
        if not getattr(app,'logout_requested',False):return
