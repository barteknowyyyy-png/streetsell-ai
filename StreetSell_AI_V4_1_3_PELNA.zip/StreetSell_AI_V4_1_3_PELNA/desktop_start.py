"""Windowed desktop entry point with visible startup failures."""
from pathlib import Path
import os,traceback

def main():
    root=Path(__file__).resolve().parent
    os.chdir(root)
    try:
        from app import main as launch
        launch()
    except Exception:
        (root/'startup_error.log').write_text(traceback.format_exc(),encoding='utf-8')
        import tkinter as tk
        from tkinter import messagebox
        window=tk.Tk();window.withdraw()
        messagebox.showerror('StreetSell AI','Nie udało się uruchomić aplikacji. Szczegóły zapisano w startup_error.log w folderze aplikacji. Uruchom install.bat, aby sprawdzić zależności.')
        window.destroy()

if __name__=='__main__':main()
