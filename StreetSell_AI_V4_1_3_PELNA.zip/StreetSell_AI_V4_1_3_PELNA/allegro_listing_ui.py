"""Seller-facing offer editor; remote work always runs outside the Tk thread."""
import copy,json,queue,re,threading,webbrowser
from pathlib import Path
import tkinter as tk
from tkinter import ttk,messagebox,simpledialog
from allegro_api import AllegroClient,AllegroError
from allegro_listing_api import OfferAPI,ListingError
from allegro_listing import ListingService,prepare_payload,calculate_price,seller_template,normalize_parameter,catalog_text

PROVINCES=['DOLNOSLASKIE','KUJAWSKO_POMORSKIE','LUBELSKIE','LUBUSKIE','LODZKIE','MALOPOLSKIE','MAZOWIECKIE','OPOLSKIE','PODKARPACKIE','PODLASKIE','POMORSKIE','SLASKIE','SWIETOKRZYSKIE','WARMINSKO_MAZURSKIE','WIELKOPOLSKIE','ZACHODNIOPOMORSKIE']

class OfferEditor(tk.Toplevel):
    def __init__(self,app,pid):
        super().__init__(app);self.app=app;self.pid=pid;self.source=dict(app.store.get(pid));self.api=None;self.service=None
        self.catalog=None;self.definitions=[];self.param_widgets=[];self.settings={};self.choices={};self.events=queue.Queue();self.busy=False;self.closed=False;self.actions=[]
        self.title('StreetSell AI • Wystawianie i edycja Allegro');self.geometry('1000x760');self.minsize(900,650);self.transient(app);self.grab_set()
        self.vars={k:tk.StringVar(value=v) for k,v in {'title':self.source.get('generated_title') or '', 'quantity':str(self.source.get('quantity',0)),
         'price':self.source.get('sale_price') or '', 'minimum':'','maximum':'','city':'','countryCode':'PL','postCode':'','province':'',
         'invoice':'NO_INVOICE','handlingTime':'PT24H','formula':'fixed','base':self.source.get('sale_price') or '', 'percent':'0'}.items()}
        self.use_local=tk.BooleanVar(value=True);self.ai_images=tk.BooleanVar(value=False);self.update_stock=tk.BooleanVar(value=False);self.update_images=tk.BooleanVar(value=False)
        self.environment=tk.StringVar(value='production');self.query=tk.StringVar(value=self.source.get('ean') or self.source.get('product_name') or '')
        self.build();self.protocol('WM_DELETE_WINDOW',self.close);self.after(100,self.poll);self.load_account()

    def button(self,parent,text,command,**kw):
        b=ttk.Button(parent,text=text,command=command,**kw);self.actions.append(b);return b
    def entry(self,parent,key,label,row,col=0,width=30):
        ttk.Label(parent,text=label).grid(row=row,column=col*2,sticky='w',padx=5,pady=4)
        w=ttk.Entry(parent,textvariable=self.vars[key],width=width);w.grid(row=row,column=col*2+1,sticky='ew',padx=5,pady=4);return w
    def text(self,parent,height=6):
        frame=ttk.Frame(parent);frame.pack(fill='both',expand=True,pady=4)
        box=tk.Text(frame,height=height,wrap='word',undo=True);bar=ttk.Scrollbar(frame,command=box.yview)
        box.configure(yscrollcommand=bar.set);bar.pack(side='right',fill='y');box.pack(fill='both',expand=True);return box
    def build(self):
        shell=ttk.Frame(self,padding=12);shell.pack(fill='both',expand=True)
        top=ttk.Frame(shell);top.pack(fill='x')
        ttk.Label(top,text=f"SS-{self.pid:05d} • Allegro",font=('Segoe UI',16,'bold')).pack(side='left')
        self.env_combo=ttk.Combobox(top,textvariable=self.environment,values=['production','sandbox'],state='readonly',width=12);self.env_combo.pack(side='right')
        self.env_combo.bind('<<ComboboxSelected>>',lambda e:self.load_account())
        self.button(top,'Wczytaj konto i ustawienia',self.load_account).pack(side='right',padx=8)
        self.account_label=ttk.Label(shell,text='Łączenie…');self.account_label.pack(fill='x',pady=5)
        self.tabs=ttk.Notebook(shell);self.tabs.pack(fill='both',expand=True)
        self.pages={}
        for name in ('Produkt Allegro','Oferta i cena','Dostawa i warunki','Parametry i GPSR','Podgląd JSON'):
            p=ttk.Frame(self.tabs,padding=8);self.tabs.add(p,text=name);self.pages[name]=p
        p=self.pages['Produkt Allegro'];row=ttk.Frame(p);row.pack(fill='x')
        ttk.Entry(row,textvariable=self.query).pack(side='left',fill='x',expand=True)
        self.button(row,'Szukaj w katalogu',self.search).pack(side='left',padx=4)
        self.button(row,'Nowy produkt / kategoria',self.search_categories).pack(side='left',padx=4)
        self.button(row,'Następne wyniki',self.next_results).pack(side='left',padx=4)
        self.button(row,'Wybierz produkt',self.choose_product).pack(side='right')
        self.results=ttk.Treeview(p,columns=('name','category'),show='headings',height=9)
        self.results.heading('name',text='Produkt z katalogu Allegro — sprawdź model i wariant');self.results.heading('category',text='Kategoria')
        self.results.column('name',width=620);self.results.column('category',width=200)
        sy=ttk.Scrollbar(p,command=self.results.yview);sy.pack(side='right',fill='y');self.results.configure(yscrollcommand=sy.set);self.results.pack(fill='both',expand=True)
        self.results.bind('<Double-1>',lambda e:self.choose_product())
        self.product_label=ttk.Label(p,text='Nie wybrano produktu. ASIN nie jest identyfikatorem katalogu Allegro.',wraplength=850);self.product_label.pack(fill='x',pady=5)
        row=ttk.Frame(p);row.pack(fill='x');self.template_query=tk.StringVar()
        ttk.Entry(row,textvariable=self.template_query,width=22).pack(side='left')
        self.button(row,'Moje oferty',self.templates).pack(side='left',padx=5)
        self.template_combo=ttk.Combobox(row,state='readonly',width=35);self.template_combo.pack(side='left',fill='x',expand=True)
        self.button(row,'Użyj ustawień',self.use_template).pack(side='right')
        self.button(row,'Edytuj wybraną ofertę',self.link_existing).pack(side='right',padx=4)
        p=self.pages['Oferta i cena'];fields=ttk.Frame(p);fields.pack(fill='x');fields.columnconfigure(1,weight=1)
        self.entry(fields,'title','Tytuł (12–75 znaków)',0,width=72);self.entry(fields,'price','Cena PLN',1)
        self.entry(fields,'quantity','Sztuki w ofercie (maks. stan magazynu)',2)
        ttk.Checkbutton(fields,text='Aktualizuj też ilość w istniejącej ofercie',variable=self.update_stock).grid(row=2,column=2,columnspan=2,sticky='w')
        formula=ttk.LabelFrame(p,text='Wylicz cenę początkową');formula.pack(fill='x',pady=5)
        ttk.Combobox(formula,textvariable=self.vars['formula'],values=['fixed','markup','discount'],state='readonly',width=12).pack(side='left',padx=4)
        ttk.Label(formula,text='Kwota bazowa / koszt:').pack(side='left');ttk.Entry(formula,textvariable=self.vars['base'],width=12).pack(side='left',padx=4)
        ttk.Label(formula,text='Procent:').pack(side='left');ttk.Entry(formula,textvariable=self.vars['percent'],width=7).pack(side='left',padx=4)
        self.button(formula,'Oblicz cenę',self.compute).pack(side='left',padx=6)
        ttk.Label(p,text='fixed = stała; markup = narzut do podanego kosztu; discount = obniżka od podanej kwoty. Narzut nie uwzględnia prowizji.').pack(anchor='w')
        pricing=ttk.Frame(p);pricing.pack(fill='x',pady=4)
        ttk.Label(pricing,text='Reguła Allegro:').pack(side='left');self.rule_combo=ttk.Combobox(pricing,state='readonly',width=40);self.rule_combo.pack(side='left',padx=4)
        for k,label in [('minimum','Min PLN'),('maximum','Max PLN')]:ttk.Label(pricing,text=label).pack(side='left');ttk.Entry(pricing,textvariable=self.vars[k],width=10).pack(side='left',padx=4)
        self.button(pricing,'Nowa reguła',self.new_rule).pack(side='left')
        ttk.Label(p,text='Reguły Allegro działają na serwerze także po zamknięciu aplikacji. Cena ręczna wyłącza regułę na allegro.pl.').pack(anchor='w')
        ttk.Label(p,text='Opis oferty:').pack(anchor='w');self.description=self.text(p,5);self.description.insert('1.0',self.source.get('generated_description') or '')
        row=ttk.Frame(p);row.pack(fill='x')
        ttk.Checkbutton(row,text='Prześlij zdjęcia z galerii aplikacji',variable=self.use_local).pack(side='left')
        ttk.Checkbutton(row,text='Oznacz przesyłane zdjęcia jako współtworzone AI',variable=self.ai_images).pack(side='left',padx=8)
        ttk.Checkbutton(p,text='Zmień też zdjęcia istniejącej oferty (przy samej edycji ceny nie trzeba)',variable=self.update_images).pack(anchor='w')
        self.photo_label=ttk.Label(p,text='');self.photo_label.pack(fill='x')
        p=self.pages['Dostawa i warunki'];p.columnconfigure(1,weight=1);self.combos={};self.option_maps={}
        for i,(key,label) in enumerate([('shipping','Cennik dostawy'),('returns','Warunki zwrotów'),('implied','Warunki reklamacji'),('warranty','Gwarancja (opcjonalnie)')]):
            ttk.Label(p,text=label).grid(row=i,column=0,sticky='w',padx=5,pady=5);w=ttk.Combobox(p,state='readonly',width=65);w.grid(row=i,column=1,columnspan=3,sticky='ew',padx=5);self.combos[key]=w
        for row,(key,label) in enumerate([('city','Miejscowość'),('postCode','Kod pocztowy'),('countryCode','Kraj (np. PL)')],4):self.entry(p,key,label,row)
        ttk.Label(p,text='Województwo PL').grid(row=7,column=0,sticky='w');ttk.Combobox(p,textvariable=self.vars['province'],values=PROVINCES,state='readonly',width=40).grid(row=7,column=1,sticky='ew',padx=5)
        ttk.Label(p,text='Wysyłka po').grid(row=8,column=0,sticky='w');ttk.Combobox(p,textvariable=self.vars['handlingTime'],values=['PT0S','PT24H','P2D','P3D','P4D','P5D','P7D','P10D','P14D','P21D','P30D','P60D'],state='readonly').grid(row=8,column=1,sticky='ew',padx=5)
        ttk.Label(p,text='Faktura').grid(row=9,column=0,sticky='w');ttk.Combobox(p,textvariable=self.vars['invoice'],values=['NO_INVOICE','WITHOUT_VAT','VAT','VAT_MARGIN'],state='readonly').grid(row=9,column=1,sticky='ew',padx=5)
        self.button(p,'Zapamiętaj ustawienia sprzedaży dla tego konta',self.save_defaults).grid(row=10,column=0,columnspan=4,pady=12)
        p=self.pages['Parametry i GPSR'];inner=ttk.Notebook(p);inner.pack(fill='both',expand=True)
        self.params_frame=ttk.Frame(inner,padding=5);gpsr=ttk.Frame(inner,padding=5);inner.add(self.params_frame,text='Parametry kategorii');inner.add(gpsr,text='Producent i bezpieczeństwo')
        for key,label in [('producer','Producent — wybierz właściwe dane'),('person','Osoba odpowiedzialna w UE (jeśli wymagana)')]:
            ttk.Label(gpsr,text=label).pack(anchor='w');self.combos[key]=ttk.Combobox(gpsr,state='readonly',width=90);self.combos[key].pack(fill='x',pady=4)
        ttk.Label(gpsr,text='Informacje bezpieczeństwa (z dokumentacji produktu lub sugestii katalogu Allegro):').pack(anchor='w');self.safety=self.text(gpsr,7)
        ttk.Label(gpsr,text='Brakujących danych producenta nie wymyślamy. W razie braku dodaj je do słownika Allegro i odśwież ustawienia.',wraplength=850).pack(anchor='w')
        p=self.pages['Podgląd JSON'];self.button(p,'Przelicz i pokaż dane wysyłane do Allegro',self.preview).pack(anchor='w');self.json_box=self.text(p,14)
        self.edit_json=tk.BooleanVar(value=False);ttk.Checkbutton(p,text='Użyj ręcznie poprawionego JSON (parametry nietypowe / dodatkowe pola)',variable=self.edit_json).pack(anchor='w')
        ttk.Label(p,text='Zdjęcia lokalne są przesyłane dopiero przy zapisie. Publikacja następuje wyłącznie przyciskiem na dole.',wraplength=850).pack(anchor='w')
        bottom=ttk.Frame(shell);bottom.pack(fill='x',pady=(8,0))
        self.button(bottom,'Sprawdź status / cenę',self.check).pack(side='left')
        self.button(bottom,'Zapisz w Allegro',lambda:self.send(False)).pack(side='left',padx=6)
        self.button(bottom,'WYSTAW / AKTUALIZUJ',lambda:self.send(True)).pack(side='left',padx=6)
        self.button(bottom,'Otwórz ofertę',self.open_offer).pack(side='right')
        self.status=ttk.Label(shell,text='Gotowy',wraplength=920);self.status.pack(fill='x',pady=5)

    def work(self,fn,callback):
        if self.busy:return
        self.busy=True;self.env_combo.configure(state='disabled')
        for b in self.actions:b.state(['disabled'])
        def run():
            try:self.events.put(('done',callback,fn()))
            except Exception as exc:self.events.put(('error',str(exc) if isinstance(exc,(AllegroError,ValueError)) else 'Nie udało się wykonać operacji. Sprawdź ustawienia i status oferty.'))
        threading.Thread(target=run,daemon=True).start()
    def progress(self,text):self.events.put(('progress',text))
    def poll(self):
        if self.closed:return
        for _ in range(30):
            try:item=self.events.get_nowait()
            except queue.Empty:break
            if item[0]=='progress':self.status.configure(text=item[1]);continue
            self.busy=False;self.env_combo.configure(state='readonly')
            for b in self.actions:b.state(['!disabled'])
            if item[0]=='error':self.status.configure(text=item[1]);messagebox.showerror('Allegro',item[1],parent=self)
            else:
                try:item[1](item[2])
                except Exception as exc:messagebox.showerror('Allegro',str(exc),parent=self)
        self.after(100,self.poll)
    def load_account(self):
        if self.busy:
            if self.api:self.environment.set(self.api.env)
            return
        env=self.environment.get();self.api=None;self.service=None;self.catalog=None;self.account_label.configure(text='Łączenie z '+env)
        self.status.configure(text='Pobieranie ustawień i reguł z Allegro…')
        def fetch():
            api=OfferAPI(AllegroClient(env));service=ListingService(self.app.store,api)
            return api,service,api.settings(),service.defaults(),service.row(self.pid)
        self.work(fetch,self.loaded)
    def loaded(self,result):
        self.api,self.service,self.settings,defaults,row=result
        self.environment.set(self.api.env)
        self.account_label.configure(text=self.api.profile['login']+' • '+self.api.env+' • uprawnienia do ofert wymagają ponownej zgody OAuth')
        for key,source in [('shipping','shipping'),('returns','returns'),('implied','implied'),('warranty','warranties'),('producer','producers'),('person','persons')]:self.fill_combo(key,self.settings.get(source,[]))
        self.fill_rules();self.set_values(defaults)
        self.photo_label.configure(text=f"Lokalnych zdjęć: {len(self.app.gallery.photos(self.pid))} (do oferty maks. 16, kolejność z galerii)")
        self.ai_images.set(any(r['localization_language'] for r in self.app.gallery.photos(self.pid)))
        self.status.configure(text='Ustawienia pobrane. Wybierz produkt katalogowy; przed publikacją sprawdź cenę i wariant.'+(' Ostrzeżenia: '+'; '.join(self.settings.get('warnings',[])) if self.settings.get('warnings') else ''))
        self.query_page=None
        if row['offer_id'] or row['phase'] in ('REQUESTING','PROCESSING'):self.check()
        else:self.search()
    def fill_combo(self,key,rows):
        mapping={'— nie wybrano —':''}
        for r in rows:
            name=str(r.get('name') or r.get('id') or 'Pozycja');mapping[name+' ['+str(r['id'])+']']=str(r['id'])
        self.option_maps[key]=mapping;self.combos[key].configure(values=list(mapping));self.combos[key].set(next(iter(mapping)))
        if key in ('shipping','returns','implied') and len(rows)==1:self.combos[key].set(list(mapping)[1])
    def fill_rules(self):
        self.rule_map={'Cena ręczna — bez reguły':''}
        for r in self.settings.get('rules',[]):
            if r['type']!='EXCHANGE_RATE':self.rule_map[str(r['name'])+' ['+str(r['id'])+']']=r['id']
        self.rule_combo.configure(values=list(self.rule_map));self.rule_combo.set(next(iter(self.rule_map)))
    def set_values(self,data):
        for key,value in data.items():
            if key=='location':
                for k,v in value.items():
                    if k in self.vars:self.vars[k].set(str(v))
            elif key in self.combos:
                match=next((name for name,uid in self.option_maps[key].items() if uid==value),None)
                if match:self.combos[key].set(match)
            elif key in self.vars:self.vars[key].set(str(value))
    def search(self,page=None):
        if not self.api:return
        phrase=self.query.get().strip()
        if not phrase:return
        self.current_search=phrase;self.status.configure(text='Wyszukiwanie produktów w Allegro…')
        self.work(lambda:self.api.products(phrase,bool(re.fullmatch(r'\d{8,14}',phrase)),page),self.found)
    def next_results(self):
        if getattr(self,'query_page',None):self.search(self.query_page)
        else:messagebox.showinfo('Katalog','Brak następnej strony wyników.',parent=self)
    def found(self,data):
        self.results.delete(*self.results.get_children());self.search_products={}
        for p in data.get('products',[]):
            self.search_products[str(p['id'])]=p;self.results.insert('','end',iid=str(p['id']),values=(p.get('name',''),(p.get('category') or {}).get('name','')))
        self.result_kind='products'
        self.query_page=(data.get('nextPage') or {}).get('id')
        self.status.configure(text=f"Znaleziono {len(self.search_products)} produktów. Wybierz dokładny model i wariant.")
        if len(self.search_products)==1 and re.fullmatch(r'\d{8,14}',getattr(self,'current_search','')):
            uid=next(iter(self.search_products));self.results.selection_set(uid);self.choose_product()
    def choose_product(self):
        rows=self.results.selection()
        if not rows:return
        uid=rows[0]
        if getattr(self,'result_kind','products')=='categories':
            def fetch():
                category=self.api.get('/sale/categories/'+uid)
                if not category.get('leaf'):raise ListingError('Wybierz końcową kategorię. Doprecyzuj wyszukiwanie.')
                return category,self.api.parameters(uid)
            self.work(fetch,self.new_category_selected)
        else:self.work(lambda:self.fetch_product(uid),self.product_loaded)
    def search_categories(self):
        if not self.api:return
        from urllib.parse import urlencode
        phrase=self.query.get().strip()
        def found(data):
            self.results.delete(*self.results.get_children());self.result_kind='categories';self.query_page=None
            for c in data.get('matchingCategories',[]):self.results.insert('','end',iid=c['id'],values=(c['name'],(c.get('parent') or {}).get('name','')))
            self.status.configure(text='Wybierz końcową kategorię dla nowego produktu. Allegro może wymagać EAN, marki i pozostałych parametrów.')
        self.work(lambda:self.api.get('/sale/matching-categories?'+urlencode({'name':phrase})),found)
    def new_category_selected(self,result):
        category,definitions=result
        name=simpledialog.askstring('Nowy produkt w katalogu','Rzeczywista nazwa i model produktu (maks. 75 znaków):',initialvalue=str(self.source.get('product_name') or '')[:75],parent=self)
        if not name:return
        if len(name)>75:messagebox.showerror('Produkt','Nazwa może mieć maksymalnie 75 znaków.',parent=self);return
        self.product_loaded(({'_new':True,'name':name,'category':category,'parameters':[],'images':[]},definitions))
        self.use_local.set(True)

    def fetch_product(self,uid):
        product=self.api.product(uid);return product,self.api.parameters(product['category']['id'])
    def product_loaded(self,result):
        self.catalog,self.definitions=result
        self.product_label.configure(text=('Nowy produkt: ' if self.catalog.get('_new') else 'Wybrano: ')+self.catalog['name']+' • '+str(self.catalog.get('id') or self.catalog['category']['id']))
        self.render_parameters()
        if not self.vars['title'].get().strip():self.vars['title'].set(self.catalog.get('name',''))
        if not self.description.get('1.0','end-1c').strip():self.description.insert('1.0',catalog_text(self.catalog.get('description')))
        if not self.app.gallery.photos(self.pid):self.use_local.set(False)
        safety=self.catalog.get('productSafety') or {};suggestions=safety.get('responsibleProducers') or []
        combined={r['id']:r for r in self.settings.get('producers',[])};combined.update({r['id']:dict(r,name='Sugestia katalogu: '+str(r.get('name') or r['id'])) for r in suggestions})
        self.fill_combo('producer',list(combined.values()))
        if len(suggestions)==1:self.set_values({'producer':suggestions[0]['id']})
        self.safety.delete('1.0','end')
        if (safety.get('safetyInformation') or {}).get('type')=='TEXT':self.safety.insert('1.0',safety['safetyInformation']['description'])
        self.status.configure(text='Produkt i parametry pobrane. Sprawdź dane oferty oraz GPSR.')
    def render_parameters(self):
        for w in self.params_frame.winfo_children():w.destroy()
        self.param_widgets=[]
        canvas=tk.Canvas(self.params_frame,highlightthickness=0);bar=ttk.Scrollbar(self.params_frame,command=canvas.yview);canvas.configure(yscrollcommand=bar.set);bar.pack(side='right',fill='y');canvas.pack(fill='both',expand=True)
        body=ttk.Frame(canvas);window=canvas.create_window(0,0,window=body,anchor='nw')
        body.bind('<Configure>',lambda e:canvas.configure(scrollregion=canvas.bbox('all')));canvas.bind('<Configure>',lambda e:canvas.itemconfigure(window,width=e.width))
        existing={str(p['id']):p for p in self.catalog.get('parameters',[])}
        for p in self.definitions:
            if (p.get('options') or {}).get('describesProduct') and not self.catalog.get('_new'):continue
            row=ttk.Frame(body);row.pack(fill='x',pady=4)
            ttk.Label(row,text=p['name']+(' *' if p.get('required') else ''),width=35).pack(side='left')
            options={str(x['value'])+' ['+str(x['id'])+']':str(x['id']) for x in p.get('dictionary',[])}
            var=tk.StringVar();minimum=tk.StringVar();maximum=tk.StringVar()
            if options:
                widget=ttk.Combobox(row,textvariable=var,values=['',*options],state='readonly',width=50);widget.pack(side='left',fill='x',expand=True)
                if p['name'].casefold()=='stan':
                    wanted=self.source.get('condition','').casefold()
                    for name in options:
                        if name.split(' [')[0].casefold()==wanted:var.set(name);break
            elif (p.get('restrictions') or {}).get('range'):
                ttk.Entry(row,textvariable=minimum,width=18).pack(side='left');ttk.Label(row,text=' do ').pack(side='left');ttk.Entry(row,textvariable=maximum,width=18).pack(side='left')
            else:
                ttk.Entry(row,textvariable=var,width=55).pack(side='left',fill='x',expand=True)
                if ('ean' in p['name'].casefold() or 'gtin' in p['name'].casefold()) and self.source.get('ean'):var.set(str(self.source['ean']))
            self.param_widgets.append((p,var,options,minimum,maximum))
        ttk.Label(body,text='* wymagane przez kategorię. Parametry zależne i wielokrotne można uzupełnić w JSON; Allegro waliduje komplet.',wraplength=820).pack(anchor='w',pady=10)
    def collect(self):
        if not self.service or not self.catalog:raise ListingError('Wczytaj konto i wybierz produkt z katalogu Allegro.')
        c={k:v.get() for k,v in self.vars.items()};c['location']={k:c.pop(k) for k in ('city','countryCode','postCode','province')}
        for key,widget in self.combos.items():c[key]=self.option_maps.get(key,{}).get(widget.get(),'')
        if self.rule_combo.get() not in self.rule_map:raise ListingError('Nie rozpoznano bieżącej reguły. Odśwież ustawienia lub jawnie wybierz cenę ręczną.')
        c['rule']=self.rule_map.get(self.rule_combo.get(),'');c['description']=self.description.get('1.0','end-1c');c['safety']=self.safety.get('1.0','end-1c')
        c['ai_images']=self.ai_images.get();c['update_stock']=self.update_stock.get();c['update_images']=self.update_images.get();c['_original_price']=self.source.get('sale_price') or ''
        c['parameters']=[]
        for p,var,options,minimum,maximum in self.param_widgets:
            v=var.get().strip()
            if options and v:c['parameters'].append({'id':p['id'],'valuesIds':[options[v]]})
            elif minimum.get() or maximum.get():c['parameters'].append({'id':p['id'],'rangeValue':{'from':minimum.get(),'to':maximum.get()}})
            elif v:c['parameters'].append({'id':p['id'],'values':[v]})
        return c
    def payload(self):
        c=self.collect();r=self.service.row(self.pid)
        if self.edit_json.get():
            data=json.loads(self.json_box.get('1.0','end-1c'))
            if not isinstance(data,dict):raise ListingError('Podgląd musi być obiektem JSON.')
        else:data=prepare_payload(self.source,self.catalog,self.definitions,c,r['external_id'])
        return data,c
    def preview(self):
        try:
            c=self.collect();data=prepare_payload(self.source,self.catalog,self.definitions,c,self.service.row(self.pid)['external_id'])
            self.json_box.delete('1.0','end');self.json_box.insert('1.0',json.dumps(data,ensure_ascii=False,indent=2));self.tabs.select(self.pages['Podgląd JSON'])
        except Exception as e:messagebox.showerror('Dane oferty',str(e),parent=self)
    def compute(self):
        try:self.vars['price'].set(calculate_price(self.vars['formula'].get(),self.vars['base'].get(),self.vars['percent'].get(),self.vars['minimum'].get(),self.vars['maximum'].get()))
        except Exception as e:messagebox.showerror('Cena',str(e),parent=self)
    def save_defaults(self):
        try:self.service.save_defaults(self.collect());self.status.configure(text='Zapamiętano ustawienia sprzedaży. Producent, reguły i parametry produktu nie są zapisywane jako domyślne.')
        except Exception as e:messagebox.showerror('Ustawienia',str(e),parent=self)
    def templates(self):
        query=self.template_query.get()
        if self.api:self.work(lambda:self.api.offers(query),self.templates_loaded)
    def templates_loaded(self,offers):
        self.template_map={str(o['name'])+' ['+str(o['id'])+']':o['id'] for o in offers}
        self.template_combo.configure(values=list(self.template_map))
        if self.template_map:self.template_combo.set(next(iter(self.template_map)))
    def use_template(self):
        uid=getattr(self,'template_map',{}).get(self.template_combo.get())
        if uid:self.work(lambda:self.api.offer(uid),lambda offer:self.set_values(seller_template(offer)))
    def link_existing(self):
        uid=getattr(self,'template_map',{}).get(self.template_combo.get())
        if not uid or not self.catalog or not self.catalog.get('id'):
            messagebox.showinfo('Powiązanie','Wybierz produkt z katalogu i swoją ofertę z listy Moje oferty.',parent=self);return
        if not messagebox.askyesno('Edycja istniejącej oferty',f'Powiązać ofertę {uid} z produktem SS-{self.pid:05d}? Kolejny zapis będzie zmieniał tę ofertę.',parent=self):return
        catalog_id=self.catalog['id']
        self.work(lambda:self.service.link_existing(self.pid,uid,catalog_id),self.checked)

    def new_rule(self):
        if not self.api:return
        name=simpledialog.askstring('Nowa reguła','Nazwa reguły (maks. 33 znaki):',parent=self)
        if not name:return
        kind=simpledialog.askstring('Typ reguły','Wpisz typ: FOLLOW_BY_ALLEGRO_MIN_PRICE, FOLLOW_BY_MARKET_MIN_PRICE albo FOLLOW_BY_TOP_OFFER_PRICE',initialvalue='FOLLOW_BY_ALLEGRO_MIN_PRICE',parent=self)
        if kind not in ('FOLLOW_BY_ALLEGRO_MIN_PRICE','FOLLOW_BY_MARKET_MIN_PRICE','FOLLOW_BY_TOP_OFFER_PRICE'):return
        if len(name)>33:messagebox.showerror('Reguła','Nazwa jest za długa.',parent=self);return
        def created(r):self.settings['rules'].append(r.data);self.fill_rules();self.rule_combo.set(next(k for k,v in self.rule_map.items() if v==r.data['id']))
        self.work(lambda:self.api.request('/sale/price-automation/rules','POST',{'name':name,'type':kind}),created)
    def check(self):
        if self.service:self.work(lambda:self.service.check(self.pid),self.checked)
    def checked(self,result):
        self.last_offer=result.get('offer');details=result.get('details') or {}
        price=(details.get('sellingMode') or {}).get('price') or {}
        self.status.configure(text='Allegro: '+str(result['state'])+' • oferta '+str(result.get('offer') or 'brak')+' • cena '+str(price.get('amount','—'))+' '+str(price.get('currency','')))
        if details and not self.catalog:
            product=((details.get('productSet') or [{}])[0].get('product') or {}).get('id')
            if product:
                self.existing_details=details;self.existing_rules=result.get('rules') or []
                self.work(lambda:self.fetch_product(product),self.existing_loaded)
    def existing_loaded(self,result):
        self.product_loaded(result);offer=self.existing_details
        self.set_values(seller_template(offer));self.vars['price'].set((offer.get('sellingMode') or {}).get('price',{}).get('amount',self.vars['price'].get()))
        first=(offer.get('productSet') or [{}])[0]
        safety=first.get('safetyInformation') or {}
        if safety.get('type')=='TEXT':self.safety.delete('1.0','end');self.safety.insert('1.0',safety['description'])
        values={str(p['id']):p for p in offer.get('parameters',[])}
        for definition,var,options,minimum,maximum in self.param_widgets:
            p=values.get(str(definition['id'])) or {}
            if options:
                selected=next((name for name,uid in options.items() if uid in p.get('valuesIds',[])),None)
                if selected:var.set(selected)
            elif p.get('rangeValue'):
                minimum.set(p['rangeValue'].get('from',''));maximum.set(p['rangeValue'].get('to',''))
            elif p.get('values'):var.set(str(p['values'][0]))
        self.set_values({'producer':(first.get('responsibleProducer') or {}).get('id',''),'person':(first.get('responsiblePerson') or {}).get('id','')})
        for rule in self.existing_rules:
            if (rule.get('marketplace') or {}).get('id')=='allegro-pl':
                match=next((k for k,v in self.rule_map.items() if v==(rule.get('rule') or {}).get('id')),None)
                if match:self.rule_combo.set(match)
                else:self.rule_combo.set('Nie odczytano bieżącej reguły — odśwież')
                bounds=(rule.get('configuration') or {}).get('priceRange') or {}
                self.vars['minimum'].set((bounds.get('minPrice') or {}).get('amount',''));self.vars['maximum'].set((bounds.get('maxPrice') or {}).get('amount',''))
        self.status.configure(text='Wczytano powiązaną ofertę. Edycja dotyczy tego samego numeru; ilość zmienia się tylko po zaznaczeniu opcji.')
    def send(self,publish):
        try:
            payload,choices=self.payload()
            paths=[]
            existing=self.service.row(self.pid)['offer_id']
            if existing and not self.update_images.get():
                payload.pop('images',None)
            elif self.use_local.get():
                rows=self.app.gallery.photos(self.pid);paths=[self.app.gallery.resolve(r['relative_path']) for r in rows]
                if not paths:raise ListingError('Dodaj zdjęcia do galerii lub odznacz opcję, aby użyć katalogu Allegro.')
            else:
                from urllib.parse import urlsplit
                urls=[i.get('url') for i in self.catalog.get('images',[]) if isinstance(i,dict) and i.get('url')]
                urls=[u for u in urls if urlsplit(u).scheme=='https' and (urlsplit(u).hostname or '').endswith(('.allegroimg.com','.allegroimg.pl'))][:16]
                if not urls:raise ListingError('Ten produkt nie ma zdjęć katalogowych. Dodaj własne zdjęcia.')
                payload['images']=urls
            # Capture all values on the UI thread. The worker never reads a Tk variable.
            service=self.service;pid=self.pid;quantity=self.source['quantity']
            self.status.configure(text='Rozpoczynam zapis'+(' i publikację…' if publish else '…'))
            self.work(lambda:service.send(pid,payload,choices,paths,quantity,publish,self.progress),self.sent)
        except Exception as e:messagebox.showerror('Wystawianie',str(e),parent=self)
    def sent(self,result):
        self.checked(result);self.app.load_db()
        if result['state']=='ACTIVE':messagebox.showinfo('Allegro','Oferta jest aktywna. Numer: '+str(result['offer']),parent=self)
        else:messagebox.showinfo('Allegro','Zapisano ofertę. Status: '+str(result['state'])+'. Aktywacja może jeszcze trwać; użyj Sprawdź status.',parent=self)
    def open_offer(self):
        uid=getattr(self,'last_offer',None) or (self.service.row(self.pid)['offer_id'] if self.service else '')
        if uid:webbrowser.open(('https://allegro.pl/oferta/' if self.api.env=='production' else 'https://allegro.pl.allegrosandbox.pl/oferta/')+uid)
    def close(self):
        if self.busy:
            messagebox.showinfo('Allegro','Trwa operacja. Poczekaj na jej wynik; zapis jest zabezpieczony przed duplikacją.',parent=self);return
        self.closed=True;self.grab_release();self.destroy()
