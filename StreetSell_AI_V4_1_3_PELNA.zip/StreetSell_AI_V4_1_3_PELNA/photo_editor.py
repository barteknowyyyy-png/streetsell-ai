"""Podgląd przygotowanego zdjęcia, zapis wyłącznie po wyborze użytkownika."""
import queue
import webbrowser
import tempfile
import threading
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox
from PIL import ImageTk, ImageOps
from photos import read_image, PhotoError, ImportCancelled
from photo_prepare import LocalRemover, compose_white, PYTHON_DOWNLOAD_URL

class PhotoEditor(tk.Toplevel):
    def __init__(self, app, product_id, photo):
        original = read_image(app.gallery.resolve(photo['relative_path']), (2048,2048))
        super().__init__(app)
        self.app, self.product_id, self.photo = app, product_id, dict(photo)
        self.title(f'Przygotuj zdjęcie • SS-{product_id:05d}')
        self.configure(bg='#171a22')
        self.geometry(f'{min(1040,self.winfo_screenwidth()-40)}x{min(740,self.winfo_screenheight()-70)}')
        self.minsize(800,570)
        self.transient(app)
        self.grab_set()
        self.temp = tempfile.TemporaryDirectory(prefix='streetsell-photo-')
        self.folder = Path(self.temp.name)
        self.original = original
        self.cutout = None
        self.result = None
        self.busy = False
        self.events = queue.Queue()
        self.cancel = threading.Event()
        self.closed = False
        self.remover = LocalRemover(app.gallery.base)
        outer = ttk.Frame(self,padding=16); outer.pack(fill='both',expand=True)
        ttk.Label(outer,text='Białe tło i margines — zapisz dopiero po sprawdzeniu',font=('Segoe UI',13,'bold')).pack(anchor='w')
        ttk.Label(outer,text='Oryginał pozostanie w galerii. Sprawdź krawędzie, detale i kompletność zestawu.',wraplength=950).pack(anchor='w',pady=(7,10))
        controls = ttk.Frame(outer); controls.pack(fill='x')
        self.remove_bg = tk.BooleanVar(value=False)
        self.remove_check = ttk.Checkbutton(controls,text='Usuń tło automatycznie',variable=self.remove_bg,command=self.changed)
        self.remove_check.pack(side='left')
        ttk.Label(controls,text='Margines:').pack(side='left',padx=(18,5))
        self.margin = tk.StringVar(value='8')
        self.margin_box = ttk.Combobox(controls,textvariable=self.margin,values=('3','5','8','10','15','20','25'),state='readonly',width=4)
        self.margin_box.pack(side='left'); ttk.Label(controls,text='%').pack(side='left')
        self.margin_box.bind('<<ComboboxSelected>>',lambda e:self.changed())
        self.prepare_button = ttk.Button(controls,text='Przygotuj podgląd',command=self.prepare)
        self.prepare_button.pack(side='right')
        self.install_button = ttk.Button(outer,text='Zainstaluj moduł tła (jednorazowo)',command=self.install)
        self.install_button.pack(anchor='w',pady=(10,4))
        self.python_button = ttk.Button(outer,text='Pobierz Python 3.13 (gdy brak zgodnej wersji)',
            command=lambda:webbrowser.open(PYTHON_DOWNLOAD_URL))
        self.python_button.pack(anchor='w',pady=(0,4))
        self.status = ttk.Label(outer,text='Bez usuwania tła program dodaje białe płótno i zachowuje całe zdjęcie.',wraplength=950)
        self.status.pack(fill='x',pady=(4,10))
        footer=ttk.Frame(outer); footer.pack(side='bottom',fill='x',pady=(12,0))
        self.save_button=ttk.Button(footer,text='Dodaj kopię do galerii',style='Accent.TButton',command=self.save,state='disabled')
        self.save_button.pack(side='right')
        self.close_button=ttk.Button(footer,text='Zamknij',command=self.close);self.close_button.pack(side='left')
        views=ttk.Frame(outer);views.pack(fill='both',expand=True)
        views.columnconfigure(0,weight=1);views.columnconfigure(1,weight=1);views.rowconfigure(1,weight=1)
        ttk.Label(views,text='Oryginał').grid(row=0,column=0,pady=6)
        ttk.Label(views,text='Wynik • 1600 × 1600 px').grid(row=0,column=1,pady=6)
        self.canvases=[]
        for col in range(2):
            canvas=tk.Canvas(views,bg='#20242e',highlightthickness=0,width=330,height=300)
            canvas.grid(row=1,column=col,sticky='nsew',padx=5)
            canvas.bind('<Configure>',self.draw)
            self.canvases.append(canvas)
        self.protocol('WM_DELETE_WINDOW',self.close)
        self.after(80,self.poll)
        self.controls()

    def controls(self):
        for widget in (self.remove_check,self.prepare_button,self.install_button,self.python_button):
            widget.state(['disabled' if self.busy else '!disabled'])
        self.margin_box.configure(state='disabled' if self.busy else 'readonly')
        self.save_button.state(['!disabled' if self.result is not None and not self.busy else 'disabled'])
        self.close_button.configure(text='Anuluj operację' if self.busy else 'Zamknij')
        if not self.busy:
            self.install_button.configure(text='Napraw / zainstaluj moduł tła' if self.remover.ready() else 'Zainstaluj moduł tła (jednorazowo)')

    def changed(self):
        self.result=None
        self.status.configure(text='Ustawienia zmienione — kliknij „Przygotuj podgląd”.')
        self.controls();self.draw()

    def draw(self,_event=None):
        if self.closed:return
        for canvas,image in zip(self.canvases,(self.original,self.result)):
            canvas.delete('all')
            if image is not None:
                fitted=ImageOps.contain(image,(max(1,canvas.winfo_width()-16),max(1,canvas.winfo_height()-16)))
                canvas.photo=ImageTk.PhotoImage(fitted,master=self)
                canvas.create_image(canvas.winfo_width()/2,canvas.winfo_height()/2,image=canvas.photo)
            else:
                canvas.photo=None
                canvas.create_text(canvas.winfo_width()/2,canvas.winfo_height()/2,text='Przygotuj podgląd',fill='#969eaf')

    def start(self, work, kind):
        if self.busy:return
        self.busy=True;self.cancel.clear();self.controls()
        def worker():
            try:self.events.put(('done',kind,work(),None))
            except Exception as exc:self.events.put(('done',kind,None,str(exc)))
        threading.Thread(target=worker,daemon=True).start()

    def progress(self,text):self.events.put(('progress',text))

    def install(self):
        self.start(lambda:self.remover.install(self.cancel,self.progress),'install')

    def prepare(self):
        if self.busy:return
        if self.remove_bg.get() and not self.remover.ready():
            self.status.configure(text='Kliknij „Zainstaluj moduł tła”. Pobieranie wymaga internetu i może potrwać kilka minut.')
            return
        use_remove=self.remove_bg.get(); margin=int(self.margin.get())
        self.result=None;self.status.configure(text='Przygotowuję podgląd…')
        def work():
            image=self.original
            if use_remove:
                if self.cutout is None:
                    source=self.folder/'input.png';target=self.folder/'cutout.png'
                    self.original.save(source)
                    self.remover.remove(source,target,self.cancel,self.progress)
                    self.cutout=read_image(target,(2048,2048))
                image=self.cutout
            if self.cancel.is_set():raise ImportCancelled('Anulowano. Galeria pozostała bez zmian.')
            return compose_white(image,margin)
        self.start(work,'prepare')

    def save(self):
        if self.busy or self.result is None:return
        if self.app.photo_importing or self.app.busy_id==self.product_id:
            messagebox.showinfo('Operacja w toku','Poczekaj na zakończenie importu lub analizy produktu.',parent=self);return
        destination=self.folder/f'SS-{self.product_id:05d}_biale_tlo.png'
        self.result.save(destination,format='PNG')
        origin={str(destination):{'source_page':self.photo['source_page'],'source_image':self.photo['source_image'],
            'original_file':self.app.gallery.resolve(self.photo['original_relative_path']) if self.photo['original_relative_path'] else None,
            'localization_language':self.photo['localization_language']}}
        self.app.photo_importing=True
        self.start(lambda:self.app.gallery.add(self.product_id,[destination],self.cancel,origins=origin),'save')

    def poll(self):
        if self.closed:return
        try:
            while True:
                event=self.events.get_nowait()
                if event[0]=='progress':self.status.configure(text=event[1]);continue
                _,kind,result,error=event
                self.busy=False
                if kind=='save':
                    self.app.photo_importing=False
                    self.app.photos_changed(self.product_id)
                if error:
                    self.status.configure(text=error)
                    if not self.cancel.is_set():messagebox.showerror('Przygotowanie zdjęcia',error,parent=self)
                elif kind=='install':self.status.configure(text='Moduł gotowy. Zaznacz usuwanie tła i przygotuj podgląd.')
                elif kind=='prepare':
                    self.result=result
                    self.status.configure(text='Sprawdź wynik. „Dodaj kopię” zapisze nowe zdjęcie; oryginał pozostanie w galerii.')
                    self.draw()
                elif kind=='save':
                    added,skipped=result
                    self.status.configure(text='Zapisano kopię w galerii. Możesz ustawić ją jako główną.' if added else 'Identyczna kopia już jest w galerii.')
                    self.result=None
                self.controls()
        except queue.Empty:pass
        self.after(80,self.poll)

    def close(self):
        if self.busy:
            self.cancel.set();self.status.configure(text='Anuluję operację. Poczekaj na jej zakończenie…');return
        self.closed=True
        self.original.close()
        if self.cutout is not None:self.cutout.close()
        if self.result is not None:self.result.close()
        self.temp.cleanup()
        self.grab_release()
        self.destroy()
