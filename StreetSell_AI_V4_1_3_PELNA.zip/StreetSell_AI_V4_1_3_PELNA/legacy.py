import csv
import json
import re
import sqlite3
import threading
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent
DB_PATH = APP_DIR / "streetsell.db"
MODEL = "gpt-5.5"

COLUMN_ALIASES = {
    "name": ["nazwa", "name", "product name", "title"],
    "ean": ["ean", "gtin", "barcode"],
    "asin": ["asin", "kod 2", "amazon asin"],
    "sku": ["fcsku", "fnsku", "kod 1", "sku"],
    "category": ["kategoria", "category"],
    "qty": ["pcs", "quantity", "qty", "ilość", "ilosc"],
    "price_gross": ["cena regularna brutto", "gross price", "price"],
    "price_net": ["cena sprzedaży netto", "cena sprzedazy netto", "net price"],
    "link": ["link", "url", "product url"],
}

def norm(value):
    return str(value or "").strip().lower().replace("_", " ")

def find_col(headers, aliases):
    normalized = {norm(h): h for h in headers}
    for alias in aliases:
        if norm(alias) in normalized:
            return normalized[norm(alias)]
    for h in headers:
        if any(norm(alias) in norm(h) for alias in aliases):
            return h
    return None

def init_db(path=None):
    with sqlite3.connect(DB_PATH if path is None else path) as con:
        con.execute("""
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source_file TEXT,
            product_name TEXT,
            asin TEXT,
            ean TEXT,
            sku TEXT,
            category TEXT,
            quantity INTEGER DEFAULT 1,
            gross_price TEXT,
            net_price TEXT,
            status TEXT DEFAULT 'Do weryfikacji'
        )
        """)
        existing = {r[1] for r in con.execute("PRAGMA table_info(products)")}
        additions = {
            "product_link": "TEXT DEFAULT ''",
            "generated_title": "TEXT DEFAULT ''",
            "generated_description": "TEXT DEFAULT ''",
            "research_notes": "TEXT DEFAULT ''",
            "ai_status": "TEXT DEFAULT 'Nie analizowano'",
        }
        for name, sql_type in additions.items():
            if name not in existing:
                con.execute(f"ALTER TABLE products ADD COLUMN {name} {sql_type}")

def get_api_key():
    try:
        import keyring
        return keyring.get_password("StreetSellAI", "openai_api_key")
    except Exception:
        return None

def save_api_key(value):
    import keyring
    keyring.set_password("StreetSellAI", "openai_api_key", value.strip())

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("StreetSell AI — Import palet + AI (V2)")
        self.geometry("1360x820")
        self.minsize(1050, 650)
        self.selected_id = None
        init_db()
        self._build_ui()
        self.load_db()

    def _build_ui(self):
        top = ttk.Frame(self, padding=12)
        top.pack(fill="x")
        ttk.Label(top, text="StreetSell AI", font=("Segoe UI", 20, "bold")).pack(side="left")
        ttk.Label(top, text="V2 • Import palet Amazon + analiza AI", font=("Segoe UI", 10)).pack(side="left", padx=16)

        actions = ttk.Frame(self, padding=(12, 0, 12, 10))
        actions.pack(fill="x")
        ttk.Button(actions, text="Wczytaj Excel / CSV", command=self.import_file).pack(side="left")
        ttk.Button(actions, text="Ustaw klucz OpenAI", command=self.configure_key).pack(side="left", padx=7)
        ttk.Button(actions, text="Analizuj zaznaczony produkt", command=self.analyze_selected).pack(side="left")
        ttk.Button(actions, text="Eksportuj CSV", command=self.export_csv).pack(side="left", padx=7)
        ttk.Button(actions, text="Odśwież", command=self.load_db).pack(side="left")
        self.summary = ttk.Label(actions, text="Wczytaj specyfikację palety.")
        self.summary.pack(side="right")

        ttk.Label(self, text="ETAP 2: analiza produktu przez AI z wyszukiwaniem internetowym. Analizuj pojedynczo i sprawdzaj wynik przed wystawieniem.",
                  padding=(12, 0, 12, 8), foreground="#444").pack(fill="x")

        main = ttk.Panedwindow(self, orient="vertical")
        main.pack(fill="both", expand=True, padx=12, pady=(0, 10))

        table_frame = ttk.Frame(main)
        cols = ("name", "asin", "ean", "qty", "category", "sku", "ai_status")
        self.tree = ttk.Treeview(table_frame, columns=cols, show="headings", height=17, selectmode="browse")
        labels = {"name":"Produkt z palety", "asin":"ASIN", "ean":"EAN z pliku", "qty":"Szt.", "category":"Kategoria", "sku":"SKU / kod", "ai_status":"Analiza AI"}
        widths = {"name":480, "asin":125, "ean":130, "qty":50, "category":140, "sku":145, "ai_status":145}
        for c in cols:
            self.tree.heading(c, text=labels[c])
            self.tree.column(c, width=widths[c], anchor="w")
        yscroll = ttk.Scrollbar(table_frame, orient="vertical", command=self.tree.yview)
        xscroll = ttk.Scrollbar(table_frame, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=yscroll.set, xscrollcommand=xscroll.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        yscroll.grid(row=0, column=1, sticky="ns")
        xscroll.grid(row=1, column=0, sticky="ew")
        table_frame.rowconfigure(0, weight=1)
        table_frame.columnconfigure(0, weight=1)
        self.tree.bind("<<TreeviewSelect>>", self.on_select)
        main.add(table_frame, weight=3)

        detail = ttk.Frame(main, padding=8)
        ttk.Label(detail, text="Wygenerowany tytuł Allegro", font=("Segoe UI", 10, "bold")).pack(anchor="w")
        self.title_box = tk.Text(detail, height=2, wrap="word")
        self.title_box.pack(fill="x", pady=(3, 8))
        ttk.Label(detail, text="Opis produktu", font=("Segoe UI", 10, "bold")).pack(anchor="w")
        self.description_box = tk.Text(detail, height=9, wrap="word")
        self.description_box.pack(fill="both", expand=True, pady=(3, 8))
        ttk.Label(detail, text="Notatki z wyszukiwania / źródła", font=("Segoe UI", 10, "bold")).pack(anchor="w")
        self.notes_box = tk.Text(detail, height=4, wrap="word")
        self.notes_box.pack(fill="x", pady=(3, 0))
        main.add(detail, weight=2)

        self.statusbar = ttk.Label(self, text="Gotowy. Najpierw ustaw klucz API OpenAI, potem zaznacz produkt i kliknij analizę.", padding=(12, 4), foreground="#555")
        self.statusbar.pack(fill="x")

    def configure_key(self):
        win = tk.Toplevel(self)
        win.title("Klucz OpenAI API")
        win.geometry("560x190")
        win.transient(self)
        win.grab_set()
        ttk.Label(win, text="Wklej klucz API OpenAI:", padding=(12, 12)).pack(anchor="w")
        entry = ttk.Entry(win, show="*", width=75)
        entry.pack(fill="x", padx=12)
        existing = get_api_key()
        if existing:
            entry.insert(0, existing)
        ttk.Label(win, text="Klucz zostanie zapisany w magazynie poświadczeń Windows (jeśli dostępny). API jest rozliczane osobno od abonamentu ChatGPT.",
                  wraplength=520, foreground="#555", padding=12).pack(anchor="w")
        def save():
            key = entry.get().strip()
            if not key:
                messagebox.showwarning("Brak klucza", "Wklej klucz API.", parent=win)
                return
            try:
                save_api_key(key)
                messagebox.showinfo("Zapisano", "Klucz API zapisany.", parent=win)
                win.destroy()
            except Exception as exc:
                messagebox.showerror("Nie udało się zapisać", f"Nie można zapisać klucza w magazynie Windows.\n{exc}", parent=win)
        ttk.Button(win, text="Zapisz klucz", command=save).pack(anchor="e", padx=12, pady=8)

    def import_file(self):
        path = filedialog.askopenfilename(
            title="Wybierz specyfikację palety",
            filetypes=[("Pliki Excel", "*.xlsx *.xls"), ("Pliki CSV", "*.csv"), ("Wszystkie pliki", "*.*")]
        )
        if not path:
            return
        try:
            if path.lower().endswith(".csv"):
                with open(path, "r", encoding="utf-8-sig", newline="") as f:
                    sample = f.read(4096); f.seek(0)
                    try: dialect = csv.Sniffer().sniff(sample, delimiters=";,\t")
                    except csv.Error: dialect = csv.excel
                    raw = list(csv.DictReader(f, dialect=dialect))
                headers, rows = (list(raw[0].keys()) if raw else []), raw
            elif path.lower().endswith((".xlsx", ".xls")):
                import pandas as pd
                book = pd.ExcelFile(path)
                df = pd.read_excel(path, sheet_name=book.sheet_names[0], dtype=str).fillna("")
                headers, rows = list(df.columns), df.to_dict(orient="records")
            else:
                messagebox.showerror("Nieobsługiwany plik", "Wybierz plik .xlsx lub .csv."); return
            if not rows:
                messagebox.showwarning("Pusty plik", "Nie znaleziono wierszy z produktami."); return
            mapped = {key: find_col(headers, aliases) for key, aliases in COLUMN_ALIASES.items()}
            inserted = 0
            with sqlite3.connect(DB_PATH) as con:
                for row in rows:
                    def get(key):
                        col = mapped.get(key)
                        return str(row.get(col, "") or "").strip() if col else ""
                    name, asin = get("name"), get("asin")
                    if not name and not asin: continue
                    try: qty = int(float(get("qty").replace(",", "."))) if get("qty") else 1
                    except ValueError: qty = 1
                    con.execute("""INSERT INTO products
                        (source_file, product_name, asin, ean, sku, category, quantity, gross_price, net_price, status, product_link)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                        (Path(path).name, name, asin, get("ean"), get("sku"), get("category"), max(qty,1),
                         get("price_gross"), get("price_net"), "Do weryfikacji", get("link")))
                    inserted += 1
            self.load_db()
            messagebox.showinfo("Import zakończony", f"Zaimportowano {inserted} wierszy z pliku:\n{Path(path).name}")
        except Exception as exc:
            messagebox.showerror("Błąd importu", f"Nie udało się wczytać pliku.\n\nSzczegóły: {exc}")

    def load_db(self):
        for item in self.tree.get_children(): self.tree.delete(item)
        with sqlite3.connect(DB_PATH) as con:
            rows = con.execute("""SELECT id, product_name, asin, ean, quantity, category, sku, ai_status
                                  FROM products ORDER BY id DESC""").fetchall()
            unique_asins = len({r[2] for r in rows if r[2]})
            total_qty = sum((r[4] or 1) for r in rows)
        for r in rows:
            self.tree.insert("", "end", iid=str(r[0]), values=(r[1],r[2],r[3],r[4],r[5],r[6],r[7]))
        self.summary.config(text=f"Wiersze: {len(rows)} • różne ASIN-y: {unique_asins} • sztuki: {total_qty}")

    def on_select(self, _event=None):
        selected = self.tree.selection()
        if not selected: return
        self.selected_id = int(selected[0])
        with sqlite3.connect(DB_PATH) as con:
            row = con.execute("SELECT generated_title, generated_description, research_notes FROM products WHERE id=?", (self.selected_id,)).fetchone()
        self._set_text(self.title_box, row[0] or "")
        self._set_text(self.description_box, row[1] or "")
        self._set_text(self.notes_box, row[2] or "")

    @staticmethod
    def _set_text(widget, value):
        widget.delete("1.0", "end")
        widget.insert("1.0", value)

    def analyze_selected(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("Wybierz produkt", "Zaznacz jeden produkt w tabeli."); return
        key = get_api_key()
        if not key:
            messagebox.showwarning("Brak klucza API", "Najpierw kliknij „Ustaw klucz OpenAI” i zapisz swój klucz API."); return
        product_id = int(selected[0])
        with sqlite3.connect(DB_PATH) as con:
            row = con.execute("""SELECT product_name, asin, ean, category, product_link
                                 FROM products WHERE id=?""", (product_id,)).fetchone()
        self.statusbar.config(text="Trwa wyszukiwanie informacji i tworzenie propozycji…")
        self.tree.set(str(product_id), "ai_status", "Analizuję…")
        threading.Thread(target=self._analyze_worker, args=(product_id, row, key), daemon=True).start()

    def _analyze_worker(self, product_id, row, key):
        try:
            from openai import OpenAI
            name, asin, ean, category, link = row
            client = OpenAI(api_key=key, timeout=120)
            prompt = f"""
Przygotuj roboczą kartę produktu do polskiej oferty Allegro. Najpierw użyj wyszukiwania internetowego,
aby zidentyfikować dokładny produkt. Priorytet: ASIN i dokładny model/wariant, następnie strona producenta
i wiarygodne sklepy. Nie utożsamiaj podobnych modeli. Nie wymyślaj parametrów, wymiarów, zawartości zestawu,
EAN ani certyfikatów. Jeżeli nie da się czegoś potwierdzić, napisz, że brak potwierdzenia.
Dane z palety:
Nazwa: {name}
ASIN: {asin}
EAN z pliku (niezweryfikowany): {ean}
Kategoria: {category}
Link z pliku: {link}

Zwróć wyłącznie poprawny JSON z kluczami:
"title": krótki, konkretny tytuł Allegro po polsku, bez marki/modelu jeśli nie są potwierdzone;
"description": atrakcyjny, rzeczowy opis po polsku, bez niepotwierdzonych obietnic;
"verified_ean": EAN wyłącznie jeśli źródło potwierdza dokładnie ten produkt/wariant, w przeciwnym razie pusty tekst;
"product_match": krótkie wyjaśnienie, czy znaleziony produkt jest dokładnym dopasowaniem;
"facts": lista potwierdzonych cech; każda cecha ma wynikać ze źródeł;
"uncertain": lista danych, których nie udało się potwierdzić;
"sources": lista adresów URL i krótkich nazw źródeł.
W opisie nie dodawaj fikcyjnych parametrów. Jeśli źródła są sprzeczne, opisz rozbieżność.
"""
            response = client.responses.create(
                model=MODEL,
                tools=[{"type": "web_search"}],
                input=prompt,
            )
            # Web Search nie współpracuje tutaj z wymuszonym JSON mode.
            # Prosimy model o JSON w treści i bezpiecznie wyciągamy obiekt z odpowiedzi.
            output_text = (response.output_text or "").strip()
            if output_text.startswith("```"):
                output_text = re.sub(r"^```(?:json)?\s*", "", output_text, flags=re.IGNORECASE)
                output_text = re.sub(r"\s*```$", "", output_text)
            try:
                data = json.loads(output_text)
            except json.JSONDecodeError:
                start = output_text.find("{")
                end = output_text.rfind("}")
                if start < 0 or end <= start:
                    raise ValueError(
                        "AI nie zwróciło poprawnego obiektu JSON. Spróbuj ponownie lub sprawdź produkt."
                    )
                data = json.loads(output_text[start:end + 1])
            if not isinstance(data, dict):
                raise ValueError("Odpowiedź AI ma nieoczekiwany format.")
            title = str(data.get("title","")).strip()
            description = str(data.get("description","")).strip()
            if not title or not description:
                raise ValueError("AI zwróciło pusty tytuł lub opis. Wcześniejszy szkic zachowano.")
            for field in ("facts", "uncertain", "sources"):
                if not isinstance(data.get(field, []), list):
                    raise ValueError("Odpowiedź AI ma nieprawidłową listę: " + field)
            verified_ean = str(data.get("verified_ean","")).strip()
            notes = (
                "DOPASOWANIE: " + str(data.get("product_match","")) + "\n\n"
                "POTWIERDZONE CECHY:\n- " + "\n- ".join(map(str, data.get("facts",[]))) + "\n\n"
                "NIEPEWNE / BRAK POTWIERDZENIA:\n- " + "\n- ".join(map(str, data.get("uncertain",[]))) + "\n\n"
                "ŹRÓDŁA:\n" + "\n".join(map(str, data.get("sources",[])))
            )
            with sqlite3.connect(DB_PATH) as con:
                old_ean = con.execute("SELECT ean FROM products WHERE id=?", (product_id,)).fetchone()[0]
                # Do not silently replace the pallet EAN. Save a web-confirmed EAN only when the source agrees exactly.
                final_ean = verified_ean if verified_ean and verified_ean == str(old_ean or "").strip() else old_ean
                con.execute("""UPDATE products SET generated_title=?, generated_description=?, research_notes=?,
                               ai_status=?, ean=? WHERE id=?""",
                             (title, description, notes, "Przygotowano szkic", final_ean, product_id))
            self.after(0, lambda: self._analysis_done(product_id, None))
        except Exception as exc:
            self.after(0, lambda err=str(exc): self._analysis_done(product_id, err))

    def _analysis_done(self, product_id, error):
        if error:
            self.tree.set(str(product_id), "ai_status", "Błąd analizy")
            self.statusbar.config(text="Analiza nie powiodła się.")
            messagebox.showerror("Błąd analizy AI", f"{error}\n\nSprawdź klucz API, połączenie internetowe i dostęp do modelu.")
        else:
            self.load_db()
            self.tree.selection_set(str(product_id))
            self.tree.see(str(product_id))
            self.on_select()
            self.statusbar.config(text="Gotowy szkic zapisany. Sprawdź dopasowanie, EAN i źródła przed użyciem na Allegro.")
            messagebox.showinfo("Analiza zakończona", "Utworzono roboczy tytuł i opis. EAN nie jest automatycznie podmieniany — sprawdź źródła i dokładny wariant.")

    def export_csv(self):
        path = filedialog.asksaveasfilename(title="Zapisz eksport produktów", defaultextension=".csv", filetypes=[("CSV", "*.csv")])
        if not path: return
        with sqlite3.connect(DB_PATH) as con:
            rows = con.execute("""SELECT product_name, asin, ean, quantity, category, sku, gross_price, net_price,
                                  generated_title, generated_description, research_notes, ai_status
                                  FROM products ORDER BY id""").fetchall()
        headers = ["Nazwa z palety","ASIN","EAN z palety","Ilość","Kategoria","SKU / kod","Cena regularna brutto",
                   "Cena sprzedaży netto","Tytuł Allegro - szkic","Opis Allegro - szkic","Weryfikacja / źródła","Status AI"]
        with open(path, "w", encoding="utf-8-sig", newline="") as f:
            writer = csv.writer(f, delimiter=";"); writer.writerow(headers); writer.writerows(rows)
        messagebox.showinfo("Eksport gotowy", f"Zapisano {len(rows)} produktów:\n{path}")

if __name__ == "__main__":
    App().mainloop()
