"""Allegro OAuth Device Flow. Bez zapisu sekretów do plików i bazy produktów.

Źródła: developer.allegro.pl/tutorials/uwierzytelnianie-i-autoryzacja-zlq9e75GdIR
oraz developer.allegro.pl/tutorials/informacje-podstawowe-b21569boAI1.
Jeden Client ID własnej aplikacji; logowanie sprzedawcy przez zgodę OAuth.
"""
import base64
import json
import math
import os
import re
import secrets
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

ENVIRONMENTS = {
    'production': ('https://allegro.pl', 'https://api.allegro.pl', 'https://apps.developer.allegro.pl'),
    'sandbox': ('https://allegro.pl.allegrosandbox.pl', 'https://api.allegro.pl.allegrosandbox.pl',
                'https://apps.developer.allegro.pl.allegrosandbox.pl'),
}
CLIENT_LOCKS = {env:threading.RLock() for env in ENVIRONMENTS}
SCOPE = 'allegro:api:profile:read allegro:api:orders:read allegro:api:sale:offers:read allegro:api:sale:offers:write allegro:api:sale:settings:read'
KNOWN_ERRORS = {'authorization_pending', 'slow_down', 'access_denied', 'expired_token',
                'invalid_grant', 'invalid_client', 'invalid_scope', 'invalid_request',
                'unauthorized_client', 'unsupported_grant_type', 'invalid_token'}

class AllegroError(Exception):
    pass

class Cancelled(AllegroError):
    def __init__(self):
        super().__init__('Przerwano łączenie konta.')

class ApiError(AllegroError):
    def __init__(self, status=0, code='api_error'):
        self.status = status
        self.code = code if isinstance(code, str) and code in KNOWN_ERRORS else 'api_error'
        messages = {
            'invalid_client': 'Allegro nie rozpoznało aplikacji. Sprawdź Client ID, Client Secret i środowisko.',
            'invalid_grant': 'Dostęp wygasł lub został cofnięty. Połącz konto ponownie.',
            'invalid_token': 'Dostęp wygasł lub został cofnięty. Połącz konto ponownie.',
            'access_denied': 'Nie udzielono zgody na połączenie z Allegro.',
            'expired_token': 'Kod logowania wygasł. Rozpocznij łączenie ponownie.',
            'invalid_scope': 'Sprawdź uprawnienia konta, zamówień, odczytu i zapisu ofert oraz odczytu ustawień sprzedaży w konfiguracji aplikacji Allegro.',
            'unauthorized_client': 'Sprawdź, czy aplikacja Allegro została zarejestrowana jako Device Flow.',
        }
        fallback = {401:'Brak ważnego dostępu do konta. Połącz konto ponownie.',
                    403:'Brak dostępu. Sprawdź uprawnienia aplikacji oraz jej User-Agent.',
                    429:'Allegro ograniczyło liczbę zapytań. Spróbuj ponownie za chwilę.'}
        super().__init__(messages.get(self.code, fallback.get(status,
            f'Allegro zwróciło błąd HTTP {status}. Spróbuj ponownie lub sprawdź konfigurację.')))

class WindowsVault:
    """Podział na krótkie wpisy WinVault; manifest zmieniany po zapisie całości.

    Jeden rekord JSON może zawierać długie tokeny JWT. Każdy fragment ma <=900
    znaków ASCII i mieści się w limicie Windows Credential Manager.
    """
    def __init__(self, backend=None):
        if backend is not None:
            self.backend = backend
        else:
            if os.name != 'nt':
                raise AllegroError('Bezpieczny zapis połączenia Allegro jest dostępny w tej wersji na Windows.')
            try:
                from keyring.backends.Windows import WinVaultKeyring
                self.backend = WinVaultKeyring()
            except Exception:
                raise AllegroError('Nie można otworzyć magazynu poświadczeń Windows. Uruchom install.bat.') from None
        self.lock = threading.RLock()

    def _name(self, env, key):
        if env not in ENVIRONMENTS:
            raise AllegroError('Nieprawidłowe środowisko Allegro.')
        return f'StreetSellAI.Allegro.{env}.{key}'

    def _get(self, env, key):
        return self.backend.get_password(self._name(env, key), 'connection')

    def _put(self, env, key, text):
        self.backend.set_password(self._name(env, key), 'connection', text)

    def _manifest(self, env):
        raw = self._get(env, 'manifest')
        if not raw:
            return None
        data = json.loads(raw)
        if (not isinstance(data, dict) or not re.fullmatch('[a-f0-9]{24}', str(data.get('generation', '')))
            or type(data.get('count')) is not int or not 1 <= data['count'] <= 128):
            raise ValueError('Invalid vault manifest')
        return data

    def _cleanup(self, env, manifest):
        if manifest:
            for i in range(manifest['count']):
                try:
                    self.backend.delete_password(self._name(env, f"{manifest['generation']}.{i}"), 'connection')
                except Exception:
                    pass  # Pozostałość pozostaje zaszyfrowana w WinVault.

    def load(self, env):
        with self.lock:
            try:
                index = self._manifest(env)
                if not index:
                    return {}
                parts = [self._get(env, f"{index['generation']}.{i}") for i in range(index['count'])]
                if any(not isinstance(p, str) for p in parts):
                    raise ValueError('Incomplete vault')
                data = json.loads(''.join(parts))
                if not isinstance(data, dict):
                    raise ValueError('Invalid vault')
                return data
            except Exception:
                raise AllegroError('Nie można odczytać połączenia z magazynu poświadczeń Windows.') from None

    def save(self, env, data):
        with self.lock:
            try:
                old = self._manifest(env)
                text = json.dumps(data, ensure_ascii=True, separators=(',', ':'), allow_nan=False)
                if len(text) > 115200:
                    raise ValueError('Vault record too large')
                index = {'generation': secrets.token_hex(12), 'count': max(1, (len(text) + 899) // 900)}
                written = 0
                try:
                    for i in range(index['count']):
                        self._put(env, f"{index['generation']}.{i}", text[i*900:(i+1)*900])
                        written += 1
                    self._put(env, 'manifest', json.dumps(index))
                except Exception:
                    self._cleanup(env, {**index, 'count': written})
                    raise
                self._cleanup(env, old)
            except Exception:
                raise AllegroError('Nie udało się bezpiecznie zapisać dostępu w Windows. Spróbuj ponownie.') from None

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None  # Nie przenosimy nagłówków z tokenami na inne adresy.

class Transport:
    def __init__(self):
        self.opener = urllib.request.build_opener(NoRedirect())

    def request(self, url, method, headers, fields=None):
        allowed = {urllib.parse.urlsplit(u).hostname for values in ENVIRONMENTS.values() for u in values[:2]}
        parsed = urllib.parse.urlsplit(url)
        if parsed.scheme != 'https' or parsed.hostname not in allowed or parsed.username or parsed.password or parsed.port not in (None, 443):
            raise AllegroError('Nieprawidłowy adres serwera Allegro.')
        data = urllib.parse.urlencode(fields).encode('utf-8') if fields is not None else None
        request = urllib.request.Request(url, data=data, headers=headers, method=method)
        try:
            with self.opener.open(request, timeout=20) as response:
                raw = response.read(1024*1024 + 1)
                if len(raw) > 1024*1024:
                    raise AllegroError('Odpowiedź Allegro jest zbyt duża.')
                result = json.loads(raw)
                if not isinstance(result, dict):
                    raise ValueError('Invalid JSON type')
                return result
        except urllib.error.HTTPError as exc:
            try:
                payload = json.loads(exc.read(16384))
                code = payload.get('error', '') if isinstance(payload, dict) else ''
            except Exception:
                code = ''
            finally:
                exc.close()
            raise ApiError(exc.code, code) from None
        except (urllib.error.URLError, TimeoutError, OSError):
            raise AllegroError('Nie udało się połączyć z Allegro. Sprawdź internet i spróbuj ponownie.') from None
        except (ValueError, UnicodeError):
            raise AllegroError('Allegro zwróciło odpowiedź w nieoczekiwanym formacie.') from None


def validate_config(client_id, client_secret, user_agent):
    client_id, client_secret, user_agent = client_id.strip(), client_secret.strip(), user_agent.strip()
    if not re.fullmatch('[A-Za-z0-9_-]{8,200}', client_id) or ':' in client_id:
        raise AllegroError('Wklej pełny Client ID własnej aplikacji Allegro.')
    if not client_secret or len(client_secret) > 1024 or any(c.isspace() for c in client_secret):
        raise AllegroError('Wklej pełny Client Secret własnej aplikacji Allegro.')
    if (len(user_agent) > 500 or not re.fullmatch(r'[A-Za-z0-9._-]+/[A-Za-z0-9._-]+ \(\+https?://[^\s()]+\)', user_agent)
        or not user_agent.isascii()):
        raise AllegroError('Wklej User-Agent z kreatora Allegro, w formacie Nazwa/Wersja (+https://adres-informacji).')
    return dict(client_id=client_id, client_secret=client_secret, user_agent=user_agent)


class AllegroClient:
    def __init__(self, env='production', vault=None, transport=None, now=time.time, monotonic=time.monotonic):
        if env not in ENVIRONMENTS:
            raise AllegroError('Nieprawidłowe środowisko Allegro.')
        self.env = env
        self.auth_url, self.api_url, self.apps_url = ENVIRONMENTS[env]
        self.vault = vault if vault is not None else WindowsVault()
        self.transport = transport if transport is not None else Transport()
        self.now, self.monotonic = now, monotonic
        self.lock = CLIENT_LOCKS[env]

    def state(self):
        return self.vault.load(self.env)

    def configure(self, client_id, client_secret, user_agent):
        config = validate_config(client_id, client_secret, user_agent)
        with self.lock:
            old = self.state()
            # Zmiana tożsamości aplikacji nigdy nie odziedziczy jej tokenów.
            if (old.get('config', {}).get('client_id'), old.get('config', {}).get('client_secret')) != (config['client_id'], config['client_secret']):
                old = {}
            old['config'] = config
            self.vault.save(self.env, old)

    def _config(self):
        values = self.state().get('config', {})
        if not isinstance(values, dict):
            raise AllegroError('Najpierw skonfiguruj własną aplikację Allegro.')
        try:
            return validate_config(values.get('client_id', ''), values.get('client_secret', ''), values.get('user_agent', ''))
        except AllegroError:
            raise AllegroError('Najpierw uzupełnij zakładkę Konfiguracja aplikacji.') from None

    def _headers(self, config, token=None):
        headers = {'User-Agent':config['user_agent'], 'Accept-Language':'pl-PL'}
        if token is None:
            basic = base64.b64encode((config['client_id'] + ':' + config['client_secret']).encode()).decode('ascii')
            headers.update(Authorization='Basic ' + basic, Accept='application/json',
                           **{'Content-Type':'application/x-www-form-urlencoded'})
        else:
            headers.update(Authorization='Bearer ' + token, Accept='application/vnd.allegro.public.v1+json')
        return headers

    @staticmethod
    def _device_problem(reason):
        # Wyłącznie stały kod diagnostyczny: bez odpowiedzi API i kodów autoryzacji.
        return AllegroError('Nie udało się odczytać danych logowania Allegro. '
                            'Kod diagnostyczny: ' + reason + '. Przekaż ten kod do sprawdzenia.')

    def _verification_url(self, value):
        if not isinstance(value, str) or not value.strip() or len(value) > 8192:
            raise self._device_problem('DEVICE-URL-FORMAT')
        value = value.strip()
        if any(ord(c) < 32 or c.isspace() for c in value) or '\\' in value:
            raise self._device_problem('DEVICE-URL-FORMAT')
        try:
            parsed = urllib.parse.urlsplit(value)
            expected = urllib.parse.urlsplit(self.auth_url).hostname
            # Odbierany URL prowadzi do strony logowania, nie do endpointu API.
            # Nie zakładamy konkretnej ścieżki z przykładu dokumentacji.
            if (parsed.scheme.lower() != 'https' or parsed.hostname != expected
                or parsed.username is not None or parsed.password is not None
                or parsed.port not in (None, 443) or parsed.fragment):
                raise ValueError()
        except ValueError:
            raise self._device_problem('DEVICE-URL-ORIGIN') from None
        return value

    def begin_device(self):
        config = self._config()
        result = self.transport.request(self.auth_url + '/auth/oauth/device', 'POST', self._headers(config),
                                        {'client_id':config['client_id'], 'scope':SCOPE})
        if not isinstance(result, dict):
            raise self._device_problem('DEVICE-OBJECT')
        codes = {}
        for key, reason in (('device_code', 'DEVICE-CODE'), ('user_code', 'DEVICE-USER-CODE')):
            value = result.get(key)
            # Akceptujemy także dodatni identyfikator całkowity, nigdy bool/listę/float.
            if type(value) is int and value >= 0:
                value = str(value)
            if not isinstance(value, str) or not value.strip() or len(value) > 8192:
                raise self._device_problem(reason)
            codes[key] = value.strip()
        try:
            raw_expiry = result.get('expires_in')
            raw_interval = result.get('interval')
            expiry = float(raw_expiry) if type(raw_expiry) in (str, int, float) else 0
            interval = 5 if raw_interval is None else (float(raw_interval) if type(raw_interval) in (str, int, float) else 0)
            if not math.isfinite(expiry) or expiry <= 0 or not math.isfinite(interval) or interval <= 0:
                raise ValueError()
            expiry, interval = math.ceil(expiry), math.ceil(interval)
        except (TypeError, ValueError, OverflowError):
            raise self._device_problem('DEVICE-TIMING') from None
        base = result.get('verification_uri')
        complete = result.get('verification_uri_complete')
        # Wystarczy dostępny zaufany URL; wariant bez kodu jest używany ręcznie.
        if not base and not complete:
            raise self._device_problem('DEVICE-URL-MISSING')
        if base:
            base = self._verification_url(base)
        if complete:
            complete = self._verification_url(complete)
        return {**codes, 'verification_uri':base or complete,
                'verification_uri_complete':complete,
                'expires_in':expiry, 'interval':interval,
                'open_url':complete or base, 'deadline':self.monotonic() + expiry}

    def _save_tokens(self, result):
        try:
            access, refresh = result['access_token'], result['refresh_token']
            expires = float(result['expires_in'])
            if (not isinstance(access, str) or not access or not isinstance(refresh, str) or not refresh
                or not math.isfinite(expires) or expires <= 0
                or str(result.get('token_type', 'bearer')).lower() != 'bearer'):
                raise ValueError()
            if any(c.isspace() for c in access + refresh):
                raise ValueError()
        except (KeyError, TypeError, ValueError):
            raise AllegroError('Allegro zwróciło niepełne dane dostępu. Połącz konto ponownie.') from None
        state = self.state()
        state.update(tokens={'access_token':access, 'refresh_token':refresh,
                             'expires_at':self.now() + expires}, profile=None, verified_at=None)
        self.vault.save(self.env, state)  # Zapis nowego refresh tokena PRZED kolejnym żądaniem.
        return access

    def complete_device(self, device, cancel, on_slow=None):
        config = self._config()
        interval = device['interval']
        while self.monotonic() < device['deadline']:
            remaining = device['deadline'] - self.monotonic()
            if cancel.wait(min(interval, max(0, remaining))):
                raise Cancelled()
            if self.monotonic() >= device['deadline']:
                break
            try:
                result = self.transport.request(self.auth_url + '/auth/oauth/token', 'POST', self._headers(config),
                    {'grant_type':'urn:ietf:params:oauth:grant-type:device_code', 'device_code':device['device_code']})
            except ApiError as exc:
                if exc.code == 'authorization_pending':
                    continue
                if exc.code == 'slow_down':
                    interval += 5
                    if on_slow:
                        on_slow()
                    continue
                raise
            if cancel.is_set():
                raise Cancelled()
            with self.lock:
                self._save_tokens(result)
            return self.profile()
        raise AllegroError('Kod logowania wygasł. Kliknij Połącz konto, aby otrzymać nowy kod.')

    def profile(self):
        with self.lock:
            config = self._config()
            tokens = self.state().get('tokens') or {}
            if not tokens.get('access_token'):
                raise AllegroError('Brak połączonego konta. Kliknij Połącz konto Allegro.')
            try:
                expiry = float(tokens.get('expires_at', 0))
            except (ValueError, TypeError):
                expiry = 0
            access = tokens['access_token']
            refreshed = False
            if not math.isfinite(expiry) or expiry <= self.now() + 60:
                access = self._refresh(config, tokens)
                refreshed = True
            try:
                result = self.transport.request(self.api_url + '/me', 'GET', self._headers(config, access))
            except ApiError as exc:
                if exc.status != 401 or refreshed:
                    raise
                access = self._refresh(config, tokens)
                result = self.transport.request(self.api_url + '/me', 'GET', self._headers(config, access))
            if not isinstance(result.get('id'), str) or not result.get('id') or not isinstance(result.get('login'), str) or not result.get('login'):
                raise AllegroError('Nie udało się potwierdzić tożsamości konta Allegro.')
            company = result.get('company') or {}
            profile = {'id':result['id'], 'login':result['login'],
                       'company_name':company.get('name', '') if isinstance(company, dict) else ''}
            state = self.state()
            state.update(profile=profile, verified_at=self.now())
            self.vault.save(self.env, state)
            return profile

    def _refresh(self, config, tokens):
        if not tokens.get('refresh_token'):
            raise AllegroError('Połącz konto ponownie — brakuje możliwości odnowienia dostępu.')
        result = self.transport.request(self.auth_url + '/auth/oauth/token', 'POST', self._headers(config),
            {'grant_type':'refresh_token', 'refresh_token':tokens['refresh_token']})
        return self._save_tokens(result)

    def disconnect(self):
        with self.lock:
            state = self.state()
            self.vault.save(self.env, {'config':state['config']} if state.get('config') else {})
