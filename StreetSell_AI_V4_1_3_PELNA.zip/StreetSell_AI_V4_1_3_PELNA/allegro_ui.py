"""Panel połączenia Allegro: jednorazowa konfiguracja właściciela i zgoda OAuth."""
import queue
import threading
import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime
import webbrowser
from allegro_api import AllegroClient, AllegroError, Cancelled

BG, PANEL, TEXT, MUTED, RED = '#0d0f14', '#171a22', '#f5f6fa', '#969eaf', '#f04455'

class AllegroDialog(tk.Toplevel):
    def __init__(self, parent, client_factory=AllegroClient):
        super().__init__(parent)
        self.title('StreetSell AI • konto Allegro')
        self.geometry('730x650')
        self.minsize(660, 610)
        self.configure(bg=BG)
        self.transient(parent)
        self.factory = client_factory
        self.events = queue.Queue()
        self.cancel = threading.Event()
        self.running = False
        self.closed = False
        self.client = None
        self.session_url = None
        self.timer = None
        self.variables = {key:tk.StringVar() for key in ('client_id','client_secret','user_agent')}
        self.environment = tk.StringVar(value='Allegro — prawdziwe konto')
        self.status = tk.StringVar(value='Niepołączone')
        self.account = tk.StringVar(value='Brak potwierdzonego konta')
        self.last_check = tk.StringVar(value='')
        self.code = tk.StringVar(value='—')
        self.build()
        self.protocol('WM_DELETE_WINDOW', self.close)
        self.load_environment()
        self.after(100, self.poll)
        self.grab_set()

    def build(self):
        pad = ttk.Frame(self, padding=20)
        pad.pack(fill='both', expand=True, padx=10, pady=10)
        ttk.Label(pad, text='Połącz konto Allegro', font=('Segoe UI',18,'bold')).pack(anchor='w')
        ttk.Label(pad, text='Logowanie i potwierdzenie konta odbywa się na stronie Allegro.',
                  foreground=MUTED, padding=(0,8)).pack(anchor='w')
        row = ttk.Frame(pad)
        row.pack(fill='x', pady=(5,14))
        ttk.Label(row, text='Środowisko:').pack(side='left')
        self.env_combo = ttk.Combobox(row, textvariable=self.environment, state='readonly', width=32,
            values=('Allegro — prawdziwe konto','Sandbox — konto testowe'))
        self.env_combo.pack(side='left', padx=10)
        self.env_combo.bind('<<ComboboxSelected>>', lambda e:self.load_environment())
        self.tabs = ttk.Notebook(pad)
        self.tabs.pack(fill='both', expand=True)
        connection = self.scroll_page('Konto Allegro')
        config = self.scroll_page('Konfiguracja aplikacji')
        ttk.Label(connection, textvariable=self.status, font=('Segoe UI',12,'bold'), foreground=RED,
                  wraplength=590).pack(anchor='w', pady=(0,10))
        ttk.Label(connection, textvariable=self.account, wraplength=590).pack(anchor='w')
        ttk.Label(connection, textvariable=self.last_check, foreground=MUTED,
                  wraplength=590).pack(anchor='w', pady=(5,15))
        actions = ttk.Frame(connection)
        actions.pack(fill='x')
        self.connect_button = ttk.Button(actions, text='Połącz konto Allegro', style='Accent.TButton', command=self.connect)
        self.connect_button.pack(side='left')
        self.check_button = ttk.Button(actions, text='Sprawdź połączenie', command=self.check)
        self.check_button.pack(side='left', padx=8)
        self.disconnect_button = ttk.Button(connection, text='Usuń dostęp z tego komputera', command=self.disconnect)
        self.disconnect_button.pack(anchor='w', pady=(10,18))
        ttk.Label(connection, text='Kod do potwierdzenia na stronie Allegro', foreground=MUTED).pack(anchor='w')
        ttk.Label(connection, textvariable=self.code, font=('Segoe UI',17,'bold')).pack(anchor='w', pady=8)
        links = ttk.Frame(connection)
        links.pack(fill='x')
        self.open_button = ttk.Button(links, text='Otwórz stronę logowania', command=self.open_login, state='disabled')
        self.open_button.pack(side='left')
        self.cancel_button = ttk.Button(links, text='Przerwij łączenie', command=self.request_cancel, state='disabled')
        self.cancel_button.pack(side='left', padx=8)
        ttk.Label(connection, text='Dostęp: konto, zamówienia, odczyt i zapis ofert oraz odczyt ustawień sprzedaży.\nHasło Allegro wpisujesz wyłącznie na stronie Allegro.',
                  foreground=MUTED, wraplength=590, padding=(0,18,0,0)).pack(anchor='w')

        ttk.Label(config, text='Jednorazowa konfiguracja własnej aplikacji StreetSell AI',
                  font=('Segoe UI',10,'bold'), wraplength=590).pack(anchor='w')
        ttk.Label(config, text='Jako właściciel tej integracji zarejestruj ją w Allegro. '
                  'Instrukcja prowadzi do potrzebnych ustawień; nie wpisuj tutaj hasła do konta.',
                  foreground=MUTED, wraplength=590, padding=(0,8)).pack(anchor='w')
        for name, title in [('client_id','Client ID aplikacji'),('client_secret','Client Secret aplikacji'),
                            ('user_agent','User-Agent z kreatora Allegro')]:
            ttk.Label(config, text=title).pack(anchor='w', pady=(8,4))
            ttk.Entry(config, textvariable=self.variables[name], show='*' if name=='client_secret' else '',
                      width=60).pack(fill='x')
        config_actions = ttk.Frame(config)
        config_actions.pack(fill='x', pady=14)
        self.save_button = ttk.Button(config_actions, text='Zapisz konfigurację', style='Accent.TButton', command=self.save_config)
        self.save_button.pack(side='left')
        ttk.Button(config_actions, text='Instrukcja krok po kroku', command=self.instructions).pack(side='left', padx=8)
        ttk.Label(config, text='Client Secret i tokeny są przechowywane w magazynie poświadczeń Windows, '
                  'poza bazą produktów i eksportem CSV.', foreground=MUTED, wraplength=590).pack(anchor='w')
        ttk.Button(pad, text='Zamknij', command=self.close).pack(anchor='e', pady=(15,0))

    def scroll_page(self, title):
        shell = ttk.Frame(self.tabs)
        self.tabs.add(shell, text=title)
        canvas = tk.Canvas(shell,bg=PANEL,highlightthickness=0,width=400,height=320)
        scrollbar = ttk.Scrollbar(shell,orient='vertical',command=canvas.yview)
        scrollbar.pack(side='right',fill='y')
        canvas.pack(side='left',fill='both',expand=True)
        canvas.configure(yscrollcommand=scrollbar.set)
        inner = ttk.Frame(canvas,padding=16)
        item = canvas.create_window((0,0),window=inner,anchor='nw')
        def resize(_event=None):
            canvas.itemconfigure(item,width=max(1,canvas.winfo_width()),
                                 height=max(inner.winfo_reqheight(),canvas.winfo_height()))
            canvas.configure(scrollregion=canvas.bbox('all'))
        canvas.bind('<Configure>',resize)
        inner.bind('<Configure>',resize)
        canvas.bind('<MouseWheel>',lambda e:canvas.yview_scroll(-int(e.delta/120),'units'))
        return inner

    def env(self):
        return 'sandbox' if self.environment.get().startswith('Sandbox') else 'production'

    def load_environment(self):
        if self.running:
            return
        self.session_url = None
        self.code.set('—')
        self.open_button.state(['disabled'])
        for var in self.variables.values():
            var.set('')
        try:
            self.client = self.factory(self.env())
            self.display_cached()
            data = self.client.state()
            for key,var in self.variables.items():
                var.set(data.get('config',{}).get(key,''))
            if not data.get('config'):
                self.tabs.select(1)
            self.connect_button.state(['!disabled'])
            self.check_button.state(['!disabled'])
            self.disconnect_button.state(['!disabled'])
        except AllegroError as exc:
            self.client = None
            self.status.set(str(exc))
            self.connect_button.state(['disabled'])
            self.check_button.state(['disabled'])
            self.disconnect_button.state(['disabled'])

    def display_cached(self):
        data = self.client.state()
        profile = data.get('profile') or {}
        self.status.set('Konto zapisane — sprawdź połączenie' if data.get('tokens') else 'Niepołączone')
        if profile:
            self.account.set(self.profile_label(profile))
        else:
            self.account.set('Brak potwierdzonego konta')
        verified = data.get('verified_at')
        self.last_check.set('Ostatnie sprawdzenie: ' + datetime.fromtimestamp(verified).strftime('%d.%m.%Y %H:%M') if verified else '')

    @staticmethod
    def profile_label(profile):
        suffix = ' • ' + profile['company_name'] if profile.get('company_name') else ''
        return f"{profile['login']}  (ID {profile['id']}){suffix}"

    def save_config(self):
        if self.running or not self.client:
            return
        try:
            old=self.client.state()
            values={k:v.get() for k,v in self.variables.items()}
            changed=any(values[k].strip()!=old.get('config',{}).get(k,'') for k in ('client_id','client_secret'))
            if changed and old.get('tokens') and not messagebox.askyesno('Zmiana aplikacji',
                    'Zmiana danych aplikacji usunie lokalne połączenie konta. Kontynuować?',parent=self):
                return
            self.client.configure(**values)
            self.display_cached()
            self.status.set('Konfiguracja zapisana. Kliknij Połącz konto Allegro.')
            self.tabs.select(0)
        except AllegroError as exc:
            messagebox.showerror('Konfiguracja Allegro',str(exc),parent=self)

    def set_busy(self, value, cancellable=False):
        self.running=value
        for button in (self.connect_button,self.check_button,self.disconnect_button,self.save_button):
            button.state(['disabled' if value else '!disabled'])
        self.env_combo.configure(state='disabled' if value else 'readonly')
        self.cancel_button.state(['!disabled' if value and cancellable else 'disabled'])
        if not value:
            self.open_button.state(['disabled'])
            self.session_url=None
            self.code.set('—')

    def run_worker(self, worker, progress, cancellable=False):
        if self.running or not self.client:
            return
        self.cancel.clear()
        self.set_busy(True,cancellable)
        self.status.set(progress)
        def execute():
            try:
                result=worker()
                self.events.put(('done',result))
            except Cancelled:
                self.events.put(('cancelled',None))
            except AllegroError as exc:
                self.events.put(('error',str(exc)))
            except Exception:
                self.events.put(('error','Nie udało się wykonać operacji. Spróbuj ponownie.'))
        threading.Thread(target=execute,daemon=True).start()

    def connect(self):
        if not self.client:
            return
        try:
            self.client._config()
        except AllegroError as exc:
            self.tabs.select(1)
            messagebox.showinfo('Konfiguracja aplikacji',str(exc),parent=self)
            return
        def worker():
            device=self.client.begin_device()
            if self.cancel.is_set():
                raise Cancelled()
            self.events.put(('device',device))
            return self.client.complete_device(device,self.cancel,
                on_slow=lambda:self.events.put(('slow',None)))
        self.tabs.select(0)
        self.run_worker(worker,'Przygotowuję logowanie Allegro…',cancellable=True)

    def check(self):
        if self.client:
            self.run_worker(self.client.profile,'Sprawdzam dostęp do konta Allegro…')

    def open_login(self):
        if self.session_url:
            try:
                opened=webbrowser.open(self.session_url)
            except Exception:
                opened=False
            if not opened:
                self.clipboard_clear()
                self.clipboard_append(self.session_url)
                messagebox.showinfo('Otwórz przeglądarkę','Adres skopiowano do schowka. Wklej go w przeglądarce.',parent=self)

    def request_cancel(self):
        self.cancel.set()
        self.status.set('Kończę łączenie. Trwające zapytanie może potrwać do 20 sekund…')
        self.cancel_button.state(['disabled'])
        self.open_button.state(['disabled'])

    def poll(self):
        while True:
            try:
                event,data=self.events.get_nowait()
            except queue.Empty:
                break
            if event=='device':
                if self.cancel.is_set():
                    continue
                self.session_url=data['open_url']
                self.code.set(data['user_code'])
                self.open_button.state(['!disabled'])
                self.status.set('Potwierdź dostęp w przeglądarce. Oczekuję na zgodę Allegro…')
                self.open_login()
            elif event=='slow':
                if not self.cancel.is_set():
                    self.status.set('Oczekuję na zgodę — Allegro poprosiło o rzadsze sprawdzanie.')
            elif event in ('done','error','cancelled'):
                self.set_busy(False)
                if event=='done':
                    self.display_cached()
                    self.status.set('Połączono i sprawdzono konto Allegro')
                    self.account.set(self.profile_label(data))
                    if self.client.env=='production' and hasattr(self.master,'allegro_connected'):self.master.allegro_connected()
                elif event=='error':
                    self.status.set(data)
                    messagebox.showerror('Połączenie Allegro',data,parent=self)
                else:
                    self.status.set('Łączenie przerwane. Możesz rozpocząć je ponownie.')
        if not self.closed:
            self.timer=self.after(100,self.poll)

    def disconnect(self):
        if self.running or not self.client:
            return
        if messagebox.askyesno('Usuń lokalny dostęp',
                'Usunąć tokeny Allegro z tego komputera?\nKonfiguracja aplikacji zostanie zachowana. '
                'Aby cofnąć samą zgodę, usuń też powiązanie w ustawieniach Allegro.',parent=self):
            try:
                self.client.disconnect()
                self.display_cached()
                self.status.set('Usunięto dostęp z tego komputera')
                if self.client.env=='production' and hasattr(self.master,'clear_allegro_data'):self.master.clear_allegro_data()
            except AllegroError as exc:
                messagebox.showerror('Połączenie Allegro',str(exc),parent=self)

    def instructions(self):
        win=tk.Toplevel(self)
        win.title('Jednorazowa konfiguracja własnej aplikacji')
        win.geometry('680x560')
        win.transient(self)
        body=ttk.Frame(win,padding=22)
        body.pack(fill='both',expand=True)
        ttk.Label(body,text='Konfiguracja StreetSell AI w Allegro',font=('Segoe UI',14,'bold')).pack(anchor='w')
        text=('1. Otwórz Zarządzanie aplikacjami i zarejestruj własną aplikację StreetSell AI. '
              'Na prawdziwym koncie potrzebne jest aktywne konto i logowanie dwustopniowe.\n\n'
              '2. Wybierz typ bez dostępu do przeglądarki albo klawiatury (Device Flow). '
              'To nazwa typu integracji — logowanie sprzedawcy nadal odbywa się w przeglądarce. '
              'Zaznacz: odczyt danych konta, zamówień, odczyt i zapis ofert oraz odczyt ustawień sprzedaży. Zakresy: allegro:api:profile:read, allegro:api:orders:read, allegro:api:sale:offers:read, allegro:api:sale:offers:write, allegro:api:sale:settings:read.\n\n'
              '3. Skopiuj Client ID i Client Secret do konfiguracji w StreetSell AI. '
              'Nie przesyłaj Client Secret ani tokenów w wiadomości.\n\n'
              '4. W kreatorze User-Agent Allegro przygotuj identyfikator z nazwą aplikacji, '
              'wersją i adresem własnej strony informacyjnej lub repozytorium opisującego aplikację. '
              'Wklej pełną wartość do pola User-Agent.\n\n'
              '5. Zapisz konfigurację. Kliknij Połącz konto Allegro i potwierdź zgodę na stronie Allegro.\n\n'
              'Ten ekran służy konfiguracji Twojej własnej integracji. Przy udostępnianiu jej innym '
              'sprzedawcom używa się jednego Client ID aplikacji — nie prosi się każdego o rejestrację własnej.')
        box=tk.Text(body,wrap='word',bg=PANEL,fg=TEXT,relief='flat',font=('Segoe UI',10),padx=5,pady=10)
        box.insert('1.0',text);box.configure(state='disabled')
        box.pack(fill='both',expand=True,pady=12)
        sy=ttk.Scrollbar(box,command=box.yview)
        sy.pack(side='right',fill='y');box.configure(yscrollcommand=sy.set)
        urls=ttk.Frame(body)
        urls.pack(fill='x')
        base=self.client.apps_url if self.client else ('https://apps.developer.allegro.pl.allegrosandbox.pl' if self.env()=='sandbox' else 'https://apps.developer.allegro.pl')
        ttk.Button(urls,text='Rejestracja aplikacji',command=lambda:webbrowser.open(base)).pack(side='left')
        ttk.Button(urls,text='Kreator User-Agent',command=lambda:webbrowser.open(base+'/user-agent')).pack(side='left',padx=8)
        ttk.Button(urls,text='Zamknij',command=win.destroy).pack(side='right')
        win.grab_set()
        def close():
            win.destroy()
            if not self.closed:
                self.grab_set()
        win.protocol('WM_DELETE_WINDOW',close)
        # Wszystkie sposoby zamknięcia przywracają modalność panelu konta.
        win.bind('<Destroy>',lambda e:self.grab_set() if e.widget==win and not self.closed else None)

    def close(self):
        if self.running:
            self.request_cancel()
            messagebox.showinfo('Trwa operacja','Kończę bieżące zapytanie. Zamknij okno, gdy operacja się zakończy.',parent=self)
            return
        self.closed=True
        if self.timer:
            self.after_cancel(self.timer)
        self.grab_release()
        self.destroy()
