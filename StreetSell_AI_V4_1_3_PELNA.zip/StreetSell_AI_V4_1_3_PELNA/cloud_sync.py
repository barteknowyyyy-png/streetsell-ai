"""V4 bidirectional synchronization with stable UUIDs and optimistic revisions.

All stock/price/archive changes are observed from committed SQLite snapshots,
including writes made by legacy modules and Allegro. Conflicts stop that row.
"""
import json
import sqlite3
import uuid
from datetime import datetime,timezone
from pathlib import Path
from cloud_api import CloudError


def canonical(value):return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'))


def backup_database(path,label='v4'):
    path=Path(path)
    if not path.is_file():raise CloudError('Nie znaleziono istniejącej bazy streetsell.db.')
    target=path.parent/'backups'/('streetsell_'+label+'_'+datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_%f')+'.db')
    target.parent.mkdir(exist_ok=True)
    with sqlite3.connect(f'{path.resolve().as_uri()}?mode=ro',uri=True) as source,sqlite3.connect(target) as dest:
        source.backup(dest)
        if dest.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise CloudError('Kopia SQLite nie przeszła kontroli integralności.')
    return target


class Sync:
    def __init__(self,store,api):
        self.store=store;self.api=api
        if not api.user_id:raise CloudError('Brak zalogowanego użytkownika.')
        # Run before adding V4 metadata. No product columns are removed or replaced.
        self.backup=backup_database(store.path,'przed_v4')
        with store.connect() as c:
            c.execute('CREATE TABLE IF NOT EXISTS ss_v4_owner(id INTEGER PRIMARY KEY CHECK(id=1),project TEXT NOT NULL,user_id TEXT NOT NULL)')
            owner=c.execute('SELECT * FROM ss_v4_owner').fetchone()
            if owner and (owner['project']!=api.url or owner['user_id']!=api.user_id):
                raise CloudError('Ta baza jest przypisana do innego konta lub projektu. Użyj osobnego folderu aplikacji dla drugiego konta.')
            c.execute('INSERT OR IGNORE INTO ss_v4_owner VALUES(1,?,?)',(api.url,api.user_id))
            c.execute('''CREATE TABLE IF NOT EXISTS ss_v4_map(kind TEXT NOT NULL,local_id INTEGER NOT NULL,uid TEXT NOT NULL UNIQUE,
                revision INTEGER NOT NULL DEFAULT 0,base TEXT,conflict TEXT,PRIMARY KEY(kind,local_id))''')
            c.execute('CREATE TABLE IF NOT EXISTS ss_v4_conflict_history(id INTEGER PRIMARY KEY,kind TEXT,uid TEXT,local_data TEXT,remote_data TEXT,resolved_at TEXT)')

    def mappings(self,c,kind):
        table='products' if kind=='products' else 'pallets'
        for row in c.execute(f'SELECT id FROM {table}').fetchall():
            c.execute('INSERT OR IGNORE INTO ss_v4_map(kind,local_id,uid) VALUES(?,?,?)',(kind,row['id'],str(uuid.uuid4())))
        return c.execute('SELECT * FROM ss_v4_map WHERE kind=? ORDER BY local_id',(kind,)).fetchall()

    def payload(self,c,kind,lid):
        table='products' if kind=='products' else 'pallets'
        row=c.execute(f'SELECT * FROM {table} WHERE id=?',(lid,)).fetchone()
        if row is None:raise CloudError('Wykryto fizyczne usunięcie rekordu. Przywróć kopię lub użyj archiwum.')
        fields=dict(row);fields.pop('id')
        if kind=='pallets':return {'fields':fields}
        archived=c.execute('SELECT archived_at,reason FROM inventory_archive WHERE product_id=?',(lid,)).fetchone()
        link=c.execute("SELECT m.uid FROM pallet_products p JOIN ss_v4_map m ON m.kind='pallets' AND m.local_id=p.pallet_id WHERE p.product_id=?",(lid,)).fetchone()
        marker=c.execute('SELECT 1 FROM pallet_archive_items WHERE product_id=?',(lid,)).fetchone()
        return {'fields':fields,'archive':dict(archived) if archived else None,'pallet_id':link['uid'] if link else None,'pallet_archive_item':bool(marker)}

    def apply(self,c,kind,remote):
        data=remote['data'];fields=dict(data['fields'])
        table='products' if kind=='products' else 'pallets'
        columns={r['name'] for r in c.execute(f'PRAGMA table_info({table})')}-{'id'}
        if set(fields)-columns:raise CloudError('Nowszy schemat danych. Zaktualizuj aplikację przed synchronizacją.')
        if kind=='products':
            quantity=fields.get('quantity')
            if type(quantity)!=int or quantity<0:raise CloudError('Nieprawidłowa ilość w danych z chmury.')
            if data.get('pallet_id') and not c.execute("SELECT 1 FROM ss_v4_map WHERE kind='pallets' AND uid=?",(data['pallet_id'],)).fetchone():
                raise CloudError('Brak palety wskazanej przez produkt. Ponów synchronizację.')
        mapped=c.execute('SELECT * FROM ss_v4_map WHERE kind=? AND uid=?',(kind,remote['id'])).fetchone()
        if mapped:
            lid=mapped['local_id']
            c.execute(f'UPDATE {table} SET '+','.join('"'+k+'"=?' for k in fields)+' WHERE id=?',(*fields.values(),lid))
        else:
            if kind=='pallets' and c.execute('SELECT 1 FROM pallets WHERE number=?',(fields['number'],)).fetchone():
                raise CloudError('Konflikt numeru palety. Zmień lokalny numer palety przed synchronizacją.')
            lid=c.execute(f'INSERT INTO {table} ('+','.join('"'+k+'"' for k in fields)+') VALUES ('+','.join('?' for _ in fields)+')',tuple(fields.values())).lastrowid
            c.execute('INSERT INTO ss_v4_map(kind,local_id,uid) VALUES(?,?,?)',(kind,lid,remote['id']))
        if kind=='products':
            c.execute('DELETE FROM pallet_products WHERE product_id=?',(lid,))
            c.execute('DELETE FROM pallet_archive_items WHERE product_id=?',(lid,))
            if data.get('pallet_id'):
                pallet=c.execute("SELECT local_id FROM ss_v4_map WHERE kind='pallets' AND uid=?",(data['pallet_id'],)).fetchone()[0]
                c.execute('INSERT INTO pallet_products VALUES(?,?)',(lid,pallet))
                if data.get('pallet_archive_item'):c.execute('INSERT INTO pallet_archive_items VALUES(?,?)',(pallet,lid))
            c.execute('DELETE FROM inventory_archive WHERE product_id=?',(lid,))
            if data.get('archive'):
                a=data['archive'];c.execute('INSERT INTO inventory_archive VALUES(?,?,?)',(lid,a['archived_at'],a['reason']))
        c.execute('UPDATE ss_v4_map SET revision=?,base=?,conflict=NULL WHERE kind=? AND local_id=?',(remote['revision'],canonical(data),kind,lid))

    def cycle(self):
        uploaded=downloaded=conflicts=0
        # Preflight both collections before publishing anything. Never guess identity
        # between an old cloud inventory and an unmapped local inventory.
        fetched={kind:self.api.list_rows(kind) for kind in ('pallets','products')}
        with self.store.connect() as c:
            unmapped=c.execute("SELECT count(*) FROM ss_v4_map WHERE kind='products'").fetchone()[0]==0
            local_count=c.execute('SELECT count(*) FROM products').fetchone()[0]
        if unmapped and local_count and fetched['products']:
            raise CloudError('Chmura i lokalna baza mają już produkty bez wspólnego mapowania UUID. Synchronizacja zatrzymana przed wysyłką, aby uniknąć duplikatów. Potrzebne jednorazowe uzgodnienie rekordów.')
        # Do not hold a SQLite transaction during network calls.
        for kind in ('pallets','products'):
            remote={r['id']:r for r in fetched[kind]}
            with self.store.connect() as c:
                c.execute('BEGIN IMMEDIATE')
                maps=self.mappings(c,kind)
            mapped_ids={m['uid'] for m in maps}
            for m in maps:
                with self.store.connect() as c:local=self.payload(c,kind,m['local_id'])
                encoded=canonical(local);r=remote.get(m['uid'])
                dirty=encoded!=m['base']
                if r and r['revision']!=m['revision']:
                    with self.store.connect() as c:
                        c.execute('BEGIN IMMEDIATE')
                        # Recheck under the write lock: a local editor may have saved meanwhile.
                        current=canonical(self.payload(c,kind,m['local_id']))
                        if current!=m['base'] and current!=canonical(r['data']):
                            c.execute('UPDATE ss_v4_map SET conflict=? WHERE kind=? AND local_id=?',(canonical(r),kind,m['local_id']));conflicts+=1
                        else:self.apply(c,kind,r);downloaded+=1
                    continue
                if not r and m['revision']:
                    raise CloudError('Rekord zniknął z chmury. Synchronizacja wstrzymana; używaj archiwizacji zamiast DELETE.')
                if dirty:
                    result=self.api.push(kind,m['uid'],m['revision'],local)
                    with self.store.connect() as c:
                        if not result['ok']:
                            c.execute('UPDATE ss_v4_map SET conflict=? WHERE kind=? AND local_id=?',(canonical(result['row']),kind,m['local_id']));conflicts+=1
                        else:
                            # Preserve edits made while the HTTP request was in flight.
                            c.execute('UPDATE ss_v4_map SET revision=?,base=?,conflict=NULL WHERE kind=? AND local_id=?',(result['row']['revision'],encoded,kind,m['local_id']));uploaded+=1
            for uid,r in remote.items():
                if uid not in mapped_ids:
                    with self.store.connect() as c:
                        c.execute('BEGIN IMMEDIATE');self.apply(c,kind,r)
                    downloaded+=1
        return {'uploaded':uploaded,'downloaded':downloaded,'conflicts':conflicts}

    def conflicts(self):
        with self.store.connect() as c:return [dict(r) for r in c.execute('SELECT * FROM ss_v4_map WHERE conflict IS NOT NULL')]

    def resolve(self,kind,lid,choice):
        if choice not in ('local','remote'):raise ValueError('Nieznany wybór.')
        backup_database(self.store.path,'przed_rozwiazaniem_konfliktu')
        with self.store.connect() as c:
            c.execute('BEGIN IMMEDIATE')
            m=c.execute('SELECT * FROM ss_v4_map WHERE kind=? AND local_id=?',(kind,lid)).fetchone()
            if not m or not m['conflict']:return
            remote=json.loads(m['conflict']);local=self.payload(c,kind,lid)
            c.execute('INSERT INTO ss_v4_conflict_history(kind,uid,local_data,remote_data,resolved_at) VALUES(?,?,?,?,?)',(kind,m['uid'],canonical(local),canonical(remote),datetime.now(timezone.utc).isoformat()))
            if choice=='remote':self.apply(c,kind,remote)
            else:c.execute('UPDATE ss_v4_map SET revision=?,base=?,conflict=NULL WHERE kind=? AND local_id=?',(remote['revision'],canonical(remote['data']),kind,lid))
